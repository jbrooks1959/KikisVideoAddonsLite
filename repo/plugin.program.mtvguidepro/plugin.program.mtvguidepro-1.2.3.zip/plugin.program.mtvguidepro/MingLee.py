# coding: UTF-8
import sys
l1l11_opy_ = sys.version_info [0] == 2
l111l_opy_ = 2048
l111_opy_ = 7
def l1ll1_opy_ (ll_opy_):
	global l11ll_opy_
	l1l1ll_opy_ = ord (ll_opy_ [-1])
	l1l1l_opy_ = ll_opy_ [:-1]
	l1ll1l_opy_ = l1l1ll_opy_ % len (l1l1l_opy_)
	l1l1_opy_ = l1l1l_opy_ [:l1ll1l_opy_] + l1l1l_opy_ [l1ll1l_opy_:]
	if l1l11_opy_:
		l1111_opy_ = unicode () .join ([unichr (ord (char) - l111l_opy_ - (l1lll_opy_ + l1l1ll_opy_) % l111_opy_) for l1lll_opy_, char in enumerate (l1l1_opy_)])
	else:
		l1111_opy_ = str () .join ([chr (ord (char) - l111l_opy_ - (l1lll_opy_ + l1l1ll_opy_) % l111_opy_) for l1lll_opy_, char in enumerate (l1l1_opy_)])
	return eval (l1111_opy_)
import xbmc
import xbmcgui
import xbmcaddon
import os
import sys
import gui
from strings import *
ADDONID = l1ll1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡶࡲࡰࡩࡵࡥࡲ࠴࡭ࡵࡸࡪࡹ࡮ࡪࡥࡱࡴࡲࠫࡇ")
ICON  = xbmc.translatePath(os.path.join(l1ll1_opy_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫࠯ࡢࡦࡧࡳࡳࡹࠧࡈ"), ADDONID, l1ll1_opy_ (u"ࠧࡪࡥࡲࡲ࠳ࡶ࡮ࡨࠩࡉ")))
ADDON =  xbmcaddon.Addon(ADDONID)
channelTitle = sys.argv[1]
programTitle = sys.argv[2]
startTime    = sys.argv[3]
def playChannel(channel, program = None):
	url = lel.getStreamUrl(channel)
	if url:
		if url[0:9] == l1ll1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫࡊ") and ADDON.getSetting(l1ll1_opy_ (u"ࠩࡤࡰࡹ࡫ࡲ࡯ࡣࡷ࡭ࡻ࡫࠮ࡱ࡮ࡤࡽࡧࡧࡣ࡬ࠩࡋ")) == l1ll1_opy_ (u"ࠪࡸࡷࡻࡥࠨࡌ"):
			xbmc.executebuiltin(l1ll1_opy_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡕࡹࡳࡖ࡬ࡶࡩ࡬ࡲ࠭ࠫࡳࠪࠩࡍ") % url)
		else:
			if url[0:26] == l1ll1_opy_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡤࡦࡺ࠲ࠫࡎ"):
				url = re.findall(l1ll1_opy_ (u"ࡸࠧࡶࡴ࡯ࡁ࠭࠴ࠫࡀࠫࠩࡱࡴࡪࡥࠨࡏ"), url)
				url = l1ll1_opy_ (u"ࠧࠨࡐ").join(url)
				url = urllib.unquote_plus(url)
			try:
				listitem = xbmcgui.ListItem(l1ll1_opy_ (u"ࠨࡖ࡬ࡸࡱ࡫ࠧࡑ"), thumbnailImage=channel.logo)
				listitem.setInfo(l1ll1_opy_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨࡒ"), {l1ll1_opy_ (u"ࠪࡘ࡮ࡺ࡬ࡦࠩࡓ"): l1ll1_opy_ (u"ࠦࡠࡉࡏࡍࡑࡕࠤࡸࡱࡹࡣ࡮ࡸࡩࡢࡡࡂ࡞ࠤࡔ")+channel.title+l1ll1_opy_ (u"ࠧࠦ࠭ࠡ࡝ࡆࡓࡑࡕࡒࠡࡲࡤࡰࡪ࡭ࡲࡦࡧࡱࡡࠧࡕ")+program.title+l1ll1_opy_ (u"ࠨ࡛࠰ࡅࡒࡐࡔࡘ࡝࡜࠱ࡅࡡࠧࡖ")})
			except:
				pass
			xbmc.Player().play(item=url, listitem=listitem, windowed=0)
	return url is not None
def createAlarmClockName(programTitle, startTime):
    return l1ll1_opy_ (u"ࠧࡵࡸࡪࡹ࡮ࡪࡥ࠮ࠧࡶ࠱ࠪࡹࠧࡗ") % (programTitle, startTime)
def l11lll_opy_(programTitle, startTime):
    name = createAlarmClockName(programTitle, startTime)
    xbmc.executebuiltin(l1ll1_opy_ (u"ࠨࡅࡤࡲࡨ࡫࡬ࡂ࡮ࡤࡶࡲ࠮ࠥࡴ࠯࠸ࡱ࡮ࡴࡳ࠭ࡖࡵࡹࡪ࠯ࠧࡘ") % name.encode(l1ll1_opy_ (u"ࠩࡸࡸ࡫࠳࠸ࠨ࡙"), l1ll1_opy_ (u"ࠪࡶࡪࡶ࡬ࡢࡥࡨ࡚ࠫ")))
    xbmc.executebuiltin(l1ll1_opy_ (u"ࠫࡈࡧ࡮ࡤࡧ࡯ࡅࡱࡧࡲ࡮ࠪࠨࡷ࠲ࡴ࡯ࡸ࠮ࡗࡶࡺ࡫ࠩࠨ࡛") % name.encode(l1ll1_opy_ (u"ࠬࡻࡴࡧ࠯࠻ࠫ࡜"), l1ll1_opy_ (u"࠭ࡲࡦࡲ࡯ࡥࡨ࡫ࠧ࡝")))
def removeNotification(program):
    lel.removeNotification(program)
    l11lll_opy_(program.title, program.startDate)
try:
	dialog = xbmcgui.Dialog()
	lel = gui.lel(None)
	streamingService = gui.streaming.StreamsService(ADDON)
	l11l11_opy_ = lel.l11ll1_opy_(channelTitle)
	l1l11l_opy_ = lel.getCurrentProgram(l11l11_opy_)
	l1l111_opy_ = lel.getNextProgram(l1l11l_opy_)
	if sys.argv[3] == l1ll1_opy_ (u"ࠧ࠶࡯࡬ࡲࠬ࡞"):
		ret = dialog.yesno(l1ll1_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡨࡩ࠸࠻࠾࠲ࡣ࠶ࡠࡑࡠࡉࡏࡍࡑࡕࠤ࡫࡬ࡃ࠱ࡅ࠳ࡇ࠵ࡣࡡࡺࡨࡤ࡭ࡷ࡛ࠦࡄࡑࡏࡓࡗࠦࡦࡧ࠶࠹࠼࠷ࡨ࠴࡞ࡉ࡞ࡇࡔࡒࡏࡓࠢࡩࡪࡈ࠶ࡃ࠱ࡅ࠳ࡡࡺ࡯ࡤࡦ࡝ࡆࡓࡑࡕࡒࠡࡩࡲࡰࡩࡣࠠࡑࡔࡒ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ࡟"),programTitle + l1ll1_opy_ (u"ࠩࠣࠫࡠ") + strings(NOTIFICATION_5_MINS, channelTitle),l1ll1_opy_ (u"ࠪࡈࡴࠦࡹࡰࡷࠣࡻ࡮ࡹࡨࠡࡶࡲࠤࡼࡧࡴࡤࡪࠣࡸ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮ࡁࠪࡡ"),l1ll1_opy_ (u"ࠫࠬࡢ"),l1ll1_opy_ (u"ࠬ࡝ࡡࡵࡥ࡫ࠤࡳࡵࡷࠨࡣ"),l1ll1_opy_ (u"࠭ࡒࡦ࡯࡬ࡲࡩࠦ࡭ࡦࠢ࡬ࡲࠥ࠻࡭ࡪࡰࡸࡸࡪࡹࠧࡤ"))
		if ret:
			pass
		elif not ret:
			removeNotification(l1l111_opy_)
			xbmc.executebuiltin(l1ll1_opy_ (u"ࠧࡏࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳ࠮ࠥࡴ࠮ࠨࡷ࠱࠻࠰࠱࠲࠯ࠩࡸ࠯ࠧࡥ") % (l1ll1_opy_ (u"ࠨࡒࡵࡳ࡬ࡸࡡ࡮ࠢࡕࡩࡲ࡯࡮ࡥࡧࡵࠫࡦ"), l1ll1_opy_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡳ࡭ࡨࡱࠠࡢࠢࡶࡳࡺࡸࡣࡦࠢࡷࡳࠥࡶ࡬ࡢࡻࠣࡔࡷࡵࡧࡳࡣࡰࠫࡧ"), ICON))
			if not playChannel(l11l11_opy_, l1l111_opy_):
				result = streamingService.detectStream(l11l11_opy_)
				if not result:
					dialog.ok(l1ll1_opy_ (u"ࠥ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫࠺࠶࠹࠴ࡥ࠸ࡢࡓ࡛ࡄࡑࡏࡓࡗࠦࡦࡧࡅ࠳ࡇ࠵ࡉ࠰࡞ࡣࡼࡪࡦ࡯ࡲࠡ࡝ࡆࡓࡑࡕࡒࠡࡨࡩ࠸࠻࠾࠲ࡣ࠶ࡠࡋࡠࡉࡏࡍࡑࡕࠤ࡫࡬ࡃ࠱ࡅ࠳ࡇ࠵ࡣࡵࡪࡦࡨ࡟ࡈࡕࡌࡐࡔࠣ࡫ࡴࡲࡤ࡞ࠢࡓࡖࡔࡡ࠯ࡄࡑࡏࡓࡗࡣࠢࡨ"), l1ll1_opy_ (u"ࠦࡊࡸࡲࡰࡴࠤࠦࡩ"), l1ll1_opy_ (u"ࠧࡉ࡯ࡶ࡮ࡧࠤࡳࡵࡴࠡࡦࡨࡸࡪࡩࡴࠡࡣࡱࡽࠥࡹࡴࡳࡧࡤࡱࡸࠦࡦࡰࡴࠣࡸ࡭࡯ࡳࠡࡥ࡫ࡥࡳࡴࡥ࡭࠰࠱ࠦࡪ"), l1ll1_opy_ (u"ࠨࠢ࡫"))
					sys.exit(1)
				elif type(result) == str:
					lel.setCustomStreamUrl(l11l11_opy_, result)
					playChannel(l11l11_opy_, l1l111_opy_)
					if gui.l11l1l_opy_:
						lel.deleteCustomStreamUrl(l11l11_opy_)
				else:
					if l11l11_opy_.title == l1ll1_opy_ (u"ࠧࡆࡒࡏࠫ࡬") or l11l11_opy_.title == l1ll1_opy_ (u"ࠨࡐࡉࡐࠬ࡭") or l11l11_opy_.title == l1ll1_opy_ (u"ࠩࡑࡆࡆ࠭࡮") or l11l11_opy_.title == l1ll1_opy_ (u"ࠪࡒࡍࡒࠧ࡯") or l11l11_opy_.title == l1ll1_opy_ (u"ࠫࡕࡖࡖࠨࡰ") or l11l11_opy_.title == l1ll1_opy_ (u"ࠬࡔࡂࡂࠩࡱ") or l11l11_opy_.title == l1ll1_opy_ (u"࠭࠲࠵࠹ࠪࡲ") or len(l11l11_opy_.title) > 13:
						selection = kappa.iI1(result)
						if selection is not None:
							if selection == -1:
								pass
							else:
								lel.setCustomStreamUrl(l11l11_opy_, selection)
								playChannel(l11l11_opy_, l1l111_opy_)
								if gui.l11l1l_opy_:
									lel.deleteCustomStreamUrl(l11l11_opy_)
					else:
						d = gui.ChooseStreamAddonDialog(result)
						d.doModal()
						if d.stream is not None:
							lel.setCustomStreamUrl(l11l11_opy_, d.stream)
							playChannel(l11l11_opy_, l1l111_opy_)
							if gui.l11l1l_opy_:
								lel.deleteCustomStreamUrl(l11l11_opy_)
	elif sys.argv[3] == l1ll1_opy_ (u"ࠧ࡯ࡱࡺࠫࡳ"):
		ret = dialog.yesno(l1ll1_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡨࡩ࠸࠻࠾࠲ࡣ࠶ࡠࡑࡠࡉࡏࡍࡑࡕࠤ࡫࡬ࡃ࠱ࡅ࠳ࡇ࠵ࡣࡡࡺࡨࡤ࡭ࡷ࡛ࠦࡄࡑࡏࡓࡗࠦࡦࡧ࠶࠹࠼࠷ࡨ࠴࡞ࡉ࡞ࡇࡔࡒࡏࡓࠢࡩࡪࡈ࠶ࡃ࠱ࡅ࠳ࡡࡺ࡯ࡤࡦ࡝ࡆࡓࡑࡕࡒࠡࡩࡲࡰࡩࡣࠠࡑࡔࡒ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࡴ"),programTitle + l1ll1_opy_ (u"ࠩࠣࠫࡵ") + strings(NOTIFICATION_NOW, channelTitle),l1ll1_opy_ (u"ࠪࡈࡴࠦࡹࡰࡷࠣࡻ࡮ࡹࡨࠡࡶࡲࠤࡼࡧࡴࡤࡪࠣࡸ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮ࡁࠪࡶ"),l1ll1_opy_ (u"ࠫࠬࡷ"),l1ll1_opy_ (u"ࠬ࡝ࡡࡵࡥ࡫ࠤࡳࡵࡷࠨࡸ"),l1ll1_opy_ (u"࠭ࡄࡦ࡮ࡨࡸࡪࠦࡲࡦ࡯࡬ࡲࡩ࡫ࡲࠨࡹ"))
		if ret:
			removeNotification(l1l111_opy_)
		elif not ret:
			removeNotification(l1l111_opy_)
			xbmc.executebuiltin(l1ll1_opy_ (u"ࠧࡏࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳ࠮ࠥࡴ࠮ࠨࡷ࠱࠻࠰࠱࠲࠯ࠩࡸ࠯ࠧࡺ") % (l1ll1_opy_ (u"ࠨࡒࡵࡳ࡬ࡸࡡ࡮ࠢࡕࡩࡲ࡯࡮ࡥࡧࡵࠫࡻ"), l1ll1_opy_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡳ࡭ࡨࡱࠠࡢࠢࡶࡳࡺࡸࡣࡦࠢࡷࡳࠥࡶ࡬ࡢࡻࠣࡔࡷࡵࡧࡳࡣࡰࠫࡼ"), ICON))
			if not playChannel(l11l11_opy_, l1l111_opy_):
				result = streamingService.detectStream(l11l11_opy_)
				if not result:
					dialog.ok(l1ll1_opy_ (u"ࠥ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫࠺࠶࠹࠴ࡥ࠸ࡢࡓ࡛ࡄࡑࡏࡓࡗࠦࡦࡧࡅ࠳ࡇ࠵ࡉ࠰࡞ࡣࡼࡪࡦ࡯ࡲࠡ࡝ࡆࡓࡑࡕࡒࠡࡨࡩ࠸࠻࠾࠲ࡣ࠶ࡠࡋࡠࡉࡏࡍࡑࡕࠤ࡫࡬ࡃ࠱ࡅ࠳ࡇ࠵ࡣࡵࡪࡦࡨ࡟ࡈࡕࡌࡐࡔࠣ࡫ࡴࡲࡤ࡞ࠢࡓࡖࡔࡡ࠯ࡄࡑࡏࡓࡗࡣࠢࡽ"), l1ll1_opy_ (u"ࠦࡊࡸࡲࡰࡴࠤࠦࡾ"), l1ll1_opy_ (u"ࠧࡉ࡯ࡶ࡮ࡧࠤࡳࡵࡴࠡࡦࡨࡸࡪࡩࡴࠡࡣࡱࡽࠥࡹࡴࡳࡧࡤࡱࡸࠦࡦࡰࡴࠣࡸ࡭࡯ࡳࠡࡥ࡫ࡥࡳࡴࡥ࡭࠰࠱ࠦࡿ"), l1ll1_opy_ (u"ࠨࠢࢀ"))
					sys.exit(1)
				elif type(result) == str:
					lel.setCustomStreamUrl(l11l11_opy_, result)
					playChannel(l11l11_opy_, l1l111_opy_)
					if gui.l11l1l_opy_:
						lel.deleteCustomStreamUrl(l11l11_opy_)
				else:
					if l11l11_opy_.title == l1ll1_opy_ (u"ࠧࡆࡒࡏࠫࢁ") or l11l11_opy_.title == l1ll1_opy_ (u"ࠨࡐࡉࡐࠬࢂ") or l11l11_opy_.title == l1ll1_opy_ (u"ࠩࡑࡆࡆ࠭ࢃ") or l11l11_opy_.title == l1ll1_opy_ (u"ࠪࡒࡍࡒࠧࢄ") or l11l11_opy_.title == l1ll1_opy_ (u"ࠫࡕࡖࡖࠨࢅ") or l11l11_opy_.title == l1ll1_opy_ (u"ࠬࡔࡂࡂࠩࢆ") or l11l11_opy_.title == l1ll1_opy_ (u"࠭࠲࠵࠹ࠪࢇ") or len(l11l11_opy_.title) > 13:
						selection = kappa.iI1(result)
						if selection is not None:
							if selection == -1:
								pass
							else:
								lel.setCustomStreamUrl(l11l11_opy_, selection)
								playChannel(l11l11_opy_, l1l111_opy_)
								if gui.l11l1l_opy_:
									lel.deleteCustomStreamUrl(l11l11_opy_)
					else:
						d = gui.ChooseStreamAddonDialog(result)
						d.doModal()
						if d.stream is not None:
							lel.setCustomStreamUrl(l11l11_opy_, d.stream)
							playChannel(l11l11_opy_, l1l111_opy_)
							if gui.l11l1l_opy_:
								lel.deleteCustomStreamUrl(l11l11_opy_)
except:
	xbmc.executebuiltin(l1ll1_opy_ (u"ࠧࡏࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳ࠮ࠥࡴ࠮ࠨࡷ࠱࠷࠰࠱࠲࠳࠰ࠪࡹࠩࠨ࢈") % (l1ll1_opy_ (u"ࠨࡇࡵࡶࡴࡸࠡࠨࢉ"), l1ll1_opy_ (u"ࠩࡖࡳࡲ࡫ࡴࡩ࡫ࡱ࡫ࠥࡽࡥ࡯ࡶࠣࡻࡷࡵ࡮ࡨࠢࡺ࡭ࡹ࡮ࠠࡑࡴࡲ࡫ࡷࡧ࡭ࠡࡴࡨࡱ࡮ࡴࡤࡦࡴࠤࠫࢊ"), ICON))
	removeNotification(l1l111_opy_)
	import sys
	import traceback as tb
	(etype, value, traceback) = sys.exc_info()
	tb.print_exception(etype, value, traceback)