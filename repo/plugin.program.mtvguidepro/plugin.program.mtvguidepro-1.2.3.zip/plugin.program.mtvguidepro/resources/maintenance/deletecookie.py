import time
import os
import xbmc
import xbmcgui
import xbmcaddon
import shutil

cookiefile = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'plugin.program.mtvguidepro', 'cookie'))
d = xbmcgui.Dialog()
deletesuccess = False

try:
	os.remove(cookiefile)
	deletesuccess = True
except: 
	d = xbmcgui.Dialog()
	d.ok('[COLOR ff4682b4]M[COLOR ffC0C0C0]ayfair [COLOR ff4682b4]G[COLOR ffC0C0C0]uide[COLOR gold] PRO[/COLOR]', 'Error Removing cookie file','Please restart device!','Thank you for using [COLOR ff4682b4]M[COLOR ffC0C0C0]ayfair [COLOR ff4682b4]G[COLOR ffC0C0C0]uide[COLOR gold] PRO[/COLOR]')
	sys.exit(1)

if deletesuccess == True:
	d = xbmcgui.Dialog()
	d.ok('[COLOR ff4682b4]M[COLOR ffC0C0C0]ayfair [COLOR ff4682b4]G[COLOR ffC0C0C0]uide[COLOR gold] PRO[/COLOR]', 'Cookie file successfully deleted.','','Thank you for using [COLOR ff4682b4]M[COLOR ffC0C0C0]ayfair [COLOR ff4682b4]G[COLOR ffC0C0C0]uide[COLOR gold] PRO[/COLOR]')