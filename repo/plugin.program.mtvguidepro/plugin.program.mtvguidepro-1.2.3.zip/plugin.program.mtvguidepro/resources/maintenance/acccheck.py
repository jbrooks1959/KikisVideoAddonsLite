import urllib2
import xbmc
import xbmcgui
import sys
import json
import xbmcaddon
import base64
import urllib
import requests

ADDON = xbmcaddon.Addon(id='plugin.program.mtvguidepro')
dialog      = xbmcgui.Dialog()

def DansGame(KappaPride):
	gachiGASM = base64.b64decode(KappaPride)
	return gachiGASM

def show_busy_dialog():
		xbmc.executebuiltin('ActivateWindow(10138)')

def hide_busy_dialog():
	xbmc.executebuiltin('Dialog.Close(10138)')
	while xbmc.getCondVisibility('Window.IsActive(10138)'):
		xbmc.sleep(100)

def get_reboot():
	try:
		u = DansGame("aHR0cDovL21heWZhaXJndWlkZXMuY29tL2d1aWRlL2dlYXJzLnR4dA==")
		uu = requests.get(u).content
		return uu
	except:
		dialog = xbmcgui.Dialog()
		dialog.ok("[COLOR ff4682b4]M[COLOR ffC0C0C0]ayfair [COLOR ff4682b4]G[COLOR ffC0C0C0]uide[COLOR gold] PRO[/COLOR]", DansGame("RXJyb3IhIENvdWxkIG5vdCBjb25uZWN0IHRvIHNlcnZlciBbMV0="),"", DansGame("UGxlYXNlIHRyeSBhZ2FpbiBsYXRlci4="))
		sys.exit(1)

def get_reboot_account_info():
	try:
		show_busy_dialog()
		req = urllib2.Request(get_reboot()+DansGame("L3BhbmVsX2FwaS5waHA/dXNlcm5hbWU9JXMmcGFzc3dvcmQ9JXM=")%(urllib.quote_plus(ADDON.getSetting(DansGame("cmVib290LnVzZXI="))),urllib.quote_plus(ADDON.getSetting(DansGame("cmVib290LnBhc3M=")))))
		req.add_header(DansGame("VXNlci1BZ2VudA==") , DansGame("TWF5ZmFpckd1aWRlLVVzZXJBZ2VudA=="))
		response = urllib2.urlopen(req)
		link=response.read()
		jdata = json.loads(link.decode('utf8'))
		response.close()
		hide_busy_dialog()
		return jdata
	except:
		hide_busy_dialog()
		dialog.ok("[COLOR ff4682b4]M[COLOR ffC0C0C0]ayfair [COLOR ff4682b4]G[COLOR ffC0C0C0]uide[COLOR gold] PRO[/COLOR]",DansGame("RXJyb3IhIENvdWxkIG5vdCBjb25uZWN0Li4="),DansGame("SXMg")+"Gears TV"+DansGame("IGRvd24/"),"")
		sys.exit(1)

if ADDON.getSetting(DansGame("cmVib290LnVzZXI=")) == '' or ADDON.getSetting(DansGame("cmVib290LnBhc3M=")) == '':
	dialog.ok("[COLOR ff4682b4]M[COLOR ffC0C0C0]ayfair [COLOR ff4682b4]G[COLOR ffC0C0C0]uide[COLOR gold] PRO[/COLOR]", DansGame("RXJyb3IhIE5vIA==")+"Gears TV"+DansGame("IFVzZXJuYW1lIG9yIHBhc3N3b3JkIQ=="), DansGame("UGxlYXNlIGVudGVyIHlvdXIgdXNlcm5hbWUgYW5kIHBhc3N3b3JkLg=="), "")
	xbmc.executebuiltin('Dialog.Close(10140)')
	lklklklklk = dialog.input(DansGame('RW50ZXIgR2VhcnMgVFYgVXNlcm5hbWU='), type=xbmcgui.INPUT_ALPHANUM)
	lklkllklklk = dialog.input(DansGame('RW50ZXIg')+"Gears TV"+DansGame("IFBhc3N3b3Jk"), type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
	ADDON.setSetting(DansGame('cmVib290LnVzZXI='), lklklklklk)
	ADDON.setSetting(DansGame('cmVib290LnBhc3M='), lklkllklklk)
	xbmc.sleep(100)
	ADDON.openSettings()
	sys.exit(1)
#if ADDON.getSetting(DansGame("cmVib290LnBhc3M=")) == '':
#	dialog.ok("M-TV Guide", DansGame("RXJyb3IhIE5vIA==")+"Gears TV"+DansGame("IFBhc3N3b3JkIQ=="), DansGame("UGxlYXNlIGVudGVyIHlvdXIgcGFzc3dvcmQu"), "")
#	xbmc.executebuiltin('Dialog.Close(10140)')
#	lklkllklklk = dialog.input(DansGame('RW50ZXIg')+"Gears TV"+DansGame("IFBhc3N3b3Jk"), type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
#	ADDON.setSetting(DansGame('cmVib290LnBhc3M='), lklkllklklk)
#	xbmc.sleep(100)
#	ADDON.openSettings()
#	sys.exit(1)

getdata = get_reboot_account_info()
MingLee = getdata[base64.b64decode("dXNlcl9pbmZv")]
Kappa = MingLee[base64.b64decode("YXV0aA==")]
if Kappa == 1:
	TriHard = MingLee[base64.b64decode("c3RhdHVz")]
	KreyGasm = MingLee[base64.b64decode("bWF4X2Nvbm5lY3Rpb25z")]
	sneakyGasm = MingLee[base64.b64decode("dXNlcm5hbWU=")]
	if TriHard == DansGame('QWN0aXZl'):
		dialog.ok("[COLOR ff4682b4]M[COLOR ffC0C0C0]ayfair [COLOR ff4682b4]G[COLOR ffC0C0C0]uide[COLOR gold] PRO[/COLOR]", DansGame("VXNlcjog")+sneakyGasm, DansGame("QWNjb3VudCBTdGF0dXM6IA==")+DansGame("W0NPTE9SIGxpbWVd")+TriHard+DansGame("Wy9DT0xPUl0="), DansGame("TWF4IENvbm5lY3Rpb25zOiA=")+KreyGasm)
	else:
		dialog.ok("[COLOR ff4682b4]M[COLOR ffC0C0C0]ayfair [COLOR ff4682b4]G[COLOR ffC0C0C0]uide[COLOR gold] PRO[/COLOR]", DansGame("VXNlcjog")+sneakyGasm, DansGame("QWNjb3VudCBTdGF0dXM6IA==")+DansGame("W0NPTE9SIHJlZF0=")+TriHard+DansGame("Wy9DT0xPUl0="), DansGame("TWF4IENvbm5lY3Rpb25zOiA=")+KreyGasm)
	sys.exit(1)

if Kappa == 0:
	dialog.ok("[COLOR ff4682b4]M[COLOR ffC0C0C0]ayfair [COLOR ff4682b4]G[COLOR ffC0C0C0]uide[COLOR gold] PRO[/COLOR]", DansGame("RXJyb3IhIA==")+"Gears TV"+DansGame("IEFjY291bnQgbm90IGZvdW5kIQ=="), DansGame("UGxlYXNlIGNoZWNrIHlvdXIgdXNlcm5hbWUgb3IgcGFzc3dvcmQu"), "")
	xbmc.executebuiltin('Dialog.Close(10140)')
	lklklklk = dialog.input(DansGame('RW50ZXIg')+"Gears TV"+DansGame("IFVzZXJuYW1l"), type=xbmcgui.INPUT_ALPHANUM)
	lklklkl = dialog.input(DansGame('RW50ZXIg')+"Gears TV"+DansGame("IFBhc3N3b3Jk"), type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
	ADDON.setSetting(DansGame('cmVib290LnVzZXI='), lklklklk)
	ADDON.setSetting(DansGame('cmVib290LnBhc3M='), lklklkl)
	xbmc.sleep(100)
	ADDON.openSettings()
	sys.exit(1)