# coding: UTF-8
import sys
l1l11_opy_ = sys.version_info [0] == 2
l111l_opy_ = 2048
l111_opy_ = 7
def l1ll1_opy_ (ll_opy_):
	global l11ll_opy_
	l1l1ll_opy_ = ord (ll_opy_ [-1])
	l1l1l_opy_ = ll_opy_ [:-1]
	l1ll1l_opy_ = l1l1ll_opy_ % len (l1l1l_opy_)
	l1l1_opy_ = l1l1l_opy_ [:l1ll1l_opy_] + l1l1l_opy_ [l1ll1l_opy_:]
	if l1l11_opy_:
		l1111_opy_ = unicode () .join ([unichr (ord (char) - l111l_opy_ - (l1lll_opy_ + l1l1ll_opy_) % l111_opy_) for l1lll_opy_, char in enumerate (l1l1_opy_)])
	else:
		l1111_opy_ = str () .join ([chr (ord (char) - l111l_opy_ - (l1lll_opy_ + l1l1ll_opy_) % l111_opy_) for l1lll_opy_, char in enumerate (l1l1_opy_)])
	return eval (l1111_opy_)
import xbmc
import xbmcaddon
import base64
import xbmcgui
import time
import os
import requests
import cfscrape
import pickle
import sys
import re
import hashlib
ADDONID     = l1ll1_opy_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡵࡸ࡯ࡨࡴࡤࡱ࠳ࡳࡴࡷࡩࡸ࡭ࡩ࡫ࡰࡳࡱࠪࠀ")
ADDON       =  xbmcaddon.Addon(ADDONID)
cookiefile 	= xbmc.translatePath(os.path.join(l1ll1_opy_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡲࡵࡳ࡫࡯࡬ࡦࠩࠁ"), l1ll1_opy_ (u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪࠂ"), l1ll1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡱࡴࡲ࡫ࡷࡧ࡭࠯࡯ࡷࡺ࡬ࡻࡩࡥࡧࡳࡶࡴ࠭ࠃ"), l1ll1_opy_ (u"ࠨࡥࡲࡳࡰ࡯ࡥࠨࠄ")))
b           = base64.b64decode
dialog      = xbmcgui.Dialog()
PROFILE     =  xbmc.translatePath(ADDON.getAddonInfo(l1ll1_opy_ (u"ࠩࡳࡶࡴ࡬ࡩ࡭ࡧࠪࠅ")))
usrsetting  = os.path.join(PROFILE)
addonini    = xbmc.translatePath(os.path.join(usrsetting, l1ll1_opy_ (u"ࠪࡥࡩࡪ࡯࡯ࡵ࠱࡭ࡳ࡯ࠧࠆ")))
def lolu():
	return ADDON.getSetting(l1ll1_opy_ (u"ࠫࡺࡹࡥࡳࠩࠇ"))
def lolp():
	return ADDON.getSetting(l1ll1_opy_ (u"ࠬࡶࡡࡴࡵࠪࠈ"))
def lolf(f):
	MAIN_URL = b(l1ll1_opy_ (u"࠭ࡡࡉࡔ࠳ࡧࡉࡵࡶࡍ࠴࠴࡬ࡪ࡝࡚ࡩࡣ࡛ࡎࡳࡪࡗ࡭࡭࡝࡜ࡒࡻ࡙࠳࠻ࡷࡐ࠸ࡈࡹࡣࡼ࠼ࡾࡒࡳ࠱࡭ࡤ࡚ࡎࡱࡩ࡬࠺࡯ࡤ࡛ࡽࡲࡘ࠳ࡔࡹࡨ࠷࠻ࡳࡣ࠴ࡉ࡯ࡕ࡝ࡆ࡫࡛࠵࡚ࡿࡩࡹ࠲ࡼࡐࡱ࠶ࡲࡢࡘࡌ࡯ࡧ࡮࠷ࡳ࡛࡚࡝ࡰࡧࡊࡅࡷࠩࠉ"))
	l11l_opy_ = b(l1ll1_opy_ (u"ࠧࡋࡰࡐࡽࡧ࡝ࡖࡵ࡛ࡰ࡚ࡾ࡞࠲࡛ࡲࡥࡋ࡛࡬ࡣ࡮ࡘࡷࡦ࠸ࡘ࡬ࡑ࡚࡯ࡰࡨࡽ࠽࠾ࠩࠊ"))
	return MAIN_URL+f+l11l_opy_
def lolkek(a):
	a = a.decode(b(l1ll1_opy_ (u"ࠨࡣࡊ࡚࠹࠭ࠋ")))
	a = b(a)
	return a
def load_cookies(filename):
	with open(filename, l1ll1_opy_ (u"ࠩࡵࡦࠬࠌ")) as f:
		return pickle.load(f)
def save_cookies(requests_cookiejar, filename):
	with open(filename, l1ll1_opy_ (u"ࠪࡻࡧ࠭ࠍ")) as f:
		pickle.dump(requests_cookiejar, f)
def show_busy_dialog():
	xbmc.executebuiltin(l1ll1_opy_ (u"ࠫࡆࡩࡴࡪࡸࡤࡸࡪ࡝ࡩ࡯ࡦࡲࡻ࠭࠷࠰࠲࠵࠻࠭ࠬࠎ"))
def hide_busy_dialog():
	xbmc.executebuiltin(l1ll1_opy_ (u"ࠬࡊࡩࡢ࡮ࡲ࡫࠳ࡉ࡬ࡰࡵࡨࠬ࠶࠶࠱࠴࠺ࠬࠫࠏ"))
	while xbmc.getCondVisibility(l1ll1_opy_ (u"࠭ࡗࡪࡰࡧࡳࡼ࠴ࡉࡴࡃࡦࡸ࡮ࡼࡥࠩ࠳࠳࠵࠸࠾ࠩࠨࠐ")):
		xbmc.sleep(100)
def l1llll_opy_():
	username = dialog.input(l1ll1_opy_ (u"ࠧࡆࡰࡷࡩࡷࠦࡹࡰࡷࡵࠤࡒࡧࡹࡧࡣ࡬ࡶࠥࡍࡵࡪࡦࡨࡷࠥࡖࡲࡰࠢࡘࡷࡪࡸ࡮ࡢ࡯ࡨࠥࠬࠑ"), type=xbmcgui.INPUT_ALPHANUM)
	password = dialog.input(l1ll1_opy_ (u"ࠨࡇࡱࡸࡪࡸࠠࡺࡱࡸࡶࠥࡓࡡࡺࡨࡤ࡭ࡷࠦࡇࡶ࡫ࡧࡩࡸࠦࡐࡳࡱࠣࡔࡦࡹࡳࡸࡱࡵࡨࠦ࠭ࠒ"), type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
	ADDON.setSetting(l1ll1_opy_ (u"ࠩࡸࡷࡪࡸࠧࠓ"), username)
	ADDON.setSetting(l1ll1_opy_ (u"ࠪࡴࡦࡹࡳࠨࠔ"), password)
def CheckForUpdates():
    try:
        l1lll1_opy_ = int(ADDON.getAddonInfo(l1ll1_opy_ (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬࠕ")).replace(l1ll1_opy_ (u"ࠬ࠴ࠧࠖ"),l1ll1_opy_ (u"࠭ࠧࠗ")))
        url = l1ll1_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡮ࡣࡼࡪࡦ࡯ࡲࡨࡷ࡬ࡨࡪࡹ࠮ࡤࡱࡰ࠳ࡻ࡫ࡲ࠯ࡶࡻࡸࠬ࠘")
        request = requests.get(url, headers={l1ll1_opy_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ࠙"): l1ll1_opy_ (u"ࠩࡓࡖࡔࠦࡖࡦࡴࡶ࡭ࡴࡴ࠭ࡄࡪࡨࡧࡰ࡫ࡲࠨࠚ")})
        l1ll_opy_ = request.content
        l1ll11_opy_ = int(l1ll_opy_.replace(l1ll1_opy_ (u"ࠪ࠲ࠬࠛ"),l1ll1_opy_ (u"ࠫࠬࠜ")))
        if l1lll1_opy_ < l1ll11_opy_:
            dialog = xbmcgui.Dialog()
            xbmc.executebuiltin(l1ll1_opy_ (u"࡛ࠬࡰࡥࡣࡷࡩࡑࡵࡣࡢ࡮ࡄࡨࡩࡵ࡮ࡴࠪࠬࠫࠝ"))
            xbmc.executebuiltin(l1ll1_opy_ (u"࠭ࡕࡱࡦࡤࡸࡪࡇࡤࡥࡱࡱࡖࡪࡶ࡯ࡴࠪࠬࠫࠞ"))
            dialog.ok(l1ll1_opy_ (u"ࠢ࡜ࡅࡒࡐࡔࡘࠠࡧࡨ࠷࠺࠽࠸ࡢ࠵࡟ࡐ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫ࡉ࠰ࡄ࠲ࡆ࠴ࡢࡧࡹࡧࡣ࡬ࡶࠥࡡࡃࡐࡎࡒࡖࠥ࡬ࡦ࠵࠸࠻࠶ࡧ࠺࡝ࡈ࡝ࡆࡓࡑࡕࡒࠡࡨࡩࡇ࠵ࡉ࠰ࡄ࠲ࡠࡹ࡮ࡪࡥ࡜ࡅࡒࡐࡔࡘࠠࡨࡱ࡯ࡨࡢࠦࡐࡓࡑ࡞࠳ࡈࡕࡌࡐࡔࡠࠦࠟ"), l1ll1_opy_ (u"ࠣࡐࡨࡻࠥࡧࡤࡥࡱࡱࠤࡺࡶࡤࡢࡶࡨࠤ࡫ࡵࡵ࡯ࡦࠤࠦࠠ"),l1ll1_opy_ (u"ࠤ࡚ࡩࠥࡽࡩ࡭࡮ࠣࡲࡴࡽࠠࡣࡧࡪ࡭ࡳࠦࡵࡱࡦࡤࡸ࡮ࡴࡧࠡࡶࡲࠤࡻ࡫ࡲࡴ࡫ࡲࡲࠥࠨࠡ")+l1ll_opy_+l1ll1_opy_ (u"ࠥ࠲ࠧࠢ"),l1ll1_opy_ (u"࡙ࠦ࡮ࡩࡴࠢࡰࡥࡾࠦࡴࡢ࡭ࡨࠤࡦࠦࡦࡦࡹࠣࡱ࡮ࡴࡵࡵࡧࡶ࠰ࠥࡪࡥࡱࡧࡱࡨ࡮ࡴࡧࠡࡱࡱࠤࡾࡵࡵࡳࠢࡧࡩࡻ࡯ࡣࡦࠣ࡟ࡲࡕࡲࡥࡢࡵࡨࠤࡷ࡫ࡳࡵࡣࡵࡸࠥࡡࡃࡐࡎࡒࡖࠥ࡬ࡦ࠵࠸࠻࠶ࡧ࠺࡝ࡎ࡝࠲ࡇࡔࡒࡏࡓ࡟࡞ࡇࡔࡒࡏࡓࠢࡩࡪࡈ࠶ࡃ࠱ࡅ࠳ࡡࡦࡿࡦࡢ࡫ࡵࠤࡠ࠵ࡃࡐࡎࡒࡖࡢࡡࡃࡐࡎࡒࡖࠥ࡬ࡦ࠵࠸࠻࠶ࡧ࠺࡝ࡈ࡝࠲ࡇࡔࡒࡏࡓ࡟࡞ࡇࡔࡒࡏࡓࠢࡩࡪࡈ࠶ࡃ࠱ࡅ࠳ࡡࡺ࡯ࡤࡦ࡝࠲ࡇࡔࡒࡏࡓ࡟࡞ࡇࡔࡒࡏࡓࠢࡪࡳࡱࡪ࡝ࠡࡒࡕࡓࡠ࠵ࡃࡐࡎࡒࡖࡢࠦࡵࡱࡱࡱࠤࡺࡶࡤࡢࡶࡨࠤࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࠤࠦࠣ"))
            return True
    except:
        pass
def lold(l11l1_opy_):
	progress = xbmcgui.DialogProgress()
	progress.create(l1ll1_opy_ (u"ࠧࡡࡃࡐࡎࡒࡖࠥ࡬ࡦ࠵࠸࠻࠶ࡧ࠺࡝ࡎ࡝ࡆࡓࡑࡕࡒࠡࡨࡩࡇ࠵ࡉ࠰ࡄ࠲ࡠࡥࡾ࡬ࡡࡪࡴࠣ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫࠺࠶࠹࠴ࡥ࠸ࡢࡍ࡛ࡄࡑࡏࡓࡗࠦࡦࡧࡅ࠳ࡇ࠵ࡉ࠰࡞ࡷ࡬ࡨࡪࡡࡃࡐࡎࡒࡖࠥ࡭࡯࡭ࡦࡠࠤࡕࡘࡏ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠤࠤ"), l1ll1_opy_ (u"ࠨࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠤࠫࠦࡉ࡯ࡵࡷࡥࡱࡲࡩ࡯ࡩࠣࡊ࡮ࡲࡥࡴࠤࠥ"), l1ll1_opy_ (u"ࠧࠡࠩࠦ"), l1ll1_opy_ (u"ࠨࠢࠪࠧ"))
	if os.path.exists(cookiefile):
		request = requests.get(l11l1_opy_, auth=(lolu(), lolp()), verify=False, cookies=load_cookies(cookiefile))
		content = request.content
		code = request.status_code
	else:
		request = requests.get(l11l1_opy_, auth=(lolu(), lolp()), verify=False)
		content = request.content
		code = request.status_code
	progress.close()
	return content
def loldd(url, dest):
    BUFFSIZE = 1024 * 4
    progress = xbmcgui.DialogProgress()
    progress.create(l1ll1_opy_ (u"ࠤ࡞ࡇࡔࡒࡏࡓࠢࡩࡪ࠹࠼࠸࠳ࡤ࠷ࡡࡒࡡࡃࡐࡎࡒࡖࠥ࡬ࡦࡄ࠲ࡆ࠴ࡈ࠶࡝ࡢࡻࡩࡥ࡮ࡸࠠ࡜ࡅࡒࡐࡔࡘࠠࡧࡨ࠷࠺࠽࠸ࡢ࠵࡟ࡊ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫ࡉ࠰ࡄ࠲ࡆ࠴ࡢࡻࡩࡥࡧ࡞ࡇࡔࡒࡏࡓࠢࡪࡳࡱࡪ࡝ࠡࡒࡕࡓࡠ࠵ࡃࡐࡎࡒࡖࡢࠨࠨ"), l1ll1_opy_ (u"ࠥࡈࡴࡽ࡮࡭ࡱࡤࡨ࡮ࡴࡧࠡࠨࠣࡍࡳࡹࡴࡢ࡮࡯࡭ࡳ࡭ࠠࡇ࡫࡯ࡩࡸࠨࠩ"), l1ll1_opy_ (u"ࠫࠬࠪ"), l1ll1_opy_ (u"ࠬ࠭ࠫ"))
    if os.path.exists(cookiefile):
        r = requests.get(url, auth=(lolu(), lolp()), verify=False, cookies=load_cookies(cookiefile), stream=True)
    else:
        r = requests.get(url, auth=(lolu(), lolp()), verify=False, stream=True)
    downloaded = 0
    total = r.headers[l1ll1_opy_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺ࠭࡭ࡧࡱ࡫ࡹ࡮ࠧࠬ")]\
        if l1ll1_opy_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴ࠮࡮ࡨࡲ࡬ࡺࡨࠨ࠭") in r.headers else None
    with open(dest, l1ll1_opy_ (u"ࠨࡹࡥࠫ࠮")) as outfile:
        start_time = time.time()
        for chunk in r.iter_content(chunk_size=BUFFSIZE):
            outfile.write(chunk)
            downloaded += len(chunk)
            text = [l1ll1_opy_ (u"ࠩࡇࡳࡼࡴ࡬ࡰࡣࡧࡩࡩࠦࠥ࠯࠴ࡩࠤࡒ࠭࠯") % (downloaded / 1024.0 / 1024.0)]
            completion = 0
            if total:
                elapsed = time.time() - start_time
                completion = downloaded / float(total)
                if completion > 0:
                    remaining = elapsed / completion - elapsed
                    text.append(l1ll1_opy_ (u"ࠪࡘ࡮ࡳࡥࠡࡴࡨࡱࡦ࡯࡮ࡪࡰࡪ࠾ࠥࠫࡳࠨ࠰") %
                                format_delta(remaining))
            progress.update(int(completion) * 100, l1ll1_opy_ (u"ࠦࡉࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨࠢࠩࠤࡎࡴࡳࡵࡣ࡯ࡰ࡮ࡴࡧࠡࡈ࡬ࡰࡪࡹࠢ࠱"), *text)
            if progress.iscanceled():
                break
    outfile.close()
    progress.close()
def format_delta(s):
	s = int(s)
def ca():
	try:
		if os.path.exists(addonini):
			l1l_opy_ = l1_opy_(lolf(l1ll1_opy_ (u"ࠬࡧࡤࡥࡱࡱࡷ࠳ࡳࡤ࠶ࠩ࠲")))
			if len(l1l_opy_)>1:
				if not l1l_opy_ == l1l1l1_opy_(addonini):
					progress = xbmcgui.DialogProgress()
					progress.create(l1ll1_opy_ (u"ࠨ࡛ࡄࡑࡏࡓࡗࠦࡦࡧ࠶࠹࠼࠷ࡨ࠴࡞ࡏ࡞ࡇࡔࡒࡏࡓࠢࡩࡪࡈ࠶ࡃ࠱ࡅ࠳ࡡࡦࡿࡦࡢ࡫ࡵࠤࡠࡉࡏࡍࡑࡕࠤ࡫࡬࠴࠷࠺࠵ࡦ࠹ࡣࡇ࡜ࡅࡒࡐࡔࡘࠠࡧࡨࡆ࠴ࡈ࠶ࡃ࠱࡟ࡸ࡭ࡩ࡫࡛ࡄࡑࡏࡓࡗࠦࡧࡰ࡮ࡧࡡࠥࡖࡒࡐ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠥ࠳"), l1ll1_opy_ (u"ࠢࡅࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫ࠥࠬࠠࡊࡰࡶࡸࡦࡲ࡬ࡪࡰࡪࠤࡱ࡯࡮࡬ࡧࡧࠤࡦࡪࡤࡰࡰࡶࠤࡩࡧࡴࡢࠤ࠴"), l1ll1_opy_ (u"ࠨࠢࠪ࠵"), l1ll1_opy_ (u"ࠩࠣࠫ࠶"))
					os.remove(addonini)
					f = open(addonini, l1ll1_opy_ (u"ࠪࡻࡧ࠭࠷"))
					if os.path.exists(cookiefile):
						tmpData = requests.get(lolf(l1ll1_opy_ (u"ࠫࡦࡪࡤࡰࡰࡶ࠲࡮ࡴࡩࠨ࠸")), auth=(lolu(), lolp()), verify=False, cookies=load_cookies(cookiefile)).content
					else:
						tmpData = requests.get(lolf(l1ll1_opy_ (u"ࠬࡧࡤࡥࡱࡱࡷ࠳࡯࡮ࡪࠩ࠹")), auth=(lolu(), lolp()), verify=False).content
					f.write(tmpData)
					f.close()
					progress.close()
					return True
	except:
		dialog.ok(l1ll1_opy_ (u"ࠨࡅࡳࡴࡲࡶࠦࠨ࠺"),b(l1ll1_opy_ (u"ࠢࡓ࡚ࡍࡽࡧ࠹ࡉࡩࠤ࠻")),b(l1ll1_opy_ (u"ࠣࡗ࠵࠽ࡹࡠࡘࡓࡱࡤ࡛࠺ࡴࡉࡉࡦ࡯ࡦࡳࡗࡧࡥ࠵ࡍࡺࡧࡳࡣࡨࡦ࠵ࡰ࠵ࡧࡃࡃ࡬ࡤࡋ࡛ࡰࡡ࠳࡮ࡸ࡞ࡾࡈࡨ࡛ࡉࡕࡺࡧࡴࡍࡨ࡜ࡊࡊ࠵࡟ࡓࡆ࠿ࠥ࠼")),l1ll1_opy_ (u"ࠤࠥ࠽"))
		return False
def l1l1l1_opy_(filePath):
	try:
		with open(filePath, l1ll1_opy_ (u"ࠪࡶࡧ࠭࠾")) as may:
			l11_opy_ = hashlib.md5()
			while True:
				data = may.read()
				if not data:
					break
				l11_opy_.update(data)
			return l11_opy_.hexdigest()
	except:
		dialog.ok(l1ll1_opy_ (u"ࠦࡊࡸࡲࡰࡴࠤࠦ࠿"),b(l1ll1_opy_ (u"ࠧࡘࡘࡋࡻࡥ࠷ࡎ࡮ࠢࡀ")),b(l1ll1_opy_ (u"ࠨࡕ࠳࠻ࡷ࡞࡝ࡘ࡯ࡢ࡙࠸ࡲࡎࡎࡤ࡭ࡤࡱࡕ࡬ࡪ࠳ࡋࡸࡥࡱࡨ࡭ࡤ࠳࡮࠳ࡥࡈࡈࡹ࡛࡙ࡉ࡯ࡦ࡝࠵࡯ࡋࡊ࡞ࡵࡨࡇࡖࡩ࡜࠶࡭ࡲ࡙࠳ࡶࡽࡨ࡜࠶ࡨࠣࡁ")),l1ll1_opy_ (u"ࠢࠣࡂ"))
def l1_opy_(url):
	try:
		show_busy_dialog()
		if os.path.exists(cookiefile):
			data = requests.get(url, auth=(lolu(), lolp()), verify=False, cookies=load_cookies(cookiefile)).content
		else:
			data = requests.get(url, auth=(lolu(), lolp()), verify=False).content
		hide_busy_dialog()
		return data
	except:
		dialog.ok(l1ll1_opy_ (u"ࠣࡇࡵࡶࡴࡸࠡࠣࡃ"),b(l1ll1_opy_ (u"ࠤࡕ࡜ࡏࡿࡢ࠴ࡋ࡫ࠦࡄ")),b(l1ll1_opy_ (u"࡙ࠥ࠷࠿ࡴ࡛࡚ࡕࡳࡦ࡝࠵࡯ࡋࡋࡨࡱࡨ࡮ࡒࡩࡧ࠷ࡏࡼࡢ࡮ࡥࡪࡨ࠷ࡲ࠰ࡢࡅࡅࡲ࡟࡞ࡒ࠱ࡣ࡚࠹ࡳࡏࡇࡏࡱ࡝࡛ࡓࡸࡣ࠴ࡘࡷࡍࡖࡃ࠽ࠣࡅ")),l1ll1_opy_ (u"ࠦࠧࡆ"))
		hide_busy_dialog()