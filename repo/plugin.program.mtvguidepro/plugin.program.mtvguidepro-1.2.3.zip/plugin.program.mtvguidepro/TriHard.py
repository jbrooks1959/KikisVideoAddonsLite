# coding: UTF-8
import sys
l1l11_opy_ = sys.version_info [0] == 2
l111l_opy_ = 2048
l111_opy_ = 7
def l1ll1_opy_ (ll_opy_):
	global l11ll_opy_
	l1l1ll_opy_ = ord (ll_opy_ [-1])
	l1l1l_opy_ = ll_opy_ [:-1]
	l1ll1l_opy_ = l1l1ll_opy_ % len (l1l1l_opy_)
	l1l1_opy_ = l1l1l_opy_ [:l1ll1l_opy_] + l1l1l_opy_ [l1ll1l_opy_:]
	if l1l11_opy_:
		l1111_opy_ = unicode () .join ([unichr (ord (char) - l111l_opy_ - (l1lll_opy_ + l1l1ll_opy_) % l111_opy_) for l1lll_opy_, char in enumerate (l1l1_opy_)])
	else:
		l1111_opy_ = str () .join ([chr (ord (char) - l111l_opy_ - (l1lll_opy_ + l1l1ll_opy_) % l111_opy_) for l1lll_opy_, char in enumerate (l1l1_opy_)])
	return eval (l1111_opy_)
import datetime
import time
import sqlite3
import os
import xbmcaddon
import xbmc
import xbmcgui
from source import Program
from source import Channel
import gui
import kappa
import urllib
import re
import urlparse
import base64
import lolol
import threading
import requests
import hashlib
import cfscrape
import sys
import json
ADDON = xbmcaddon.Addon(id=l1ll1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡱࡴࡲ࡫ࡷࡧ࡭࠯࡯ࡷࡺ࡬ࡻࡩࡥࡧࡳࡶࡴ࠭঄"))
addon_id = l1ll1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡲࡵࡳ࡬ࡸࡡ࡮࠰ࡰࡸࡻ࡭ࡵࡪࡦࡨࡴࡷࡵࠧঅ")
profilePath = xbmc.translatePath(ADDON.getAddonInfo(l1ll1_opy_ (u"ࠩࡳࡶࡴ࡬ࡩ࡭ࡧࠪআ")))
HOME        =  ADDON.getAddonInfo(l1ll1_opy_ (u"ࠪࡴࡦࡺࡨࠨই"))
ICON        =  os.path.join(HOME, l1ll1_opy_ (u"ࠫ࡮ࡩ࡯࡯࠰ࡳࡲ࡬࠭ঈ"))
ICON        =  xbmc.translatePath(ICON)
usrsetting  = os.path.join(profilePath)
addonini    = xbmc.translatePath(os.path.join(usrsetting, l1ll1_opy_ (u"ࠬࡧࡤࡥࡱࡱࡷ࠳࡯࡮ࡪࠩউ")))
SOURCE_DB = l1ll1_opy_ (u"࠭ࡳࡰࡷࡵࡧࡪ࠴ࡤࡣࠩঊ")
l1l11l1l1_opy_ = os.path.join(profilePath, l1ll1_opy_ (u"ࠧࡵࡧࡰࡴ࠳ࡪࡢࠨঋ"))
l11lllll1_opy_ = os.path.join(profilePath, l1ll1_opy_ (u"ࠨࡩࡸ࡭ࡩ࡫࠮ࡹ࡯࡯ࠫঌ"))
KEY = l1ll1_opy_ (u"ࠩࡻࡱࡱࡺࡶࠨ঍")
dex = l1ll1_opy_ (u"ࠪࡨࡪࡾࠧ঎")
reboot = l1ll1_opy_ (u"ࠫࡷ࡫ࡢࡰࡱࡷࠫএ")
aftermathtv = l1ll1_opy_ (u"ࠬࡧࡦࡵࡧࡵࡱࡦࡺࡨࡵࡸࠪঐ")
ukturk = l1ll1_opy_ (u"࠭ࡵ࡬ࡶࡸࡶࡰ࠭঑")
sanctuary = l1ll1_opy_ (u"ࠧࡴࡣࡱࡧࡹࡻࡡࡳࡻࠪ঒")
OTTTV     = l1ll1_opy_ (u"ࠨࡑࡗࡘ࡙࡜ࠧও")
suicide21 = l1ll1_opy_ (u"ࠩࡶࡹ࡮ࡩࡩࡥ࠴࠴ࡩࠬঔ")
freeview  = l1ll1_opy_ (u"ࠪࡪࡷ࡫ࡥࡷ࡫ࡨࡻࠬক")
FTV = l1ll1_opy_ (u"ࠫ࡫ࡺࡶࠨখ")
uktvnow = l1ll1_opy_ (u"ࠬࡻ࡫ࡵࡸࡱࡳࡼ࠭গ")
cluiptv = l1ll1_opy_ (u"࠭ࡣ࡭ࡷ࡬ࡴࡹࡼࠧঘ")
suicide = l1ll1_opy_ (u"ࠧࡴࡷ࡬ࡧ࡮ࡪࡥࠨঙ")
projectcypher = l1ll1_opy_ (u"ࠨࡲࡵࡳ࡯࡫ࡣࡵࡥࡼࡴ࡭࡫ࡲࠨচ")
notfilmon = l1ll1_opy_ (u"ࠩࡩ࡭ࡱࡳ࡮ࡰࡶࡲࡲࠬছ")
israelive = l1ll1_opy_ (u"ࠪ࡭ࡸࡸࡡࡦ࡮࡬ࡺࡪ࠭জ")
adriansports = l1ll1_opy_ (u"ࠫࡦࡪࡲࡪࡣࡱࡷࡵࡵࡲࡵࡵࠪঝ")
evolve = l1ll1_opy_ (u"ࠬ࡫ࡶࡰ࡮ࡹࡩࠬঞ")
dialog = xbmcgui.Dialog()
class URLopener(urllib.FancyURLopener):
    version = l1ll1_opy_ (u"ࠨࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡ࡬ࡲ࠻࠺࠻ࠡࡺ࠹࠸࠮ࠦࡁࡱࡲ࡯ࡩ࡜࡫ࡢࡌ࡫ࡷ࠳࠺࠹࠷࠯࠵࠹ࠤ࠭ࡑࡈࡕࡏࡏ࠰ࠥࡲࡩ࡬ࡧࠣࡋࡪࡩ࡫ࡰࠫࠣࡇ࡭ࡸ࡯࡮ࡧ࠲࠹࠻࠴࠰࠯࠴࠼࠶࠹࠴࠸࠸ࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠤট")
class lel(object):
    def __init__(self, i):
        sqlite3.register_adapter(datetime.datetime, self.adapt_datetime)
        sqlite3.register_converter(l1ll1_opy_ (u"ࠧࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪঠ"),     self.convert_datetime)
        databasePath = os.path.join(profilePath, SOURCE_DB)
        self.conn = sqlite3.connect(databasePath, timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.i = i
        self.channels = None
    def convert_datetime(self, ts):
        try:
            return datetime.datetime.fromtimestamp(float(ts))
        except ValueError:
            return None
    def adapt_datetime(self, ts):
        return time.mktime(ts.timetuple())
    def getCurrentProgram(self, channel):
        l1ll1_opy_ (u"ࠣࠤࠥࠑࠏࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࡂࡳࡥࡷࡧ࡭ࠡࡥ࡫ࡥࡳࡴࡥ࡭࠼ࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࡆࡴࡺࡲࡨࠤࡨ࡮ࡡ࡯ࡰࡨࡰ࠿ࠦࡳࡰࡷࡵࡧࡪ࠴ࡃࡩࡣࡱࡲࡪࡲࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢࡃࡶࡪࡺࡵࡳࡰ࠽ࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤড")
        program = None
        now = datetime.datetime.now()
        c = self.conn.cursor()
        try:
            c.execute(l1ll1_opy_ (u"ࠩࡖࡉࡑࡋࡃࡕࠢ࠭ࠤࡋࡘࡏࡎࠢࡳࡶࡴ࡭ࡲࡢ࡯ࡶࠤ࡜ࡎࡅࡓࡇࠣࡧ࡭ࡧ࡮࡯ࡧ࡯ࡁࡄࠦࡁࡏࡆࠣࡷࡴࡻࡲࡤࡧࡀࡃࠥࡇࡎࡅࠢࡶࡸࡦࡸࡴࡠࡦࡤࡸࡪࠦ࠼࠾ࠢࡂࠤࡆࡔࡄࠡࡧࡱࡨࡤࡪࡡࡵࡧࠣࡂࡂࠦ࠿ࠨঢ"),
                    [channel.id, KEY, now, now])
            row = c.fetchone()
            if row:
                program = Program(channel, row[l1ll1_opy_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩণ")], row[l1ll1_opy_ (u"ࠫࡸࡺࡡࡳࡶࡢࡨࡦࡺࡥࠨত")], row[l1ll1_opy_ (u"ࠬ࡫࡮ࡥࡡࡧࡥࡹ࡫ࠧথ")], row[l1ll1_opy_ (u"࠭ࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠫদ")],
                                row[l1ll1_opy_ (u"ࠧࡪ࡯ࡤ࡫ࡪࡥ࡬ࡢࡴࡪࡩࠬধ")], row[l1ll1_opy_ (u"ࠨ࡫ࡰࡥ࡬࡫࡟ࡴ࡯ࡤࡰࡱ࠭ন")], None, row[l1ll1_opy_ (u"ࠩࡶࡩࡦࡹ࡯࡯ࠩ঩")], row[l1ll1_opy_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࠫপ")],
                                row[l1ll1_opy_ (u"ࠫ࡮ࡹ࡟࡮ࡱࡹ࡭ࡪ࠭ফ")], row[l1ll1_opy_ (u"ࠬࡲࡡ࡯ࡩࡸࡥ࡬࡫ࠧব")])
            c.close()
        except:
            pass
        return program
    def getNextProgram(self, program):
        nextProgram = None
        c = self.conn.cursor()
        c.execute(
            l1ll1_opy_ (u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࠪࠡࡈࡕࡓࡒࠦࡰࡳࡱࡪࡶࡦࡳࡳ࡙ࠡࡋࡉࡗࡋࠠࡤࡪࡤࡲࡳ࡫࡬࠾ࡁࠣࡅࡓࡊࠠࡴࡱࡸࡶࡨ࡫࠽ࡀࠢࡄࡒࡉࠦࡳࡵࡣࡵࡸࡤࡪࡡࡵࡧࠣࡂࡂࠦ࠿ࠡࡑࡕࡈࡊࡘࠠࡃ࡛ࠣࡷࡹࡧࡲࡵࡡࡧࡥࡹ࡫ࠠࡂࡕࡆࠤࡑࡏࡍࡊࡖࠣ࠵ࠬভ"),
            [program.channel.id, KEY, program.endDate])
        row = c.fetchone()
        if row:
            nextProgram = Program(program.channel, row[l1ll1_opy_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ম")], row[l1ll1_opy_ (u"ࠨࡵࡷࡥࡷࡺ࡟ࡥࡣࡷࡩࠬয")], row[l1ll1_opy_ (u"ࠩࡨࡲࡩࡥࡤࡢࡶࡨࠫর")], row[l1ll1_opy_ (u"ࠪࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠨ঱")],
                                  row[l1ll1_opy_ (u"ࠫ࡮ࡳࡡࡨࡧࡢࡰࡦࡸࡧࡦࠩল")], row[l1ll1_opy_ (u"ࠬ࡯࡭ࡢࡩࡨࡣࡸࡳࡡ࡭࡮ࠪ঳")], None, row[l1ll1_opy_ (u"࠭ࡳࡦࡣࡶࡳࡳ࠭঴")], row[l1ll1_opy_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࠨ঵")],
                                  row[l1ll1_opy_ (u"ࠨ࡫ࡶࡣࡲࡵࡶࡪࡧࠪশ")], row[l1ll1_opy_ (u"ࠩ࡯ࡥࡳ࡭ࡵࡢࡩࡨࠫষ")])
        c.close()
        return nextProgram
    def getPreviousProgram(self, program):
        previousProgram = None
        c = self.conn.cursor()
        c.execute(
            l1ll1_opy_ (u"ࠪࡗࡊࡒࡅࡄࡖࠣ࠮ࠥࡌࡒࡐࡏࠣࡴࡷࡵࡧࡳࡣࡰࡷࠥ࡝ࡈࡆࡔࡈࠤࡨ࡮ࡡ࡯ࡰࡨࡰࡂࡅࠠࡂࡐࡇࠤࡸࡵࡵࡳࡥࡨࡁࡄࠦࡁࡏࡆࠣࡩࡳࡪ࡟ࡥࡣࡷࡩࠥࡂ࠽ࠡࡁࠣࡓࡗࡊࡅࡓࠢࡅ࡝ࠥࡹࡴࡢࡴࡷࡣࡩࡧࡴࡦࠢࡇࡉࡘࡉࠠࡍࡋࡐࡍ࡙ࠦ࠱ࠨস"),
            [program.channel.id, KEY, program.startDate])
        row = c.fetchone()
        if row:
            previousProgram = Program(program.channel, row[l1ll1_opy_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪহ")], row[l1ll1_opy_ (u"ࠬࡹࡴࡢࡴࡷࡣࡩࡧࡴࡦࠩ঺")], row[l1ll1_opy_ (u"࠭ࡥ࡯ࡦࡢࡨࡦࡺࡥࠨ঻")],
                                      row[l1ll1_opy_ (u"ࠧࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲ়ࠬ")], row[l1ll1_opy_ (u"ࠨ࡫ࡰࡥ࡬࡫࡟࡭ࡣࡵ࡫ࡪ࠭ঽ")], row[l1ll1_opy_ (u"ࠩ࡬ࡱࡦ࡭ࡥࡠࡵࡰࡥࡱࡲࠧা")], None, row[l1ll1_opy_ (u"ࠪࡷࡪࡧࡳࡰࡰࠪি")],
                                      row[l1ll1_opy_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࠬী")], row[l1ll1_opy_ (u"ࠬ࡯ࡳࡠ࡯ࡲࡺ࡮࡫ࠧু")], row[l1ll1_opy_ (u"࠭࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨূ")])
        c.close()
        return previousProgram
    def getPreviousChannel(self, currentChannel):
        idx = self.channels.index(currentChannel)
        idx -= 1
        if idx < 0:
            idx = len(self.channels) - 1
        return self.channels[idx]
    def getNextChannel(self, currentChannel):
        idx = self.channels.index(currentChannel)
        idx += 1
        if idx > len(self.channels) - 1:
            idx = 0
        return self.channels[idx]
    def getCurrentChannel(self, currentChannel, category=l1ll1_opy_ (u"ࠢࡂ࡮࡯ࠤࡈ࡮ࡡ࡯ࡰࡨࡰࡸࠨৃ")):
        try:
            if category == l1ll1_opy_ (u"ࠨࡃ࡯ࡰࠥࡉࡨࡢࡰࡱࡩࡱࡹࠧৄ"):
                idx = self.channels.index(currentChannel)
            else:
                channels = self.getChannelList(category=category)
                idx = channels.index(currentChannel)
        except ValueError:
            gui.ADDON.setSetting(l1ll1_opy_ (u"ࠩ࡯ࡥࡸࡺ࠮ࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ৅"), l1ll1_opy_ (u"ࠥࡅࡱࡲࠠࡄࡪࡤࡲࡳ࡫࡬ࡴࠤ৆"))
            category = l1ll1_opy_ (u"ࠦࡆࡲ࡬ࠡࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠥে")
            idx = self.channels.index(currentChannel)
            return idx
        return idx
    def l11llll11_opy_(self, l11lll1l1_opy_):
        if l11lll1l1_opy_+1 < 0:
            l11lll1l1_opy_ = 0
        if l11lll1l1_opy_+1 > len(self.channels):
            l11lll1l1_opy_ = 0
        return self.channels[l11lll1l1_opy_]
    def getChannelList(self, onlyVisible=True, category=l1ll1_opy_ (u"ࠧࡇ࡬࡭ࠢࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠦৈ")):
        c = self.conn.cursor()
        channelList = list()
        if onlyVisible:
            c.execute(l1ll1_opy_ (u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࠪࠡࡈࡕࡓࡒࠦࡣࡩࡣࡱࡲࡪࡲࡳ࡙ࠡࡋࡉࡗࡋࠠࡴࡱࡸࡶࡨ࡫࠽ࡀࠢࡄࡒࡉࠦࡶࡪࡵ࡬ࡦࡱ࡫࠽ࡀࠢࡄࡒࡉࠦࡣࡩࡰࡦࡥࡹ࡫ࡧࡰࡴࡼࠤࡑࡏࡋࡆࠢࡂࠤࡔࡘࡄࡆࡔࠣࡆ࡞ࠦࡷࡦ࡫ࡪ࡬ࡹ࠭৉"), [KEY, True, l1ll1_opy_ (u"ࠧࠦࠩ৊")+category+l1ll1_opy_ (u"ࠨࠧࠪো")])
        else:
            c.execute(l1ll1_opy_ (u"ࠩࡖࡉࡑࡋࡃࡕࠢ࠭ࠤࡋࡘࡏࡎࠢࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠤ࡜ࡎࡅࡓࡇࠣࡷࡴࡻࡲࡤࡧࡀࡃࠥࡇࡎࡅࠢࡦ࡬ࡳࡩࡡࡵࡧࡪࡳࡷࡿࠠࡍࡋࡎࡉࠥࡅࠠࡐࡔࡇࡉࡗࠦࡂ࡚ࠢࡺࡩ࡮࡭ࡨࡵࠩৌ"), [KEY, l1ll1_opy_ (u"্ࠪࠩࠬ")+category+l1ll1_opy_ (u"ࠫࠪ࠭ৎ")])
        for row in c:
            channel = Channel(row[l1ll1_opy_ (u"ࠬ࡯ࡤࠨ৏")], row[l1ll1_opy_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ৐")], row[l1ll1_opy_ (u"ࠧࡤࡪࡱࡧࡦࡺࡥࡨࡱࡵࡽࠬ৑")], row[l1ll1_opy_ (u"ࠨࡥ࡫ࡲࡦࡪࡤࡰࡰࠪ৒")], row[l1ll1_opy_ (u"ࠩ࡯ࡳ࡬ࡵࠧ৓")], row[l1ll1_opy_ (u"ࠪࡷࡹࡸࡥࡢ࡯ࡢࡹࡷࡲࠧ৔")], row[l1ll1_opy_ (u"ࠫࡻ࡯ࡳࡪࡤ࡯ࡩࠬ৕")], row[l1ll1_opy_ (u"ࠬࡽࡥࡪࡩ࡫ࡸࠬ৖")])
            if (gui.ADDON.getSetting(l1ll1_opy_ (u"࠭ࡤࡦࡺࡷࡩࡷ࠴ࡥ࡯ࡣࡥࡰࡪࡪࠧৗ")) == l1ll1_opy_ (u"ࠧࡵࡴࡸࡩࠬ৘") and dex in channel.chnaddon or
                gui.ADDON.getSetting(l1ll1_opy_ (u"ࠨࡴࡨࡦࡴࡵࡴ࠯ࡧࡱࡥࡧࡲࡥࡥࠩ৙")) == l1ll1_opy_ (u"ࠩࡷࡶࡺ࡫ࠧ৚") and reboot in channel.chnaddon or
                gui.ADDON.getSetting(l1ll1_opy_ (u"ࠪࡓ࡙࡚ࡔࡗ࠰ࡨࡲࡦࡨ࡬ࡦࡦࠪ৛")) == l1ll1_opy_ (u"ࠫࡹࡸࡵࡦࠩড়") and OTTTV in channel.chnaddon or
                gui.ADDON.getSetting(l1ll1_opy_ (u"ࠬࡹࡵࡪࡥ࡬ࡨࡪ࠸࠱࠯ࡧࡱࡥࡧࡲࡥࡥࠩঢ়")) == l1ll1_opy_ (u"࠭ࡴࡳࡷࡨࠫ৞") and suicide21 in channel.chnaddon or
                gui.ADDON.getSetting(l1ll1_opy_ (u"ࠧࡢࡨࡷࡩࡷࡳࡡࡵࡪࡷࡺ࠳࡫࡮ࡢࡤ࡯ࡩࡩ࠭য়")) == l1ll1_opy_ (u"ࠨࡶࡵࡹࡪ࠭ৠ") and aftermathtv in channel.chnaddon or
                gui.ADDON.getSetting(l1ll1_opy_ (u"ࠩࡸ࡯ࡹࡻࡲ࡬࠰ࡨࡲࡦࡨ࡬ࡦࡦࠪৡ")) == l1ll1_opy_ (u"ࠪࡸࡷࡻࡥࠨৢ") and ukturk in channel.chnaddon or
                gui.ADDON.getSetting(l1ll1_opy_ (u"ࠫࡸࡧ࡮ࡤࡶࡸࡥࡷࡿ࠮ࡦࡰࡤࡦࡱ࡫ࡤࠨৣ")) == l1ll1_opy_ (u"ࠬࡺࡲࡶࡧࠪ৤") and sanctuary in channel.chnaddon or
                gui.ADDON.getSetting(l1ll1_opy_ (u"࠭ࡆࡕࡘ࠱ࡩࡳࡧࡢ࡭ࡧࡧࠫ৥")) == l1ll1_opy_ (u"ࠧࡵࡴࡸࡩࠬ০") and FTV in channel.chnaddon or
                gui.ADDON.getSetting(l1ll1_opy_ (u"ࠨࡷ࡮ࡸࡻࡴ࡯ࡸ࠰ࡨࡲࡦࡨ࡬ࡦࡦࠪ১")) == l1ll1_opy_ (u"ࠩࡷࡶࡺ࡫ࠧ২") and uktvnow in channel.chnaddon or
                gui.ADDON.getSetting(l1ll1_opy_ (u"ࠪࡧࡱࡻࡩࡱࡶࡹ࠲ࡪࡴࡡࡣ࡮ࡨࡨࠬ৩")) == l1ll1_opy_ (u"ࠫࡹࡸࡵࡦࠩ৪") and cluiptv in channel.chnaddon or
                gui.ADDON.getSetting(l1ll1_opy_ (u"ࠬࡹࡵࡪࡥ࡬ࡨࡪ࠴ࡥ࡯ࡣࡥࡰࡪࡪࠧ৫")) == l1ll1_opy_ (u"࠭ࡴࡳࡷࡨࠫ৬") and suicide in channel.chnaddon or
                gui.ADDON.getSetting(l1ll1_opy_ (u"ࠧࡱࡴࡲ࡮ࡪࡩࡴࡤࡻࡳ࡬ࡪࡸ࠮ࡦࡰࡤࡦࡱ࡫ࡤࠨ৭")) == l1ll1_opy_ (u"ࠨࡶࡵࡹࡪ࠭৮") and projectcypher in channel.chnaddon or
                gui.ADDON.getSetting(l1ll1_opy_ (u"ࠩࡱࡳࡹ࡬ࡩ࡭࡯ࡲࡲ࠳࡫࡮ࡢࡤ࡯ࡩࡩ࠭৯")) == l1ll1_opy_ (u"ࠪࡸࡷࡻࡥࠨৰ") and notfilmon in channel.chnaddon or
                gui.ADDON.getSetting(l1ll1_opy_ (u"ࠫ࡮ࡹࡲࡢࡧ࡯࡭ࡻ࡫࠮ࡦࡰࡤࡦࡱ࡫ࡤࠨৱ")) == l1ll1_opy_ (u"ࠬࡺࡲࡶࡧࠪ৲") and israelive in channel.chnaddon or
                gui.ADDON.getSetting(l1ll1_opy_ (u"࠭ࡡࡥࡴ࡬ࡥࡳࡹࡰࡰࡴࡷࡷ࠳࡫࡮ࡢࡤ࡯ࡩࡩ࠭৳")) == l1ll1_opy_ (u"ࠧࡵࡴࡸࡩࠬ৴") and adriansports in channel.chnaddon or
                gui.ADDON.getSetting(l1ll1_opy_ (u"ࠨࡧࡹࡳࡱࡼࡥ࠯ࡧࡱࡥࡧࡲࡥࡥࠩ৵")) == l1ll1_opy_ (u"ࠩࡷࡶࡺ࡫ࠧ৶") and evolve in channel.chnaddon or
                gui.ADDON.getSetting(l1ll1_opy_ (u"ࠪࡪࡷ࡫ࡥࡷ࡫ࡨࡻ࠳࡫࡮ࡢࡤ࡯ࡩࡩ࠭৷")) == l1ll1_opy_ (u"ࠫࡹࡸࡵࡦࠩ৸") and freeview in channel.chnaddon or
                gui.ADDON.getSetting(l1ll1_opy_ (u"ࠬࡧ࡬࡭ࡨࡵࡩࡪࡧࡤࡥࡱࡱࡷ࠳࡫࡮ࡢࡤ࡯ࡩࡩ࠭৹")) == l1ll1_opy_ (u"࠭ࡴࡳࡷࡨࠫ৺") and (ukturk in channel.chnaddon or sanctuary in channel.chnaddon or FTV in channel.chnaddon or uktvnow in channel.chnaddon or
                    cluiptv in channel.chnaddon or suicide in channel.chnaddon or projectcypher in channel.chnaddon or notfilmon in channel.chnaddon or israelive in channel.chnaddon or adriansports in channel.chnaddon or evolve in channel.chnaddon or freeview in channel.chnaddon) or
                gui.ADDON.getSetting(l1ll1_opy_ (u"ࠧࡢ࡮࡯ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷ࠳࡫࡮ࡢࡤ࡯ࡩࡩ࠭৻")) == l1ll1_opy_ (u"ࠨࡶࡵࡹࡪ࠭ৼ")):
                channelList.append(channel)
        c.close()
        return channelList
    def getWeight(self, channel):
        return channel.weight
    def close(self):
        try:
            if self.conn:
                self.conn.rollback()
        except sqlite3.OperationalError:
            pass
        if self.conn:
            self.conn.close()
    def setchns(self):
        c = self.conn.cursor()
        if gui.ADDON.getSetting(l1ll1_opy_ (u"ࠩࡦ࡬ࡳࡵࡲࡥࡧࡵࠫ৽")) == l1ll1_opy_ (u"ࠪࡅ࠲ࡠࠧ৾"):
            c.execute(l1ll1_opy_ (u"ࠦࡈࡘࡅࡂࡖࡈࠤ࡙ࡋࡍࡑࡑࡕࡅࡗ࡟ࠠࡕࡃࡅࡐࡊࠦࡡ࡭ࡲ࡫ࡥ࡙࡫࡭ࡱࠢࡤࡷࠥ࡝ࡉࡕࡊࠣࡻࡹ࡬ࡉࡩࡣࡷࡩ࡞ࡵࡵࠡࡃࡖࠤ࠭ࡹࡥ࡭ࡧࡦࡸࠥ࡯ࡤ࠭ࠢࡷ࡭ࡹࡲࡥ࠭ࠢࡺࡩ࡮࡭ࡨࡵ࠮ࠣࠬࡘࡋࡌࡆࡅࡗࠤࡈࡕࡕࡏࡖࠫ࠮࠮ࠦ࠭ࠡ࠳ࠣࡊࡗࡕࡍࠡࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠣࡥࠥ࡝ࡈࡆࡔࡈࠤࡦ࠴ࡴࡪࡶ࡯ࡩࠥࡂ࠽ࠡࡤ࠱ࡸ࡮ࡺ࡬ࡦࠢࡆࡓࡑࡒࡁࡕࡇࠣࡒࡔࡉࡁࡔࡇࠬࠤࡦࡹࠠࡳࡱࡺࡒࡺࡳࡢࡦࡴࠣࡪࡷࡵ࡭ࠡࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠣࡦࠥࡕࡲࡥࡧࡵࠤࡇࡿࠠࡵ࡫ࡷࡰࡪࠦࡃࡐࡎࡏࡅ࡙ࡋࠠࡏࡑࡆࡅࡘࡋࠠࡂࡕࡆ࠭ࠥࡹࡥ࡭ࡧࡦࡸࠥ࠰ࠠࡧࡴࡲࡱࠥࡽࡴࡧࡋ࡫ࡥࡹ࡫࡙ࡰࡷࠥ৿"))
            self.conn.commit()
            c.execute(l1ll1_opy_ (u"࡛ࠧࡐࡅࡃࡗࡉࠥࡉࡨࡢࡰࡱࡩࡱࡹࠠࡔࡇࡗࠤࡼ࡫ࡩࡨࡪࡷࠤࡂࠦࠨࡴࡧ࡯ࡩࡨࡺࠠࡳࡱࡺࡒࡺࡳࡢࡦࡴࠣࡪࡷࡵ࡭ࠡࡣ࡯ࡴ࡭ࡧࡔࡦ࡯ࡳࠤࡼ࡮ࡥࡳࡧࠣ࡭ࡩࠦ࠽ࠡࡅ࡫ࡥࡳࡴࡥ࡭ࡵ࠱࡭ࡩ࠯ࠢ਀"))
            self.conn.commit()
            c.execute(l1ll1_opy_ (u"ࠨࡄࡓࡑࡓࠤ࡙ࡇࡂࡍࡇࠣࡥࡱࡶࡨࡢࡖࡨࡱࡵࠨਁ"))
            self.conn.commit()
        if gui.ADDON.getSetting(l1ll1_opy_ (u"ࠧࡤࡪࡱࡳࡷࡪࡥࡳࠩਂ")) == l1ll1_opy_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩਃ"):
            c.execute(l1ll1_opy_ (u"ࠤࡘࡔࡉࡇࡔࡆࠢࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠤࡘࡋࡔࠡࡹࡨ࡭࡬࡮ࡴࠡ࠿ࠣࡶࡴࡽࡩࡥࠢ࠰ࠤ࠶ࠨ਄"))
            self.conn.commit()
        c.close()
    def updatechnlist(self):
        self.channels = self.getChannelList()
    def l11ll1_opy_(self,l1l11111l_opy_):
        c = self.conn.cursor()
        c.execute(l1ll1_opy_ (u"ࠪࡗࡊࡒࡅࡄࡖࠣ࠮ࠥࡌࡒࡐࡏࠣࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠥ࡝ࡈࡆࡔࡈࠤࡸࡵࡵࡳࡥࡨࡁࡄࠦࡁࡏࡆࠣ࡭ࡩࡃ࠿ࠨਅ"), [KEY, l1l11111l_opy_])
        for row in c:
            channel = Channel(row[l1ll1_opy_ (u"ࠫ࡮ࡪࠧਆ")], row[l1ll1_opy_ (u"ࠬࡺࡩࡵ࡮ࡨࠫਇ")], row[l1ll1_opy_ (u"࠭ࡣࡩࡰࡦࡥࡹ࡫ࡧࡰࡴࡼࠫਈ")], row[l1ll1_opy_ (u"ࠧࡤࡪࡱࡥࡩࡪ࡯࡯ࠩਉ")], row[l1ll1_opy_ (u"ࠨ࡮ࡲ࡫ࡴ࠭ਊ")], row[l1ll1_opy_ (u"ࠩࡶࡸࡷ࡫ࡡ࡮ࡡࡸࡶࡱ࠭਋")], row[l1ll1_opy_ (u"ࠪࡺ࡮ࡹࡩࡣ࡮ࡨࠫ਌")], row[l1ll1_opy_ (u"ࠫࡼ࡫ࡩࡨࡪࡷࠫ਍")])
        c.close()
        return channel
    def l1l111111_opy_(self,l1l11111l_opy_,programTitle):
        c = self.conn.cursor()
        c.execute(l1ll1_opy_ (u"ࠬࡊࡅࡍࡇࡗࡉࠥ࡬ࡲࡰ࡯ࠣࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡵ࡛ࠣࡍࡋࡒࡆࠢࡦ࡬ࡦࡴ࡮ࡦ࡮ࡀࡃࠥࡇࡎࡅࠢࡳࡶࡴ࡭ࡲࡢ࡯ࡢࡸ࡮ࡺ࡬ࡦ࠿ࡂࠫ਎"), [l1l11111l_opy_,programTitle])
        c.close()
    def setCustomStreamUrl(self, channel, stream_url):
        if stream_url is not None:
            c = self.conn.cursor()
            c.execute(l1ll1_opy_ (u"ࠨࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡨࡻࡳࡵࡱࡰࡣࡸࡺࡲࡦࡣࡰࡣࡺࡸ࡬࡙ࠡࡋࡉࡗࡋࠠࡤࡪࡤࡲࡳ࡫࡬࠾ࡁࠥਏ"), [channel.id])
            c.execute(l1ll1_opy_ (u"ࠢࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥࡩࡵࡴࡶࡲࡱࡤࡹࡴࡳࡧࡤࡱࡤࡻࡲ࡭ࠪࡦ࡬ࡦࡴ࡮ࡦ࡮࠯ࠤࡸࡺࡲࡦࡣࡰࡣࡺࡸ࡬࡙ࠪࠢࡅࡑ࡛ࡅࡔࠪࡂ࠰ࠥࡅࠩࠣਐ"),
                      [channel.id, stream_url.decode(l1ll1_opy_ (u"ࠨࡷࡷࡪ࠲࠾ࠧ਑"), l1ll1_opy_ (u"ࠩ࡬࡫ࡳࡵࡲࡦࠩ਒"))])
            self.conn.commit()
            c.close()
    def deleteCustomStreamUrl(self, channel):
        c = self.conn.cursor()
        c.execute(l1ll1_opy_ (u"ࠥࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࡥࡸࡷࡹࡵ࡭ࡠࡵࡷࡶࡪࡧ࡭ࡠࡷࡵࡰࠥ࡝ࡈࡆࡔࡈࠤࡨ࡮ࡡ࡯ࡰࡨࡰࡂࡅࠢਓ"), [channel.id])
        self.conn.commit()
        c.close()
    def getStreamUrl(self, channel):
        customStreamUrl = self.getCustomStreamUrl(channel)
        if customStreamUrl:
            customStreamUrl = customStreamUrl.encode(l1ll1_opy_ (u"ࠫࡺࡺࡦ࠮࠺ࠪਔ"), l1ll1_opy_ (u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬਕ"))
            return customStreamUrl
        elif channel.isPlayable():
            streamUrl = channel.streamUrl.encode(l1ll1_opy_ (u"࠭ࡵࡵࡨ࠰࠼ࠬਖ"), l1ll1_opy_ (u"ࠧࡪࡩࡱࡳࡷ࡫ࠧਗ"))
            return streamUrl
        return None
    def getCustomStreamUrl(self, channel):
        c = self.conn.cursor()
        c.execute(l1ll1_opy_ (u"ࠣࡕࡈࡐࡊࡉࡔࠡࡵࡷࡶࡪࡧ࡭ࡠࡷࡵࡰࠥࡌࡒࡐࡏࠣࡧࡺࡹࡴࡰ࡯ࡢࡷࡹࡸࡥࡢ࡯ࡢࡹࡷࡲࠠࡘࡊࡈࡖࡊࠦࡣࡩࡣࡱࡲࡪࡲ࠽ࡀࠤਘ"), [channel.id])
        stream_url = c.fetchone()
        c.close()
        if stream_url:
            return stream_url[0]
        else:
            return None
    def removeNotification(self, program):
        c = self.conn.cursor()
        c.execute(l1ll1_opy_ (u"ࠤࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡹࠠࡘࡊࡈࡖࡊࠦࡣࡩࡣࡱࡲࡪࡲ࠽ࡀࠢࡄࡒࡉࠦࡰࡳࡱࡪࡶࡦࡳ࡟ࡵ࡫ࡷࡰࡪࡃ࠿ࠡࡃࡑࡈࠥࡹ࡯ࡶࡴࡦࡩࡂࡅࠢਙ"),
                  [program.channel.id, program.title, KEY])
        self.conn.commit()
        c.close()
    def getCustomLineUp(self):
        c = self.conn.cursor()
        d = xbmcgui.DialogProgressBG()
        d.create(l1ll1_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫࠺࠶࠹࠴ࡥ࠸ࡢࡓ࡛࠰ࡅࡒࡐࡔࡘ࡝࡜ࡅࡒࡐࡔࡘࠠࡧࡨࡆ࠴ࡈ࠶ࡃ࠱࡟ࡤࡽ࡫ࡧࡩࡳࠢ࡞࠳ࡈࡕࡌࡐࡔࡠ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫࠺࠶࠹࠴ࡥ࠸ࡢࡍ࡛࠰ࡅࡒࡐࡔࡘ࡝࡜ࡅࡒࡐࡔࡘࠠࡧࡨࡆ࠴ࡈ࠶ࡃ࠱࡟ࡸ࡭ࡩ࡫࡛࠰ࡅࡒࡐࡔࡘ࡝࡜ࡅࡒࡐࡔࡘࠠࡨࡱ࡯ࡨࡢࠦࡐࡓࡑ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࡠࡉࡏࡍࡑࡕࠤࡼ࡮ࡩࡵࡧࡠ࠱࡙ࠥࡴࡰࡴ࡬ࡲ࡬ࠦࡃࡶࡵࡷࡳࡲࠦࡃࡩࡣࡱࡲࡪࡲࠠࡍ࡫ࡱࡩࡺࡶࠠࡅࡣࡷࡥࠥࡺ࡯ࠡࡃࡦࡧࡴࡻ࡮ࡵ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪਚ"), l1ll1_opy_ (u"ࠦࡘࡺࡡࡳࡶ࡬ࡲ࡬࠴࠮࠯ࠤਛ"))
        c.execute(l1ll1_opy_ (u"࡙ࠧࡅࡍࡇࡆࡘࠥ࡯ࡤ࠭ࡹࡨ࡭࡬࡮ࡴ࠭ࡸ࡬ࡷ࡮ࡨ࡬ࡦࠢࡩࡶࡴࡳࠠࡤࡪࡤࡲࡳ࡫࡬ࡴࠤਜ"))
        data = c.fetchall()
        c.close()
        l1l1l11ll_opy_ = str(time.time())
        l1ll11lll_opy_ = []
        l1ll11lll_opy_.append((l1ll1_opy_ (u"ࠨࡔࡪ࡯ࡨࠤ࡚ࡶࡤࡢࡶࡨࡨࠧਝ").encode(l1ll1_opy_ (u"ࠢࡩࡧࡻࠦਞ")), l1l1l11ll_opy_, 0))
        total = len(data) - 1
        l1l11l1ll_opy_ = 0
        for row in data:
            t = (row[l1ll1_opy_ (u"ࠨ࡫ࡧࠫਟ")].encode(l1ll1_opy_ (u"ࠤ࡫ࡩࡽࠨਠ")), row[l1ll1_opy_ (u"ࠪࡻࡪ࡯ࡧࡩࡶࠪਡ")], row[l1ll1_opy_ (u"ࠫࡻ࡯ࡳࡪࡤ࡯ࡩࠬਢ")])
            l1ll11lll_opy_.append(t)
            l1l11l1ll_opy_ += 1
            percent = 100.0 * l1l11l1ll_opy_ / total
            d.update(int(percent), message=l1ll1_opy_ (u"࡛ࠬࡰ࡭ࡱࡤࡨ࡮ࡴࡧࠡࠩਣ")+row[l1ll1_opy_ (u"࠭ࡩࡥࠩਤ")])
        gui.ADDON.setSetting(l1ll1_opy_ (u"ࠧࡢࡥࡦࡰࡺࡲࡡࡴࡶࡸࡴࡩࡧࡴࡦࠩਥ"), l1l1l11ll_opy_)
        d.update(100, message=l1ll1_opy_ (u"ࠣࡕࡷࡳࡷ࡯࡮ࡨࠢࡆࡹࡸࡺ࡯࡮ࠢࡆ࡬ࡦࡴ࡮ࡦ࡮ࠣࡐ࡮ࡴࡥࡶࡲࠣࡈࡦࡺࡡࠡࡶࡲࠤࡆࡩࡣࡰࡷࡱࡸࠥࡉ࡯࡮ࡲ࡯ࡩࡹ࡫ࡤࠢࠤਦ"))
        d.close()
        dialog.notification(l1ll1_opy_ (u"ࠩࠪਧ"), l1ll1_opy_ (u"ࠪࡗࡹࡵࡲࡪࡰࡪࠤࡈࡻࡳࡵࡱࡰࠤࡈ࡮ࡡ࡯ࡰࡨࡰࠥࡒࡩ࡯ࡧࡸࡴࡡࡴࡄࡢࡶࡤࠤࡹࡵࠠࡂࡥࡦࡳࡺࡴࡴࠡࡅࡲࡱࡵࡲࡥࡵࡧࡧࠥࠬਨ"), ICON, 4500)
        return json.dumps(l1ll11lll_opy_)
    def setCustomLineUp(self,data):
        c = self.conn.cursor()
        d = xbmcgui.DialogProgressBG()
        d.create(l1ll1_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤ࡫࡬࠴࠷࠺࠵ࡦ࠹ࡣࡍ࡜࠱ࡆࡓࡑࡕࡒ࡞࡝ࡆࡓࡑࡕࡒࠡࡨࡩࡇ࠵ࡉ࠰ࡄ࠲ࡠࡥࡾ࡬ࡡࡪࡴࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࡠࡉࡏࡍࡑࡕࠤ࡫࡬࠴࠷࠺࠵ࡦ࠹ࡣࡇ࡜࠱ࡆࡓࡑࡕࡒ࡞࡝ࡆࡓࡑࡕࡒࠡࡨࡩࡇ࠵ࡉ࠰ࡄ࠲ࡠࡹ࡮ࡪࡥ࡜࠱ࡆࡓࡑࡕࡒ࡞࡝ࡆࡓࡑࡕࡒࠡࡩࡲࡰࡩࡣࠠࡑࡔࡒ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࡡࡃࡐࡎࡒࡖࠥࡽࡨࡪࡶࡨࡡ࠲ࠦࡉ࡮ࡲࡲࡶࡹ࡯࡮ࡨࠢࡆ࡬ࡦࡴ࡮ࡦ࡮ࠣࡐ࡮ࡴࡥࡶࡲࠣࡈࡦࡺࡡࠡࡨࡵࡳࡲࠦࡁࡤࡥࡲࡹࡳࡺ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ਩"), l1ll1_opy_ (u"࡙ࠧࡴࡢࡴࡷ࡭ࡳ࡭࠮࠯࠰ࠥਪ"))
        total = len(data) - 1
        l1l11l1ll_opy_ = 0
        try:
            for id,weight,visible in data:
                id = id.decode(l1ll1_opy_ (u"ࠨࡨࡦࡺࠥਫ"))
                if id == l1ll1_opy_ (u"ࠧࡕ࡫ࡰࡩ࡛ࠥࡰࡥࡣࡷࡩࡩ࠭ਬ"):
                    time = weight
                    continue
                c.execute(l1ll1_opy_ (u"ࠣࡗࡓࡈࡆ࡚ࡅࠡࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠣࡗࡊ࡚ࠠࡸࡧ࡬࡫࡭ࡺ࠽ࡀ࠮ࠣࡺ࡮ࡹࡩࡣ࡮ࡨࡁࡄࠦࡗࡉࡇࡕࡉࠥ࡯ࡤ࠾ࡁࠥਭ"), [weight, visible, id])
                self.conn.commit()
                l1l11l1ll_opy_ += 1
                percent = 100.0 * l1l11l1ll_opy_ / total
                d.update(int(percent), message=l1ll1_opy_ (u"ࠩࡌࡱࡵࡵࡲࡵ࡫ࡱ࡫ࠥ࠭ਮ")+id)
            c.close()
            gui.ADDON.setSetting(l1ll1_opy_ (u"ࠪࡧ࡭ࡴ࡯ࡳࡦࡨࡶࠬਯ"), l1ll1_opy_ (u"ࠦࡈࡻࡳࡵࡱࡰࠦਰ"))
            gui.ADDON.setSetting(l1ll1_opy_ (u"ࠬࡧࡣࡤ࡮ࡸࡰࡦࡹࡴࡶࡲࡧࡥࡹ࡫ࠧ਱"), time)
            d.update(100, message=l1ll1_opy_ (u"ࠨࡉ࡮ࡲࡲࡶࡹ࡯࡮ࡨࠢࡆࡹࡸࡺ࡯࡮ࠢࡆ࡬ࡦࡴ࡮ࡦ࡮ࠣࡐ࡮ࡴࡥࡶࡲࠣࡈࡦࡺࡡࠡࡨࡵࡳࡲࠦࡁࡤࡥࡲࡹࡳࡺࠠࡄࡱࡰࡴࡱ࡫ࡴࡦࡦࠤࠦਲ"))
            d.close()
            dialog.notification(l1ll1_opy_ (u"ࠧࠨਲ਼"), l1ll1_opy_ (u"ࠨࡋࡰࡴࡴࡸࡴࡪࡰࡪࠤࡈࡻࡳࡵࡱࡰࠤࡈ࡮ࡡ࡯ࡰࡨࡰࠥࡒࡩ࡯ࡧࡸࡴࡡࡴࡄࡢࡶࡤࠤ࡫ࡸ࡯࡮ࠢࡄࡧࡨࡵࡵ࡯ࡶࠣࡇࡴࡳࡰ࡭ࡧࡷࡩࡩࠧࠧ਴"), ICON, 4500)
        except:
            c.close()
            d.close()
    def programsdata(self):
        if not os.path.exists(l1l11l1l1_opy_):
            os.remove(l11lllll1_opy_)
            dialog.ok(l1ll1_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡩࡪ࠹࠼࠸࠳ࡤ࠷ࡡࡒࡡࡃࡐࡎࡒࡖࠥ࡬ࡦࡄ࠲ࡆ࠴ࡈ࠶࡝ࡢࡻࡩࡥ࡮ࡸࠠ࡜ࡅࡒࡐࡔࡘࠠࡧࡨ࠷࠺࠽࠸ࡢ࠵࡟ࡊ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫ࡉ࠰ࡄ࠲ࡆ࠴ࡢࡻࡩࡥࡧ࡞ࡇࡔࡒࡏࡓࠢࡪࡳࡱࡪ࡝ࠡࡒࡕࡓࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ਵ"), l1ll1_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝࡜ࡄࡠࡉࡷࡸ࡯ࡳࠢࡵࡩࡦࡪࡩ࡯ࡩࠣࡨࡦࡺࡡࠢ࡝࠲ࡆࡢࡡ࠯ࡄࡑࡏࡓࡗࡣࠧਸ਼"), l1ll1_opy_ (u"ࠫࠬ਷"), l1ll1_opy_ (u"ࠬࡖ࡬ࡦࡣࡶࡩࠥ࡫ࡸࡪࡶࠣ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫࠺࠶࠹࠴ࡥ࠸ࡢࡓ࡛ࡄࡑࡏࡓࡗࠦࡦࡧࡅ࠳ࡇ࠵ࡉ࠰࡞ࡣࡼࡪࡦ࡯ࡲࠡ࡝ࡆࡓࡑࡕࡒࠡࡨࡩ࠸࠻࠾࠲ࡣ࠶ࡠࡋࡠࡉࡏࡍࡑࡕࠤ࡫࡬ࡃ࠱ࡅ࠳ࡇ࠵ࡣࡵࡪࡦࡨ࡟ࡈࡕࡌࡐࡔࠣ࡫ࡴࡲࡤ࡞ࠢࡓࡖࡔࡡ࠯ࡄࡑࡏࡓࡗࡣࠠࡢࡰࡧࠤࡷ࡫࠭࡭ࡣࡸࡲࡨ࡮ࠬࠡࡶࡲࠤ࡫ࡵࡲࡤࡧࠣࡨࡦࡺࡡࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠤࠫਸ"))
            raise ValueError(l1ll1_opy_ (u"࠭ࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠣࠣࡒࡪ࡫ࡤࠡࡶࡲࠤ࡫ࡵࡲࡤࡧࠣࡨࡦࡺࡡࠡࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࠫਹ"))
        c = self.conn.cursor()
        c.execute(l1ll1_opy_ (u"ࠢࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡳࡡࡪࡰ࠱ࡴࡷࡵࡧࡳࡣࡰࡷࡀࠨ਺"))
        self.conn.commit()
        c.execute(l1ll1_opy_ (u"ࠣࡃࡗࡘࡆࡉࡈࠡࡆࡄࡘࡆࡈࡁࡔࡇࠣࠫࠪࡹࠧࠡࡃࡖࠤࡹ࡫࡭ࡱࡦࡥ࠿ࠧ਻") % (l1l11l1l1_opy_))
        c.execute(l1ll1_opy_ (u"ࠤࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠ࡮ࡣ࡬ࡲ࠳ࡶࡲࡰࡩࡵࡥࡲࡹࠠࡔࡇࡏࡉࡈ࡚ࠠࠫࠢࡉࡖࡔࡓࠠࡵࡧࡰࡴࡩࡨ࠮ࡱࡴࡲ࡫ࡷࡧ࡭ࡴ࠽਼ࠥ"))
        c.execute(l1ll1_opy_ (u"ࠥࡈࡊ࡚ࡁࡄࡊࠣࡈࡆ࡚ࡁࡃࡃࡖࡉࠥ࠭ࡴࡦ࡯ࡳࡨࡧ࠭࠻ࠣ਽"))
        self.conn.commit()
        c.close()
        try:
            os.remove(l1l11l1l1_opy_)
        except:
            pass
class hm(object):
    def __init__(self, i):
        self.l1l1111l1_opy_ = i
        self.hm = gui
    def _channelUp(self):
        channel = self.l1l1111l1_opy_.kek.getNextChannel(self.l1l1111l1_opy_.currentChannel)
        program = self.l1l1111l1_opy_.kek.getCurrentProgram(channel)
        if not self.playChannel(channel, program, True):
            result = self.l1l1111l1_opy_.streamingService.detectStream(channel)
            if not result:
                self.l1l1111l1_opy_._showContextMenu(program)
            elif type(result) == str:
                self.l1l1111l1_opy_.database.setCustomStreamUrl(channel, result)
                self.playChannel(channel, program)
            else:
                result = sorted(result, key=self.l11llllll_opy_)
                result = sorted(result, key=self.l1ll11l11_opy_)
                if channel.title == l1ll1_opy_ (u"ࠫࡊࡖࡌࠨਾ") or channel.title == l1ll1_opy_ (u"ࠬࡔࡆࡍࠩਿ") or channel.title == l1ll1_opy_ (u"࠭ࡎࡃࡃࠪੀ") or channel.title == l1ll1_opy_ (u"ࠧࡏࡊࡏࠫੁ") or channel.title == l1ll1_opy_ (u"ࠨࡒࡓ࡚ࠬੂ") or channel.title == l1ll1_opy_ (u"ࠩࡑࡆࡆ࠭੃") or channel.title == l1ll1_opy_ (u"ࠪ࠶࠹࠽ࠧ੄") or channel.title == l1ll1_opy_ (u"ࠫࡒࡒࡂࠨ੅") or channel.title == l1ll1_opy_ (u"ࠬࡓࡕࡔࡋࡆࠤࡈࡎࡏࡊࡅࡈࠫ੆") or len(channel.title) > 13:
                    selection = kappa.iI1(l1ll1_opy_ (u"ࠨ࡛ࡃ࡟ࡉࡳࡺࡴࡤࠡ࡯ࡸࡰࡹ࡯ࡰ࡭ࡧࠣࡷࡴࡻࡲࡤࡧࡶࠤ࡫ࡵࡲࠡࡶ࡫࡭ࡸࠦࡣࡩࡣࡱࡲࡪࡲ࠮ࠡࡒ࡯ࡩࡦࡹࡥࠡࡵࡨࡰࡪࡩࡴࠡࡱࡱࡩ࠳ࡡ࠯ࡃ࡟ࠥੇ"), result)
                    if selection is not None:
                        if selection == -1:
                            pass
                        else:
                            self.l1l1111l1_opy_.database.setCustomStreamUrl(channel, selection)
                            self.playChannel(channel, program)
                else:
                    d = self.hm.ChooseStreamAddonDialog(result)
                    d.doModal()
                    if d.stream is not None:
                        self.l1l1111l1_opy_.database.setCustomStreamUrl(channel, d.stream)
                        self.playChannel(channel, program)
    def _channelDown(self):
        channel = self.l1l1111l1_opy_.kek.getPreviousChannel(self.l1l1111l1_opy_.currentChannel)
        program = self.l1l1111l1_opy_.kek.getCurrentProgram(channel)
        if not self.playChannel(channel, program, True):
            result = self.l1l1111l1_opy_.streamingService.detectStream(channel)
            if not result:
                self.l1l1111l1_opy_._showContextMenu(program)
            elif type(result) == str:
                self.l1l1111l1_opy_.database.setCustomStreamUrl(channel, result)
                self.playChannel(channel, program)
            else:
                result = sorted(result, key=self.l11llllll_opy_)
                result = sorted(result, key=self.l1ll11l11_opy_)
                if channel.title == l1ll1_opy_ (u"ࠧࡆࡒࡏࠫੈ") or channel.title == l1ll1_opy_ (u"ࠨࡐࡉࡐࠬ੉") or channel.title == l1ll1_opy_ (u"ࠩࡑࡆࡆ࠭੊") or channel.title == l1ll1_opy_ (u"ࠪࡒࡍࡒࠧੋ") or channel.title == l1ll1_opy_ (u"ࠫࡕࡖࡖࠨੌ") or channel.title == l1ll1_opy_ (u"ࠬࡔࡂࡂ੍ࠩ") or channel.title == l1ll1_opy_ (u"࠭࠲࠵࠹ࠪ੎") or channel.title == l1ll1_opy_ (u"ࠧࡎࡎࡅࠫ੏") or channel.title == l1ll1_opy_ (u"ࠨࡏࡘࡗࡎࡉࠠࡄࡊࡒࡍࡈࡋࠧ੐") or len(channel.title) > 13:
                    selection = kappa.iI1(l1ll1_opy_ (u"ࠤ࡞ࡆࡢࡌ࡯ࡶࡰࡧࠤࡲࡻ࡬ࡵ࡫ࡳࡰࡪࠦࡳࡰࡷࡵࡧࡪࡹࠠࡧࡱࡵࠤࡹ࡮ࡩࡴࠢࡦ࡬ࡦࡴ࡮ࡦ࡮࠱ࠤࡕࡲࡥࡢࡵࡨࠤࡸ࡫࡬ࡦࡥࡷࠤࡴࡴࡥ࠯࡝࠲ࡆࡢࠨੑ"), result)
                    if selection is not None:
                        if selection == -1:
                            pass
                        else:
                            self.l1l1111l1_opy_.database.setCustomStreamUrl(channel, selection)
                            self.playChannel(channel, program)
                else:
                    d = self.hm.ChooseStreamAddonDialog(result)
                    d.doModal()
                    if d.stream is not None:
                        self.l1l1111l1_opy_.database.setCustomStreamUrl(channel, d.stream)
                        self.playChannel(channel, program)
    def _previouschannel(self):
        if self.l1l1111l1_opy_.previouschannel is not None:
            previouschannel     = self.l1l1111l1_opy_.previouschannel
            l1ll111ll_opy_ = self.l1l1111l1_opy_.kek.getCurrentProgram(previouschannel)
            if not self.playChannel(previouschannel, l1ll111ll_opy_, True):
                result = self.l1l1111l1_opy_.streamingService.detectStream(previouschannel)
                if not result:
                    self.l1l1111l1_opy_._showContextMenu(l1ll111ll_opy_)
                elif type(result) == str:
                    self.l1l1111l1_opy_.database.setCustomStreamUrl(previouschannel, result)
                    self.playChannel(previouschannel, l1ll111ll_opy_)
                else:
                    result = sorted(result, key=self.l11llllll_opy_)
                    result = sorted(result, key=self.l1ll11l11_opy_)
                    if previouschannel.title == l1ll1_opy_ (u"ࠪࡉࡕࡒࠧ੒") or previouschannel.title == l1ll1_opy_ (u"ࠫࡓࡌࡌࠨ੓") or previouschannel.title == l1ll1_opy_ (u"ࠬࡔࡂࡂࠩ੔") or previouschannel.title == l1ll1_opy_ (u"࠭ࡎࡉࡎࠪ੕") or previouschannel.title == l1ll1_opy_ (u"ࠧࡑࡒ࡙ࠫ੖") or previouschannel.title == l1ll1_opy_ (u"ࠨࡐࡅࡅࠬ੗") or previouschannel.title == l1ll1_opy_ (u"ࠩ࠵࠸࠼࠭੘") or previouschannel.title == l1ll1_opy_ (u"ࠪࡑࡑࡈࠧਖ਼") or previouschannel.title == l1ll1_opy_ (u"ࠫࡒ࡛ࡓࡊࡅࠣࡇࡍࡕࡉࡄࡇࠪਗ਼") or len(previouschannel.title) > 13:
                        selection = kappa.iI1(l1ll1_opy_ (u"ࠧࡡࡂ࡞ࡈࡲࡹࡳࡪࠠ࡮ࡷ࡯ࡸ࡮ࡶ࡬ࡦࠢࡶࡳࡺࡸࡣࡦࡵࠣࡪࡴࡸࠠࡵࡪ࡬ࡷࠥࡩࡨࡢࡰࡱࡩࡱ࠴ࠠࡑ࡮ࡨࡥࡸ࡫ࠠࡴࡧ࡯ࡩࡨࡺࠠࡰࡰࡨ࠲ࡠ࠵ࡂ࡞ࠤਜ਼"), result)
                        if selection is not None:
                            if selection == -1:
                                pass
                            else:
                                self.l1l1111l1_opy_.database.setCustomStreamUrl(previouschannel, selection)
                                self.playChannel(previouschannel, l1ll111ll_opy_)
                    else:
                        d = self.hm.ChooseStreamAddonDialog(result)
                        d.doModal()
                        if d.stream is not None:
                            self.l1l1111l1_opy_.database.setCustomStreamUrl(previouschannel, d.stream)
                            self.playChannel(previouschannel, l1ll111ll_opy_)
    def inputnumber(self, number, method):
        self.l1l1111l1_opy_.channelinput = True
        l1l111l1l_opy_ = int(gui.ADDON.getSetting(l1ll1_opy_ (u"࠭ࡣ࡭ࡱࡶࡩ࡮ࡴࡰࡶࡶࡰࡷࠬੜ")).replace(l1ll1_opy_ (u"ࠧࠡ࡯ࡶࠫ੝"),l1ll1_opy_ (u"ࠨࠩਫ਼")))
        dialog = xbmcgui.Dialog()
        selection = dialog.input(l1ll1_opy_ (u"ࠤࡌࡲࡵࡻࡴࠡࡥ࡫ࡥࡳࡴࡥ࡭ࠢࡱࡹࡲࡨࡥࡳࠤ੟"), number, xbmcgui.INPUT_NUMERIC, autoclose=l1l111l1l_opy_)
        if int(selection) < 1 or selection == l1ll1_opy_ (u"ࠪࠫ੠"):
            selection = l1ll1_opy_ (u"ࠫ࠶࠭੡")
        if method == l1ll1_opy_ (u"ࠬࡋࡐࡈࠩ੢"):
            if self.l1l1111l1_opy_.currentcategory != l1ll1_opy_ (u"ࠨࡁ࡭࡮ࠣࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠧ੣"):
                self.hm.ADDON.setSetting(l1ll1_opy_ (u"ࠧ࡭ࡣࡶࡸ࠳ࡩࡡࡵࡧࡪࡳࡷࡿࠧ੤"), l1ll1_opy_ (u"ࠣࡃ࡯ࡰࠥࡉࡨࡢࡰࡱࡩࡱࡹࠢ੥"))
                self.l1l1111l1_opy_.currentcategory = self.hm.ADDON.getSetting(l1ll1_opy_ (u"ࠩ࡯ࡥࡸࡺ࠮ࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ੦"))
            self.l1l1111l1_opy_.viewStartDate = datetime.datetime.today()
            self.l1l1111l1_opy_.viewStartDate -= datetime.timedelta(minutes=self.l1l1111l1_opy_.viewStartDate.minute % 30, seconds=self.l1l1111l1_opy_.viewStartDate.second)
            self.l1l1111l1_opy_.focusPoint.y = self.l1l1111l1_opy_.epgView.top
            self.l1l1111l1_opy_.onRedrawEPG(int(selection)-1, self.l1l1111l1_opy_.viewStartDate)
        elif method == l1ll1_opy_ (u"ࠪࡘ࡛࠭੧"):
            self.l1l1111l1_opy_.osdChannel = self.l1l1111l1_opy_.kek.l11llll11_opy_(int(selection)-1)
            self.l1l1111l1_opy_.osdProgram = self.l1l1111l1_opy_.kek.getCurrentProgram(self.l1l1111l1_opy_.osdChannel)
            if not self.playChannel(self.l1l1111l1_opy_.osdChannel, self.l1l1111l1_opy_.osdProgram, True):
                result = self.l1l1111l1_opy_.streamingService.detectStream(self.l1l1111l1_opy_.osdChannel)
                if not result:
                    self.l1l1111l1_opy_._showContextMenu(self.l1l1111l1_opy_.osdProgram)
                elif type(result) == str:
                    self.l1l1111l1_opy_.database.setCustomStreamUrl(self.l1l1111l1_opy_.osdChannel, result)
                    self.playChannel(self.l1l1111l1_opy_.osdChannel, self.l1l1111l1_opy_.osdProgram)
                else:
                    result = sorted(result, key=self.l11llllll_opy_)
                    result = sorted(result, key=self.l1ll11l11_opy_)
                    if self.l1l1111l1_opy_.osdChannel.title == l1ll1_opy_ (u"ࠫࡊࡖࡌࠨ੨") or self.l1l1111l1_opy_.osdChannel.title == l1ll1_opy_ (u"ࠬࡔࡆࡍࠩ੩") or self.l1l1111l1_opy_.osdChannel.title == l1ll1_opy_ (u"࠭ࡎࡃࡃࠪ੪") or self.l1l1111l1_opy_.osdChannel.title == l1ll1_opy_ (u"ࠧࡏࡊࡏࠫ੫") or self.l1l1111l1_opy_.osdChannel.title == l1ll1_opy_ (u"ࠨࡒࡓ࡚ࠬ੬") or self.l1l1111l1_opy_.osdChannel.title == l1ll1_opy_ (u"ࠩࡑࡆࡆ࠭੭") or self.l1l1111l1_opy_.osdChannel.title == l1ll1_opy_ (u"ࠪ࠶࠹࠽ࠧ੮") or self.l1l1111l1_opy_.osdChannel.title == l1ll1_opy_ (u"ࠫࡒࡒࡂࠨ੯") or self.l1l1111l1_opy_.osdChannel.title == l1ll1_opy_ (u"ࠬࡓࡕࡔࡋࡆࠤࡈࡎࡏࡊࡅࡈࠫੰ") or len(self.l1l1111l1_opy_.osdChannel.title) > 13:
                        selection = kappa.iI1(l1ll1_opy_ (u"ࠨ࡛ࡃ࡟ࡉࡳࡺࡴࡤࠡ࡯ࡸࡰࡹ࡯ࡰ࡭ࡧࠣࡷࡴࡻࡲࡤࡧࡶࠤ࡫ࡵࡲࠡࡶ࡫࡭ࡸࠦࡣࡩࡣࡱࡲࡪࡲ࠮ࠡࡒ࡯ࡩࡦࡹࡥࠡࡵࡨࡰࡪࡩࡴࠡࡱࡱࡩ࠳ࡡ࠯ࡃ࡟ࠥੱ"), result)
                        if selection is not None:
                            if selection == -1:
                                pass
                            else:
                                self.l1l1111l1_opy_.database.setCustomStreamUrl(self.l1l1111l1_opy_.osdChannel, selection)
                                self.playChannel(self.l1l1111l1_opy_.osdChannel, self.l1l1111l1_opy_.osdProgram)
                    else:
                        d = self.hm.ChooseStreamAddonDialog(result)
                        d.doModal()
                        if d.stream is not None:
                            self.l1l1111l1_opy_.database.setCustomStreamUrl(self.l1l1111l1_opy_.osdChannel, d.stream)
                            self.playChannel(self.l1l1111l1_opy_.osdChannel, self.l1l1111l1_opy_.osdProgram)
        elif method == l1ll1_opy_ (u"ࠧࡐࡕࡇࠫੲ"):
            self.l1l1111l1_opy_.osdChannel = self.l1l1111l1_opy_.kek.l11llll11_opy_(int(selection)-1)
            self.l1l1111l1_opy_.osdProgram = self.l1l1111l1_opy_.kek.getCurrentProgram(self.l1l1111l1_opy_.osdChannel)
            self._showOsd()
        self.l1l1111l1_opy_.channelinput = False
    def _showOsd(self, onplayback=False):
        if not self.l1l1111l1_opy_.osdEnabled:
            return
        if self.l1l1111l1_opy_.mode != self.hm.MODE_OSD:
            self.l1l1111l1_opy_.database.getEPGView(self.l1l1111l1_opy_.currentChannel, self.l1l1111l1_opy_.viewStartDate, self.l1l1111l1_opy_.onSourceProgressUpdate, clearExistingProgramList=False)
            self.l1l1111l1_opy_.osdChannel = self.l1l1111l1_opy_.currentChannel
            self.l1l1111l1_opy_.osdProgram = self.l1l1111l1_opy_.kek.getCurrentProgram(self.l1l1111l1_opy_.currentChannel)
        if self.l1l1111l1_opy_.osdProgram is None:
            self.l1l1111l1_opy_.osdProgram = self.hm.src.Program(self.l1l1111l1_opy_.osdChannel, self.hm.strings(self.hm.NO_PROGRAM_AVAILABLE), None, None, None)
        if self.l1l1111l1_opy_.osdProgram is not None and self.l1l1111l1_opy_.osdChannel is not None:
            self.l1l1111l1_opy_.setControlLabel(self.l1l1111l1_opy_.C_MAIN_OSD_TITLE, l1ll1_opy_ (u"ࠨ࡝ࡅࡡࠪࡹ࡛࠰ࡄࡠࠫੳ") % self.l1l1111l1_opy_.osdProgram.title)
            if self.l1l1111l1_opy_.osdProgram.startDate or self.l1l1111l1_opy_.osdProgram.endDate:
                self.l1l1111l1_opy_.setControlLabel(self.l1l1111l1_opy_.C_MAIN_OSD_TIME, l1ll1_opy_ (u"ࠩ࡞ࡆࡢࠫࡳࠡ࠯ࠣࠩࡸࡡ࠯ࡃ࡟ࠪੴ") % (
                    self.l1l1111l1_opy_.formatTime(self.l1l1111l1_opy_.osdProgram.startDate), self.l1l1111l1_opy_.formatTime(self.l1l1111l1_opy_.osdProgram.endDate)))
            else:
                self.l1l1111l1_opy_.setControlLabel(self.l1l1111l1_opy_.C_MAIN_OSD_TIME, l1ll1_opy_ (u"ࠪࠫੵ"))
            self.l1l1111l1_opy_.setControlText(self.l1l1111l1_opy_.C_MAIN_OSD_DESCRIPTION, self.l1l1111l1_opy_.osdProgram.description)
            self.l1l1111l1_opy_.setControlLabel(self.l1l1111l1_opy_.C_MAIN_OSD_CHANNEL_TITLE, self.l1l1111l1_opy_.osdChannel.title)
            if self.l1l1111l1_opy_.osdProgram.channel.logo is not None and self.l1l1111l1_opy_.osdShowlogos:
                self.l1l1111l1_opy_.setControlImage(self.l1l1111l1_opy_.C_MAIN_OSD_CHANNEL_LOGO, self.l1l1111l1_opy_.osdProgram.channel.logo)
            else:
                self.l1l1111l1_opy_.setControlImage(self.l1l1111l1_opy_.C_MAIN_OSD_CHANNEL_LOGO, l1ll1_opy_ (u"ࠫࠬ੶"))
            if self.l1l1111l1_opy_.osdShownumbers:
                self.l1l1111l1_opy_.setControlText(self.l1l1111l1_opy_.C_MAIN_OSD_CHANNEL_NUMBER, str(self.l1l1111l1_opy_.kek.getCurrentChannel(self.l1l1111l1_opy_.osdChannel)+1))
        if not onplayback:
            self.l1l1111l1_opy_.mode = self.hm.MODE_OSD
        self.l1l1111l1_opy_._showControl(self.l1l1111l1_opy_.C_MAIN_OSD)
    def p1(self):
        if not self.playChannel(self.l1l1111l1_opy_.osdChannel, self.l1l1111l1_opy_.osdProgram, True):
            result = self.l1l1111l1_opy_.streamingService.detectStream(self.l1l1111l1_opy_.osdChannel)
            if not result:
                self.l1l1111l1_opy_._showContextMenu(self.l1l1111l1_opy_.osdProgram)
            elif type(result) == str:
                self.l1l1111l1_opy_.database.setCustomStreamUrl(self.l1l1111l1_opy_.osdChannel, result)
                self.playChannel(self.l1l1111l1_opy_.osdChannel, self.l1l1111l1_opy_.osdProgram)
            else:
                result = sorted(result, key=self.l11llllll_opy_)
                result = sorted(result, key=self.l1ll11l11_opy_)
                if self.l1l1111l1_opy_.osdChannel.title == l1ll1_opy_ (u"ࠬࡋࡐࡍࠩ੷") or self.l1l1111l1_opy_.osdChannel.title == l1ll1_opy_ (u"࠭ࡎࡇࡎࠪ੸") or self.l1l1111l1_opy_.osdChannel.title == l1ll1_opy_ (u"ࠧࡏࡄࡄࠫ੹") or self.l1l1111l1_opy_.osdChannel.title == l1ll1_opy_ (u"ࠨࡐࡋࡐࠬ੺") or self.l1l1111l1_opy_.osdChannel.title == l1ll1_opy_ (u"ࠩࡓࡔ࡛࠭੻") or self.l1l1111l1_opy_.osdChannel.title == l1ll1_opy_ (u"ࠪࡒࡇࡇࠧ੼") or self.l1l1111l1_opy_.osdChannel.title == l1ll1_opy_ (u"ࠫ࠷࠺࠷ࠨ੽") or self.l1l1111l1_opy_.osdChannel.title == l1ll1_opy_ (u"ࠬࡓࡌࡃࠩ੾") or self.l1l1111l1_opy_.osdChannel.title == l1ll1_opy_ (u"࠭ࡍࡖࡕࡌࡇࠥࡉࡈࡐࡋࡆࡉࠬ੿") or len(self.l1l1111l1_opy_.osdChannel.title) > 13:
                    selection = kappa.iI1(l1ll1_opy_ (u"ࠢ࡜ࡄࡠࡊࡴࡻ࡮ࡥࠢࡰࡹࡱࡺࡩࡱ࡮ࡨࠤࡸࡵࡵࡳࡥࡨࡷࠥ࡬࡯ࡳࠢࡷ࡬࡮ࡹࠠࡤࡪࡤࡲࡳ࡫࡬࠯ࠢࡓࡰࡪࡧࡳࡦࠢࡶࡩࡱ࡫ࡣࡵࠢࡲࡲࡪ࠴࡛࠰ࡄࡠࠦ઀"), result)
                    if selection is not None:
                        if selection == -1:
                            pass
                        else:
                            self.l1l1111l1_opy_.database.setCustomStreamUrl(self.l1l1111l1_opy_.osdChannel, selection)
                            self.playChannel(self.l1l1111l1_opy_.osdChannel, self.l1l1111l1_opy_.osdProgram)
                else:
                    d = self.hm.ChooseStreamAddonDialog(result)
                    d.doModal()
                    if d.stream is not None:
                        self.l1l1111l1_opy_.database.setCustomStreamUrl(self.l1l1111l1_opy_.osdChannel, d.stream)
                        self.playChannel(self.l1l1111l1_opy_.osdChannel, self.l1l1111l1_opy_.osdProgram)
    def p2(self, program):
        if not self.playChannel(program.channel, program, True):
            result = self.l1l1111l1_opy_.streamingService.detectStream(program.channel)
            if not result:
                self.l1l1111l1_opy_._showContextMenu(program)
            elif type(result) == str:
                self.l1l1111l1_opy_.database.setCustomStreamUrl(program.channel, result)
                self.playChannel(program.channel, program)
            else:
                result = sorted(result, key=self.l11llllll_opy_)
                result = sorted(result, key=self.l1ll11l11_opy_)
                if program.channel.title == l1ll1_opy_ (u"ࠨࡇࡓࡐࠬઁ") or program.channel.title == l1ll1_opy_ (u"ࠩࡑࡊࡑ࠭ં") or program.channel.title == l1ll1_opy_ (u"ࠪࡒࡇࡇࠧઃ") or program.channel.title == l1ll1_opy_ (u"ࠫࡓࡎࡌࠨ઄") or program.channel.title == l1ll1_opy_ (u"ࠬࡖࡐࡗࠩઅ") or program.channel.title == l1ll1_opy_ (u"࠭ࡎࡃࡃࠪઆ") or program.channel.title == l1ll1_opy_ (u"ࠧ࠳࠶࠺ࠫઇ") or program.channel.title == l1ll1_opy_ (u"ࠨࡏࡏࡆࠬઈ") or program.channel.title == l1ll1_opy_ (u"ࠩࡐ࡙ࡘࡏࡃࠡࡅࡋࡓࡎࡉࡅࠨઉ") or len(program.channel.title) > 13:
                    selection = kappa.iI1(l1ll1_opy_ (u"ࠥ࡟ࡇࡣࡆࡰࡷࡱࡨࠥࡳࡵ࡭ࡶ࡬ࡴࡱ࡫ࠠࡴࡱࡸࡶࡨ࡫ࡳࠡࡨࡲࡶࠥࡺࡨࡪࡵࠣࡧ࡭ࡧ࡮࡯ࡧ࡯࠲ࠥࡖ࡬ࡦࡣࡶࡩࠥࡹࡥ࡭ࡧࡦࡸࠥࡵ࡮ࡦ࠰࡞࠳ࡇࡣࠢઊ"), result)
                    if selection is not None:
                        if selection == -1:
                            pass
                        else:
                            self.l1l1111l1_opy_.database.setCustomStreamUrl(program.channel, selection)
                            self.playChannel(program.channel, program)
                else:
                    d = self.hm.ChooseStreamAddonDialog(result)
                    d.doModal()
                    if d.stream is not None:
                        self.l1l1111l1_opy_.database.setCustomStreamUrl(program.channel, d.stream)
                        self.playChannel(program.channel, program)
    def playChannel(self, channel, program = None, l11lll11l_opy_ = False):
        try:
            l1l1l111l_opy_ = self.l1l1111l1_opy_.player.isPlaying()
            url = self.l1l1111l1_opy_.database.getStreamUrl(channel)
            SAVESTREAM = self.hm.ADDON.getSetting(l1ll1_opy_ (u"ࠫࡸࡧࡶࡦ࠰ࡶࡸࡷ࡫ࡡ࡮ࠩઋ")) == l1ll1_opy_ (u"ࠬࡺࡲࡶࡧࠪઌ")
            l1l11l111_opy_ = [l1ll1_opy_ (u"࠭࠲࠵࠹ࠪઍ"),l1ll1_opy_ (u"ࠧࡏࡄࡄࠫ઎"),l1ll1_opy_ (u"ࠨࡐࡉࡐࠬએ"),l1ll1_opy_ (u"ࠩࡑࡌࡑ࠭ઐ"),l1ll1_opy_ (u"ࠪࡉࡕࡒࠧઑ"),l1ll1_opy_ (u"ࠫࡕࡖࡖࠨ઒"),l1ll1_opy_ (u"ࠬࡓࡌࡃࠩઓ"),l1ll1_opy_ (u"࠭ࡍࡶࡵ࡬ࡧࠥࡉࡨࡰ࡫ࡦࡩࠬઔ"),l1ll1_opy_ (u"ࠧࡎࡗࡖࡍࡈࠦࡃࡉࡑࡌࡇࡊ࠭ક")]
            if url:
                if l1l1l111l_opy_:
                    self.l1l1111l1_opy_.channelswitch = True
                    self.l1l1111l1_opy_.previouschannel = self.l1l1111l1_opy_.currentChannel
                self.l1l1111l1_opy_.currentChannel = channel
                if program == None:
                    program = self.l1l1111l1_opy_.kek.getCurrentProgram(self.l1l1111l1_opy_.currentChannel)
                if channel.title in l1l11l111_opy_ or not SAVESTREAM and not l11lll11l_opy_:
                    self.l1l1111l1_opy_.database.deleteCustomStreamUrl(channel)
                if url.isdigit():
                    command = (l1ll1_opy_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠦࠢ࠳࠰࠳ࠦ࠱ࠦࠢࡪࡦࠥ࠾ࠧ࠷ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠥࠨࡐ࡭ࡣࡼࡩࡷ࠴ࡏࡱࡧࡱࠦ࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤ࡬ࡸࡪࡳࠢ࠻ࡽࠥࡧ࡭ࡧ࡮࡯ࡧ࡯࡭ࡩࠨ࠺ࠦࡵࢀࢁࢂ࠭ખ") % url)
                    xbmc.executeJSONRPC(command)
                    return
                if url.startswith(l1ll1_opy_ (u"ࠩࡏࡍ࡛ࡋࡔࡗࠩગ")):
                    import add;stream = add.l1l11l11l_opy_(url)
                    delay=0
                    delay=100
                    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                    playlist.clear()
                    playlist.add(stream, xbmcgui.ListItem(l1ll1_opy_ (u"ࠪࠫઘ")))
                    try:
                        xbmc.Player().play(playlist)
                    except: pass
                    return
                if url.lower().startswith(l1ll1_opy_ (u"ࠫࡩࡹࡦࠨઙ")):
                    import add
                    if add.playPlaylist(url, windowed):
                        print l1ll1_opy_ (u"ࠬࡖ࡬ࡢࡻ࡯࡭ࡸࡺࠧચ")
                    return
                if str.startswith(url,l1ll1_opy_ (u"ࠨࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮࡮ࡧࡷࡥࠧછ")) and program is not None:
                    title = urllib.quote(program.title)
                    url += l1ll1_opy_ (u"ࠢ࠰ࠧࡶ࠳ࠪࡹࠢજ") % (title, program.language)
                if url[0:9] == l1ll1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫઝ") and self.l1l1111l1_opy_.alternativePlayback:
                    if self.l1l1111l1_opy_.alternativePlayback:
                        xbmc.executebuiltin(l1ll1_opy_ (u"࡛ࠩࡆࡒࡉ࠮ࡓࡷࡱࡔࡱࡻࡧࡪࡰࠫࠩࡸ࠯ࠧઞ") % url)
                else:
                    if url[0:26] == l1ll1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡩ࡫ࡸ࠰ࠩટ"):
                        url = re.findall(l1ll1_opy_ (u"ࡶࠬࡻࡲ࡭࠿ࠫ࠲࠰ࡅࠩࠧ࡯ࡲࡨࡪ࠭ઠ"), url)
                        url = l1ll1_opy_ (u"ࠬ࠭ડ").join(url)
                        url = urllib.unquote_plus(url)
                    try:
                        listitem = xbmcgui.ListItem(l1ll1_opy_ (u"࠭ࡔࡪࡶ࡯ࡩࠬઢ"), thumbnailImage=self.l1l1111l1_opy_.currentChannel.logo)
                        listitem.setInfo(l1ll1_opy_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ણ"), {l1ll1_opy_ (u"ࠨࡖ࡬ࡸࡱ࡫ࠧત"): l1ll1_opy_ (u"ࠤ࡞ࡇࡔࡒࡏࡓࠢࡶ࡯ࡾࡨ࡬ࡶࡧࡠ࡟ࡇࡣࠢથ")+self.l1l1111l1_opy_.currentChannel.title+l1ll1_opy_ (u"ࠥࠤ࠲࡛ࠦࡄࡑࡏࡓࡗࠦࡰࡢ࡮ࡨ࡫ࡷ࡫ࡥ࡯࡟ࠥદ")+program.title+l1ll1_opy_ (u"ࠦࡠ࠵ࡃࡐࡎࡒࡖࡢࡡ࠯ࡃ࡟ࠥધ")})
                    except:
                        pass
                    self.l1l1111l1_opy_.player.play(item=url, listitem=listitem, windowed=0)
                if not l1l1l111l_opy_:
                    self.l1l1111l1_opy_._hideEpg()
                else:
                    self.l1l1111l1_opy_._hideOsd()
                self.hm.threading.Timer(1, self.l1l1111l1_opy_.waitForPlayBackStopped).start()
                xbmc.sleep(350)
                self.l1l1111l1_opy_.osdProgram = self.l1l1111l1_opy_.kek.getCurrentProgram(self.l1l1111l1_opy_.currentChannel)
                self.l1l1111l1_opy_.channelIdx = self.l1l1111l1_opy_.kek.getCurrentChannel(self.l1l1111l1_opy_.currentChannel)
            return url is not None
        except:
            if channel.title in l1l11l111_opy_ or not SAVESTREAM and not l11lll11l_opy_:
                self.l1l1111l1_opy_.database.deleteCustomStreamUrl(channel)
    def cw(self, kek):
        try:
            opener = URLopener()
            parsed_url = urlparse.urlparse(kek)
            if not bool(parsed_url.scheme):
                parsed_url = parsed_url._replace(**{l1ll1_opy_ (u"ࠧࡹࡣࡩࡧࡰࡩࠧન"): l1ll1_opy_ (u"ࠨࡨࡵࡶࡳࠦ઩")})
                kek = parsed_url.geturl()
                if kek[0:8] == l1ll1_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠰ࠩપ"):
                    kek = kek.replace(l1ll1_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠱ࠪફ"),l1ll1_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࠪબ"))
            response = opener.open(kek)
            try:
                code = response.getcode()
            finally:
                response.close()
            if code == 200:
                path = urlparse.urlparse(kek).path
                l1l111lll_opy_ = os.path.splitext(path)[1]
                l1l1l1l11_opy_ = path.split(l1ll1_opy_ (u"ࠪ࠳ࠬભ"))[-1].split(l1ll1_opy_ (u"ࠫ࠳࠭મ"))[0]
                if (l1ll1_opy_ (u"ࠧ࠴ࡰ࡯ࡩࠥય") in l1l111lll_opy_ or l1ll1_opy_ (u"ࠨ࠮࡫ࡲࡪࠦર") in l1l111lll_opy_ or l1ll1_opy_ (u"ࠢ࠯࡬ࡳࡩ࡬ࠨ઱") in l1l111lll_opy_ or l1ll1_opy_ (u"ࠣ࠰ࡪ࡭࡫ࠨલ") in l1l111lll_opy_):
                    mayfaircustomwp = xbmc.translatePath(os.path.join(gui.SKINdir, l1ll1_opy_ (u"ࠩࡵࡩࡸࡵࡵࡳࡥࡨࡷࠬળ"), l1ll1_opy_ (u"ࠪࡷࡰ࡯࡮ࡴࠩ઴"), l1ll1_opy_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬવ"), l1l1l1l11_opy_))
                    if not os.path.exists(mayfaircustomwp+l1l111lll_opy_):
                        dp = xbmcgui.DialogProgress()
                        dp.create(l1ll1_opy_ (u"ࠧࡡࡃࡐࡎࡒࡖࠥ࡬ࡦ࠵࠸࠻࠶ࡧ࠺࡝ࡎ࡝ࡆࡓࡑࡕࡒࠡࡨࡩࡇ࠵ࡉ࠰ࡄ࠲ࡠࡥࡾ࡬ࡡࡪࡴࠣ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫࠺࠶࠹࠴ࡥ࠸ࡢࡍ࡛ࡄࡑࡏࡓࡗࠦࡦࡧࡅ࠳ࡇ࠵ࡉ࠰࡞ࡷ࡬ࡨࡪࡡࡃࡐࡎࡒࡖࠥ࡭࡯࡭ࡦࡠࠤࡕࡘࡏ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࠰ࠤࡘࡱࡩ࡯ࠤશ"),l1ll1_opy_ (u"࠭ࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠤࡈࡻࡳࡵࡱࡰࠤࡇࡧࡣ࡬ࡩࡵࡳࡺࡴࡤࠡࡋࡰࡥ࡬࡫࠮࠯ࠩષ"), l1ll1_opy_ (u"ࠧࠨસ"), l1ll1_opy_ (u"ࠨࠩહ"))
                        dp.update(0)
                        start_time=time.time()
                        opener.retrieve(kek, mayfaircustomwp+l1l111lll_opy_, lambda nb, bs, fs: self._pbhook(nb, bs, fs, dp, start_time))
                    return True, l1l1l1l11_opy_+l1l111lll_opy_
                else:
                    dialog = xbmcgui.Dialog()
                    dialog.ok(l1ll1_opy_ (u"ࠤ࡞ࡇࡔࡒࡏࡓࠢࡩࡪ࠹࠼࠸࠳ࡤ࠷ࡡࡒࡡࡃࡐࡎࡒࡖࠥ࡬ࡦࡄ࠲ࡆ࠴ࡈ࠶࡝ࡢࡻࡩࡥ࡮ࡸࠠ࡜ࡅࡒࡐࡔࡘࠠࡧࡨ࠷࠺࠽࠸ࡢ࠵࡟ࡊ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫ࡉ࠰ࡄ࠲ࡆ࠴ࡢࡻࡩࡥࡧ࡞ࡇࡔࡒࡏࡓࠢࡪࡳࡱࡪ࡝ࠡࡒࡕࡓࡠ࠵ࡃࡐࡎࡒࡖࡢࠨ઺"),self.DansGame(l1ll1_opy_ (u"ࠥࡗ࡝ࡗࡧࡤ࠴࡙ࡰࡧ࡞ࡍࡨࡧ࡚࠽࠶ࡏࡇࡩࡪࡧࡱ࡚࡭ࡣࡉࡌࡹࡨࡲࡲ࡫࡛࡙ࡔ࡫࡞࡝࠴ࡨࡣ࡚࠹࡯ࡨ࠳ࡋࡻ࡝࡛ࡓ࠶ࡢࡉ࡭ࡪ࡞ࡲ࠿ࡹࡣ࡙ࡉ࠴ࡩࡍࡖ࡬ࡋࡋ࡚ࡾࡨࡃࡃ࡯ࡥ࠷ࡎ࡭࡙࠴ࡘࡽࡨࡌ࠿ࡴࡊࡊࡑࡶࡦ࡝࠴ࡨ࡛ࡰࡊ࡯ࡧ࠲ࡥࡻࡥ࠷࡛ࡻ࡚ࡄࡄࡳࡦ࡜ࡌ࡮࡛ࡕ࠷ࡁࠧ઻")),l1ll1_opy_ (u"઼ࠦࠧ"),self.DansGame(l1ll1_opy_ (u"࡛ࠧࡇࡹ࡮࡜࡜ࡓࡲࡉࡈ࠳࡫ࡥ࠷࡛ࡧࡤ࠵࡙ࡽ࡟࡙ࡂ࠶ࡤ࠶࡙࡬ࡩࡈࡋࡸࡧࡱࡱࡱ࡚ࡔࡄ࠳ࡥࡌ࡛ࡧ࡛ࡉ࡯ࡽ࡟࡝ࡎ࠱ࡋࡋ࡚ࡾࡨࡃࡃ࠲ࡥࡽࡇ࠶ࡡࡈࡗࡪࡥ࡜࠷ࡨ࡛࠴ࡘ࡫࡟ࡳ࡬ࡴ࡜ࡖ࠸࡬ࡑࡃ࠶ࡳࡦࡋࡨࡼࡌ࡯ࡄࡸ࡞ࡾ࠾ࡵࡢࡰࡅࡰ࡟ࡿ࠸ࡶ࡜࠵ࡰࡲࡑࡑ࠾࠿ࠥઽ")))
                    return False, l1ll1_opy_ (u"࠭ࠧા")
            else:
                dialog = xbmcgui.Dialog()
                dialog.ok(l1ll1_opy_ (u"ࠢ࡜ࡅࡒࡐࡔࡘࠠࡧࡨ࠷࠺࠽࠸ࡢ࠵࡟ࡐ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫ࡉ࠰ࡄ࠲ࡆ࠴ࡢࡧࡹࡧࡣ࡬ࡶࠥࡡࡃࡐࡎࡒࡖࠥ࡬ࡦ࠵࠸࠻࠶ࡧ࠺࡝ࡈ࡝ࡆࡓࡑࡕࡒࠡࡨࡩࡇ࠵ࡉ࠰ࡄ࠲ࡠࡹ࡮ࡪࡥ࡜ࡅࡒࡐࡔࡘࠠࡨࡱ࡯ࡨࡢࠦࡐࡓࡑ࡞࠳ࡈࡕࡌࡐࡔࡠࠦિ"),self.DansGame(l1ll1_opy_ (u"ࠣࡕ࡛ࡕ࡬ࡩ࠲ࡗ࡮ࡥ࡜ࡒ࡭ࡤࡈࡪ࡯ࡍࡍ࡜ࡹࡣࡅࡅࡻࡨࡳ࠹࠳ࡣ࡚ࡖࡱࡠࡃࡃ࡯ࡥ࠷ࡎ࡭࡙࠴ࡘࡽࡨࡌ࠿ࡴࡊࡊࡑࡶࡦ࡝࠴ࡨ࡛ࡰࡊ࡯ࡧ࠲ࡥࡻࡥ࠷࡛ࡻ࡚ࡄࡄࡳࡦ࡜ࡌ࡮࡛ࡕࡅࡴࡨࡿࡂ࠴ࡥࡰ࠽ࡺࡠࡹࡃࡸࡦ࡭ࡇ࠶ࡡࡈࡘࡼ࡞ࡘࡈ࠳࡚࡚ࡐ࡫࡞࡝࠴ࡨࡣ࡛ࡒࡿࡪࡗࡖࡩ࡜࠶࠾ࡻࡢ࡮ࡘ࡭ࡨࡌࡲࡵ࡛ࡻࡅ࠴ࡧࡿࡂ࠱ࡣࡊࡊ࠵ࡏࡈࡥ࡮࡜ࡲࡓࡶࡤࡈࡗ࡫ࠦી")),l1ll1_opy_ (u"ࠤࠥુ"),self.DansGame(l1ll1_opy_ (u"࡙ࠥࡌࡾ࡬࡚࡚ࡑࡰࡎࡍࡖࡶࡦࡊ࡚ࡾࡏࡈࡓࡱ࡝ࡗࡇ࡜ࡕ࡬ࡹࡪ࡞࡝࡮ࡨ࡚࠵ࡔࡷࡎࡍࡎࡩࡥ࠵࡙ࡹࡩ࠲ࡗࡷࡦ࠶ࡱ࠶ࡡ࡙࡜࡯ࡐ࡬ࡃ࠽ࠣૂ")))
                return False, l1ll1_opy_ (u"ࠫࠬૃ")
        except:
            dialog = xbmcgui.Dialog()
            dialog.ok(l1ll1_opy_ (u"ࠧࡡࡃࡐࡎࡒࡖࠥ࡬ࡦ࠵࠸࠻࠶ࡧ࠺࡝ࡎ࡝ࡆࡓࡑࡕࡒࠡࡨࡩࡇ࠵ࡉ࠰ࡄ࠲ࡠࡥࡾ࡬ࡡࡪࡴࠣ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫࠺࠶࠹࠴ࡥ࠸ࡢࡍ࡛ࡄࡑࡏࡓࡗࠦࡦࡧࡅ࠳ࡇ࠵ࡉ࠰࡞ࡷ࡬ࡨࡪࡡࡃࡐࡎࡒࡖࠥ࡭࡯࡭ࡦࡠࠤࡕࡘࡏ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠤૄ"), self.DansGame(l1ll1_opy_ (u"ࠨࡕ࠳࠻ࡷ࡞࡝ࡘ࡯ࡢ࡙࠸ࡲࡎࡎࡤ࡭ࡤࡱࡕ࡬ࡪ࠳ࡋࡸࡥࡱࡨ࡭ࡤ࠳࡮࠳ࡥࡈࡈ࠰ࡢࡉࡘ࡫ࡨࡎࡊࡷࡦࡰࡰࡰࡠࡗࡒࡩ࡜࠷࡛ࢀࡤࡈ࠻ࡷࡍࡌࡐࡨ࡚࠴ࡷࡲࡨࡳ࠹࠲ࡤࡰࡕ࡬ࡩ࠲ࡵࡲࡥ࡭ࡇ࠷ࡣ࡮ࡹ࡫ࠦૅ")),self.DansGame(l1ll1_opy_ (u"ࠢࡖࡉࡻࡰ࡞࡞ࡎ࡭ࡋࡊ࠵࡭ࡧ࠲ࡖࡩࡦ࠷࡛ࡿ࡚ࡔࡄ࠸ࡦ࠸࡛ࡧ࡚࡚ࡍࡰࡎࡍࡖࡶࡦࡊ࡚ࡾࡧࡗ࠶ࡰࡌࡋࡱ࠶ࡉࡈࡘ࠷࡝࡜ࡔ࠰ࡌࡉࡑ࡬ࡨ࠸ࡕࡵࡥ࠵࡚ࡺࡩ࠲࡭࠲ࡤ࡜࡟ࡲࡋࡔࡄ࡫ࡦࡲࡗࡧࡢ࡚ࡔࡲࡨࡿࡂ࠱ࡣࡊ࡙࡬ࡠࡇ࡭ࡻ࡝࡛ࡓ࠶ࡉࡈ࡮ࡷ࡝࡜ࡪ࡬ࡊࡈ࡙ࡗ࡙ࡉࡂ࡭ࡤࡰࡖࡵࡨ࡭ࡤࡩࡤ࡛࠹࡭ࡋࡄ࠷ࡴࡧࡌࡩࡶࡍ࡯ࡳࡻ࡟࡝ࡣࡷࡎࡱࡆࡺࡠࡹ࠹ࡷ࡝࠶ࡱࡳࡋࡒ࠿ࡀࠦ૆")),l1ll1_opy_ (u"ࠣࠤે"))
            return False, l1ll1_opy_ (u"ࠩࠪૈ")
    def StreamDown(self):
        dialog = xbmcgui.Dialog()
        try:
            if self.l1l1111l1_opy_.database.getStreamUrl(self.l1l1111l1_opy_.currentChannel):
                ret = dialog.yesno(l1ll1_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫࠺࠶࠹࠴ࡥ࠸ࡢࡓ࡛ࡄࡑࡏࡓࡗࠦࡦࡧࡅ࠳ࡇ࠵ࡉ࠰࡞ࡣࡼࡪࡦ࡯ࡲࠡ࡝ࡆࡓࡑࡕࡒࠡࡨࡩ࠸࠻࠾࠲ࡣ࠶ࡠࡋࡠࡉࡏࡍࡑࡕࠤ࡫࡬ࡃ࠱ࡅ࠳ࡇ࠵ࡣࡵࡪࡦࡨ࡟ࡈࡕࡌࡐࡔࠣ࡫ࡴࡲࡤ࡞ࠢࡓࡖࡔࡡ࠯ࡄࡑࡏࡓࡗࡣࠧૉ"),l1ll1_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞࡝ࡅࡡࡊࡸࡲࡰࡴࠣࡻ࡮ࡺࡨࠡࠩ૊")+self.l1l1111l1_opy_.currentChannel.title+l1ll1_opy_ (u"ࠬࠦࡳࡵࡴࡨࡥࡲ࡛ࠧ࠰ࡄࡠ࡟࠴ࡉࡏࡍࡑࡕࡡࠬો"),l1ll1_opy_ (u"࠭ࡓࡵࡴࡨࡥࡲࠦࡡࡱࡲࡨࡥࡷࡹࠠࡵࡱࠣࡦࡪࠦࡤࡰࡹࡱࠥࠥࡵࡲࠡࡥ࡫ࡩࡨࡱࠠࡺࡱࡸࡶࠥࡩ࡯࡯ࡰࡨࡧࡹ࡯࡯࡯࠰࠱ࠫૌ"),l1ll1_opy_ (u"ࠧࡅࡱࠣࡽࡴࡻࠠࡸ࡫ࡶ࡬ࠥࡺ࡯ࠡࡴࡨࡱࡴࡼࡥࠡࡶ࡫࡭ࡸࠦࡳࡵࡴࡨࡥࡲࠦࡡࡴࠢࡼࡳࡺࡸࠠࡥࡧࡩࡥࡺࡲࡴࠡࡵࡷࡶࡪࡧ࡭ࠡࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤ࡫ࡵࡲࠡࡶ࡫࡭ࡸࠦࡣࡩࡣࡱࡲࡪࡲ࠿ࠨ્"),l1ll1_opy_ (u"ࠨࡐࡲࠫ૎"),l1ll1_opy_ (u"ࠩ࡜ࡩࡸ࠭૏"))
                if ret:
                    self.l1l1111l1_opy_.database.deleteCustomStreamUrl(self.l1l1111l1_opy_.currentChannel)
                    return
                if not ret:
                    return
            else:
                dialog.ok(l1ll1_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫࠺࠶࠹࠴ࡥ࠸ࡢࡓ࡛ࡄࡑࡏࡓࡗࠦࡦࡧࡅ࠳ࡇ࠵ࡉ࠰࡞ࡣࡼࡪࡦ࡯ࡲࠡ࡝ࡆࡓࡑࡕࡒࠡࡨࡩ࠸࠻࠾࠲ࡣ࠶ࡠࡋࡠࡉࡏࡍࡑࡕࠤ࡫࡬ࡃ࠱ࡅ࠳ࡇ࠵ࡣࡵࡪࡦࡨ࡟ࡈࡕࡌࡐࡔࠣ࡫ࡴࡲࡤ࡞ࠢࡓࡖࡔࡡ࠯ࡄࡑࡏࡓࡗࡣࠧૐ"),l1ll1_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞࡝ࡅࡡࡊࡸࡲࡰࡴࠣࡻ࡮ࡺࡨࠡࡵࡷࡶࡪࡧ࡭ࠢ࡝࠲ࡆࡢࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ૑"),l1ll1_opy_ (u"࡙ࠬࡴࡳࡧࡤࡱࠥࡧࡰࡱࡧࡤࡶࡸࠦࡴࡰࠢࡥࡩࠥࡪ࡯ࡸࡰࠤࠤࡴࡸࠠࡤࡪࡨࡧࡰࠦࡹࡰࡷࡵࠤࡨࡵ࡮࡯ࡧࡦࡸ࡮ࡵ࡮࠯࠰ࠪ૒"),l1ll1_opy_ (u"࠭ࠧ૓"))
                return
        except:
            return
    def _pbhook(self, numblocks, blocksize, filesize, dp, start_time):
        try:
            percent = min(numblocks * blocksize * 100 / filesize, 100)
            currently_downloaded = float(numblocks) * blocksize / (1024 * 1024)
            kbps_speed = numblocks * blocksize / (time.time() - start_time)
            if kbps_speed > 0:
                eta = (filesize - numblocks * blocksize) / kbps_speed
            else:
                eta = 0
            kbps_speed = kbps_speed / 1024
            total = float(filesize) / (1024 * 1024)
            mbs = l1ll1_opy_ (u"ࠢࡄࡷࡶࡸࡴࡳࠠࡃࡣࡦ࡯࡬ࡸ࡯ࡶࡰࡧࠤࡎࡳࡡࡨࡧ࠽ࠤࠧ૔")+l1ll1_opy_ (u"ࠨࠧ࠱࠴࠷࡬ࠠࡎࡄࠣࡳ࡫ࠦࠥ࠯࠲࠵ࡪࠥࡓࡂࠨ૕") % (currently_downloaded, total)
            e = l1ll1_opy_ (u"ࠩࡖࡴࡪ࡫ࡤ࠻ࠢࠨ࠲࠵࠸ࡦࠡࡍࡥ࠳ࡸࠦࠧ૖") % kbps_speed
            e += l1ll1_opy_ (u"ࠪࡉ࡙ࡇ࠺ࠡࠧ࠳࠶ࡩࡀࠥ࠱࠴ࡧࠫ૗") % divmod(eta, 60)
            dp.update(percent, mbs, e)
        except:
            percent = 100
            dp.update(percent)
        if dp.iscanceled():
            dp.close()
    def DansGame(self,KappaPride):
        gachiGASM = base64.b64decode(KappaPride)
        return gachiGASM
    def l11llllll_opy_(self,item):
        return item[1]
    def l1ll11l11_opy_(self,item):
        return item[0]
    def systemvideosettings(self):
        try:
            dialog = xbmcgui.Dialog()
            l11lll1ll_opy_ = json.loads(xbmc.executeJSONRPC(l1ll1_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡺ࡮ࡪࡥࡰࡲ࡯ࡥࡾ࡫ࡲ࠯ࡷࡶࡩࡲ࡫ࡤࡪࡣࡦࡳࡩ࡫ࡣࠣࡿ࠯ࠤࠧ࡯ࡤࠣ࠼࠴ࢁࠬ૘")))[l1ll1_opy_ (u"ࠧࡸࡥࡴࡷ࡯ࡸࠧ૙")][l1ll1_opy_ (u"ࠨࡶࡢ࡮ࡸࡩࠧ૚")]
            l1ll111l1_opy_ = json.loads(xbmc.executeJSONRPC(l1ll1_opy_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨࡶࡪࡦࡨࡳࡵࡲࡡࡺࡧࡵ࠲ࡺࡹࡥ࡮ࡧࡧ࡭ࡦࡩ࡯ࡥࡧࡦࡷࡺࡸࡦࡢࡥࡨࠦࢂ࠲ࠠࠣ࡫ࡧࠦ࠿࠷ࡽࠨ૛")))[l1ll1_opy_ (u"ࠣࡴࡨࡷࡺࡲࡴࠣ૜")][l1ll1_opy_ (u"ࠤࡹࡥࡱࡻࡥࠣ૝")]
            if l1ll111l1_opy_ == True:
                ret = dialog.yesno(l1ll1_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫࠺࠶࠹࠴ࡥ࠸ࡢࡓ࡛ࡄࡑࡏࡓࡗࠦࡦࡧࡅ࠳ࡇ࠵ࡉ࠰࡞ࡣࡼࡪࡦ࡯ࡲࠡ࡝ࡆࡓࡑࡕࡒࠡࡨࡩ࠸࠻࠾࠲ࡣ࠶ࡠࡋࡠࡉࡏࡍࡑࡕࠤ࡫࡬ࡃ࠱ࡅ࠳ࡇ࠵ࡣࡵࡪࡦࡨ࡟ࡈࡕࡌࡐࡔࠣ࡫ࡴࡲࡤ࡞ࠢࡓࡖࡔࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ૞"),l1ll1_opy_ (u"ࠫ࡜࡫ࠠࡩࡣࡹࡩࠥࡡࡂ࡞ࡦࡨࡸࡪࡩࡴࡦࡦ࡞࠳ࡇࡣࠠࡴࡱࡰࡩࠥࡵࡦࠡࡻࡲࡹࡷࠦࡋࡰࡦ࡬ࠤࡻ࡯ࡤࡦࡱࠣࡷࡪࡺࡴࡪࡰࡪࡷࠥࡧࡲࡦࠢࡦࡳࡳ࡬ࡩࡨࡷࡵࡩࡩࠦࡩ࡯ࠢࡤࠤࡼࡧࡹࠡ࡝ࡆࡓࡑࡕࡒࠡࡴࡨࡨࡢࡡࡂ࡞ࡶ࡫ࡥࡹࠦࡣࡰࡷ࡯ࡨࠥࡩࡡࡶࡵࡨࠤࡸ࡫ࡶࡦࡴࡤࡰࠥ࡯ࡳࡴࡷࡨࡷࠦࡡ࠯ࡃ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠫ૟"),l1ll1_opy_ (u"ࠬࡊ࡯ࠡࡻࡲࡹࠥࡽࡡ࡯ࡶࠣࡹࡸࠦࡴࡰࠢࡦࡳࡳ࡬ࡩࡨࡷࡵࡩࠥࡺࡨࡦࡵࡨࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸࠦࡦࡰࡴࠣࡽࡴࡻࠠࡧࡱࡵࠤࡦ࡛ࠦࡃ࡟ࡶࡱࡴࡵࡴࡩࠢࡨࡼࡵ࡫ࡲࡪࡧࡱࡧࡪࡅ࡛࠰ࡄࡠࠤࡠࡉࡏࡍࡑࡕࠤࡱ࡯࡭ࡦࡩࡵࡩࡪࡴ࡝࡜ࡄࡠࡘ࡭࡯ࡳࠡ࡫ࡶࠤ࡭࡯ࡧࡩ࡮ࡼࠤࡷ࡫ࡣࡰ࡯ࡰࡩࡳࡪࡥࡥࠣ࡞࠳ࡇࡣ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨૠ"),l1ll1_opy_ (u"࠭ࠧૡ"),l1ll1_opy_ (u"࡚ࠧࡧࡶࠫૢ"),l1ll1_opy_ (u"ࠨࡐࡲࠫૣ"))
                if ret:
                    gui.ADDON.setSetting(l1ll1_opy_ (u"ࠩࡶࡽࡸࡺࡥ࡮ࡵࡨࡸࡹ࡯࡮ࡨࡥ࡫ࡩࡨࡱࠧ૤"), l1ll1_opy_ (u"ࠥࡸࡷࡻࡥࠣ૥"))
                    return False
                if not ret:
                    xbmc.executeJSONRPC(l1ll1_opy_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡓࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡺ࡮ࡪࡥࡰࡲ࡯ࡥࡾ࡫ࡲ࠯ࡷࡶࡩࡲ࡫ࡤࡪࡣࡦࡳࡩ࡫ࡣࡴࡷࡵࡪࡦࡩࡥࠣ࠮ࠣࠦࡻࡧ࡬ࡶࡧࠥ࠾࡫ࡧ࡬ࡴࡧࢀ࠰ࠧ࡯ࡤࠣ࠼࠴ࢁࠬ૦"))
                    xbmc.executeJSONRPC(l1ll1_opy_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡔࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡻ࡯ࡤࡦࡱࡳࡰࡦࡿࡥࡳ࠰ࡸࡷࡪࡳࡥࡥ࡫ࡤࡧࡴࡪࡥࡤࠤ࠯ࠤࠧࡼࡡ࡭ࡷࡨࠦ࠿ࡺࡲࡶࡧࢀ࠰ࠧ࡯ࡤࠣ࠼࠴ࢁࠬ૧"))
                    gui.ADDON.setSetting(l1ll1_opy_ (u"࠭ࡳࡺࡵࡷࡩࡲࡹࡥࡵࡶ࡬ࡲ࡬ࡩࡨࡦࡥ࡮ࠫ૨"), l1ll1_opy_ (u"ࠢࡵࡴࡸࡩࠧ૩"))
                    dialog.ok(l1ll1_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡨࡩ࠸࠻࠾࠲ࡣ࠶ࡠࡑࡠࡉࡏࡍࡑࡕࠤ࡫࡬ࡃ࠱ࡅ࠳ࡇ࠵ࡣࡡࡺࡨࡤ࡭ࡷ࡛ࠦࡄࡑࡏࡓࡗࠦࡦࡧ࠶࠹࠼࠷ࡨ࠴࡞ࡉ࡞ࡇࡔࡒࡏࡓࠢࡩࡪࡈ࠶ࡃ࠱ࡅ࠳ࡡࡺ࡯ࡤࡦ࡝ࡆࡓࡑࡕࡒࠡࡩࡲࡰࡩࡣࠠࡑࡔࡒ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ૪"),l1ll1_opy_ (u"࡚ࠩࡩࠥ࡮ࡡࡷࡧࠣ࡟ࡈࡕࡌࡐࡔࠣࡰ࡮ࡳࡥࡨࡴࡨࡩࡳࡣ࡛ࡃ࡟ࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࡲࡹ࡜࠱ࡅࡡࡠ࠵ࡃࡐࡎࡒࡖࡢࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡦࡦࠣࡽࡴࡻࡲࠡࡍࡲࡨ࡮ࠦࡶࡪࡦࡨࡳࠥࡹࡥࡵࡶ࡬ࡲ࡬ࡹࠠࡰࡰࠣࡽࡴࡻࡲࠡࡤࡨ࡬ࡦࡲࡦࠡࡨࡲࡶࠥࡧࠠࡴ࡯ࡲࡳࡹ࡮ࠠࡦࡺࡳࡩࡷ࡯ࡥ࡯ࡥࡨࠥࠬ૫"),l1ll1_opy_ (u"ࠪࠫ૬"),l1ll1_opy_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡷ࡫࠭࡭ࡣࡸࡲࡨ࡮ࠠ࡜ࡅࡒࡐࡔࡘࠠࡧࡨ࠷࠺࠽࠸ࡢ࠵࡟ࡐ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫ࡉ࠰ࡄ࠲ࡆ࠴ࡢࡧࡹࡧࡣ࡬ࡶࠥࡡࡃࡐࡎࡒࡖࠥ࡬ࡦ࠵࠸࠻࠶ࡧ࠺࡝ࡈ࡝ࡆࡓࡑࡕࡒࠡࡨࡩࡇ࠵ࡉ࠰ࡄ࠲ࡠࡹ࡮ࡪࡥ࡜ࡅࡒࡐࡔࡘࠠࡨࡱ࡯ࡨࡢࠦࡐࡓࡑࠤ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ૭"))
                    return True
        except:
            dialog.ok(l1ll1_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥ࡬ࡦ࠵࠸࠻࠶ࡧ࠺࡝ࡎ࡝ࡆࡓࡑࡕࡒࠡࡨࡩࡇ࠵ࡉ࠰ࡄ࠲ࡠࡥࡾ࡬ࡡࡪࡴࠣ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫࠺࠶࠹࠴ࡥ࠸ࡢࡍ࡛ࡄࡑࡏࡓࡗࠦࡦࡧࡅ࠳ࡇ࠵ࡉ࠰࡞ࡷ࡬ࡨࡪࡡࡃࡐࡎࡒࡖࠥ࡭࡯࡭ࡦࡠࠤࡕࡘࡏ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ૮"),l1ll1_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡲࡦࡦࡠࡉࡷࡸ࡯ࡳࠣ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࡘࡵ࡭ࡦࡶ࡫࡭ࡳ࡭ࠠࡸࡧࡱࡸࠥࡡࡃࡐࡎࡒࡖࠥࡸࡥࡥ࡟࡞ࡆࡢࡽࡲࡰࡰࡪ࡟࠴ࡈ࡝࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢࡺ࡭ࡹ࡮ࠠࡤࡪࡤࡲ࡬࡯࡮ࡨࠢࡼࡳࡺࡸࠠࡌࡱࡧ࡭ࠥࡼࡩࡥࡧࡲࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸࠧࠧ૯"),l1ll1_opy_ (u"ࠧࠨ૰"),l1ll1_opy_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡴࡨࡴࡴࡸࡴࠡࡶ࡫࡭ࡸࠦࡴࡰࠢࡲࡹࡷࠦࡦࡢࡥࡨࡦࡴࡵ࡫ࠡࡩࡵࡳࡺࡶࠠࡢࡰࡧࠤ࡮ࡴࡣ࡭ࡷࡧࡩࠥࡿ࡯ࡶࡴࠣࡨࡪࡼࡩࡤࡧࠣࡱࡴࡪࡥ࡭ࠣࠪ૱"))
            return False
class okok(object):
    def __init__(self, i):
        self.i = i
        self.l1l1ll1ll_opy_ = False
        self.l1ll1111l_opy_ = None
        self.l1l1ll11l_opy_ = False
        self.l1l1llll1_opy_ = requests.session()
        self.username = lolol.lolu()
        self.password = lolol.lolp()
        self.loggedin = self.login()
        self.NOTICE = xbmc.translatePath(os.path.join(l1ll1_opy_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴࡮࡯࡮ࡧ࠲ࡥࡩࡪ࡯࡯ࡵ࠲ࠫ૲") + addon_id,l1ll1_opy_ (u"ࠪࡒࡔ࡚ࡉࡄࡇ࠱ࡸࡽࡺࠧ૳")))
        self.cookiefile = xbmc.translatePath(os.path.join(l1ll1_opy_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡱࡴࡲࡪ࡮ࡲࡥࠨ૴"), l1ll1_opy_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ૵"), l1ll1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡰࡳࡱࡪࡶࡦࡳ࠮࡮ࡶࡹ࡫ࡺ࡯ࡤࡦࡲࡵࡳࠬ૶"), l1ll1_opy_ (u"ࠧࡤࡱࡲ࡯࡮࡫ࠧ૷")))
        if self.loggedin:
            lolol.save_cookies(self.l1l1llll1_opy_.cookies, self.cookiefile)
    def login(self):
        username = lolol.lolu()
        password = lolol.lolp()
        if username != l1ll1_opy_ (u"ࠨࠩ૸") and password != l1ll1_opy_ (u"ࠩࠪૹ"):
            URL      = l1ll1_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡦࡿࡦࡢ࡫ࡵ࡫ࡺ࡯ࡤࡦࡵ࠱ࡧࡴࡳ࠯ࡱࡴࡲ࠳ࡼࡶ࠭࡭ࡱࡪ࡭ࡳ࠴ࡰࡩࡲࠪૺ")
            data  = {l1ll1_opy_ (u"ࠫࡱࡵࡧࠨૻ") : username, l1ll1_opy_ (u"ࠬࡶࡷࡥࠩૼ") : password, l1ll1_opy_ (u"࠭ࡷࡱ࠯ࡶࡹࡧࡳࡩࡵࠩ૽"): l1ll1_opy_ (u"ࠧࡍࡱࡪࠤࡎࡴࠧ૾")}
            try:
                lolol.show_busy_dialog()
                request  = self.l1l1llll1_opy_.post(URL, data=data)
                content = request.content
                code = request.status_code
                self.l1ll1111l_opy_ = re.findall(l1ll1_opy_ (u"ࡳࠩ࠳࠷࠽ࡁ࡟ࡸࡲࡱࡳࡳࡩࡥ࠾ࠪ࠱࠯ࡄ࠯ࠢ࠿ࡎࡲ࡫ࠥࡕࡵࡵ࠾࠲ࡥࡃࡂ࠯࡭࡫ࡁࠫ૿"), content)
                self.l1ll1111l_opy_ = l1ll1_opy_ (u"ࠩࠪ଀").join(self.l1ll1111l_opy_)
                l1ll11111_opy_ = re.findall(l1ll1_opy_ (u"ࡵࠫࡳࡧ࡭ࡦ࠿ࠥࡻࡸࡥࡰ࡭ࡷࡪ࡭ࡳࡥ࡟ࡴ࠴ࡰࡩࡲࡨࡥࡳࡡࡳࡶࡴ࡬ࡩ࡭ࡧࡢࡰࡴ࡭ࡩ࡯ࠤࠣ࡭ࡩࡃࠢࡸࡵ࠰ࡴࡱࡻࡧࡪࡰ࠰࠱ࡸ࠸࡭ࡦ࡯ࡥࡩࡷ࠳ࡰࡳࡱࡩ࡭ࡱ࡫࠭࡭ࡱࡪ࡭ࡳࠨࠠࡤ࡮ࡤࡷࡸࡃࠢࡸࡵ࠰ࡴࡱࡻࡧࡪࡰ࠰࠱ࡸ࠸࡭ࡦ࡯ࡥࡩࡷ࠳ࡰࡳࡱࡩ࡭ࡱ࡫࠭ࡧ࡫ࡨࡰࡩࠦࡦࡰࡴࡰ࠱ࡨࡵ࡮ࡵࡴࡲࡰࠧࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯࠭ࡂ࠭ࠧࠦࡤࡪࡵࡤࡦࡱ࡫ࡤ࠾ࠩଁ"), content)
                l1ll11111_opy_ = l1ll1_opy_ (u"ࠫࠬଂ").join(l1ll11111_opy_)
                lolol.hide_busy_dialog()
                if l1ll1_opy_ (u"ࠬࡂ࡬ࡪࠢ࡬ࡨࡂࠨࡷࡱ࠯ࡤࡨࡲ࡯࡮࠮ࡤࡤࡶ࠲ࡲ࡯ࡨࡱࡸࡸࠧࡄࠧଃ") in content and l1ll11111_opy_.lower() != self.username.lower():
                    dialog.ok(l1ll1_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡦࡧ࠶࠹࠼࠷ࡨ࠴࡞ࡏ࡞ࡇࡔࡒࡏࡓࠢࡩࡪࡈ࠶ࡃ࠱ࡅ࠳ࡡࡦࡿࡦࡢ࡫ࡵࠤࡠࡉࡏࡍࡑࡕࠤ࡫࡬࠴࠷࠺࠵ࡦ࠹ࡣࡇ࡜ࡅࡒࡐࡔࡘࠠࡧࡨࡆ࠴ࡈ࠶ࡃ࠱࡟ࡸ࡭ࡩ࡫࡛ࡄࡑࡏࡓࡗࠦࡧࡰ࡮ࡧࡡࠥࡖࡒࡐ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ଄"),l1ll1_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡳࡧࡧࡡࡠࡈ࡝࡚ࡱࡸࠤࡦࡸࡥࠡࡷࡶ࡭ࡳ࡭ࠠࡺࡱࡸࡶࠥ࡫࡭ࡢ࡫࡯ࠤࡦࡪࡤࡳࡧࡶࡷࠥࡧࡳࠡࡻࡲࡹࡷࠦࡕࡴࡧࡵࡲࡦࡳࡥࠢ࡝࠲ࡆࡢࡡ࠯ࡄࡑࡏࡓࡗࡣࠧଅ"),l1ll1_opy_ (u"ࠨ࡛ࡲࡹࡷࠦࡥ࡮ࡣ࡬ࡰࠥࡧࡤࡥࡴࡨࡷࡸࠦࡩࡴࠢ࡞ࡇࡔࡒࡏࡓࠢࡵࡩࡩࡣ࡛ࡃ࡟ࡑࡓ࡙ࡡ࠯ࡃ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠤࡾࡵࡵࡳࠢࡸࡷࡪࡸ࡮ࡢ࡯ࡨ࠰ࠥ࡯ࡴࠡ࡫ࡶࠤࡹ࡮ࡥࠡࡗࡶࡩࡷࡴࡡ࡮ࡧࠣࡽࡴࡻࠠࡤࡴࡨࡥࡹ࡫ࡤࠡࡷࡳࡳࡳࠦࡳࡪࡩࡱࡹࡵ࠴ࠠࡊࡨࠣࡽࡴࡻࠠࡧࡱࡵ࡫ࡴࡺࠠࡵࡪ࡬ࡷ࠱ࠦࡳࡶࡤࡰ࡭ࡹࠦࡡࠡࡶ࡬ࡧࡰ࡫ࡴࠡࡶࡲࠤࡸࡻࡰࡱࡱࡵࡸࡅࡳࡡࡺࡨࡤ࡭ࡷ࡭ࡵࡪࡦࡨࡷ࠳ࡩ࡯࡮ࠩଆ"),l1ll1_opy_ (u"ࠩࠪଇ"))
                    return False
                if l1ll1_opy_ (u"ࠪࡅࡨࡩࡥࡴࡵࠣࡉࡽࡶࡩࡳࡧࡧࠫଈ") in content or l1ll1_opy_ (u"࡚ࠫࡴࡰࡢ࡫ࡧࠫଉ") in content:
                    dialog.ok(l1ll1_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥ࡬ࡦ࠵࠸࠻࠶ࡧ࠺࡝ࡎ࡝ࡆࡓࡑࡕࡒࠡࡨࡩࡇ࠵ࡉ࠰ࡄ࠲ࡠࡥࡾ࡬ࡡࡪࡴࠣ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫࠺࠶࠹࠴ࡥ࠸ࡢࡍ࡛ࡄࡑࡏࡓࡗࠦࡦࡧࡅ࠳ࡇ࠵ࡉ࠰࡞ࡷ࡬ࡨࡪࡡࡃࡐࡎࡒࡖࠥ࡭࡯࡭ࡦࡠࠤࡕࡘࡏ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩଊ"),l1ll1_opy_ (u"࠭ࡉࡵࠢࡤࡴࡵ࡫ࡡࡳࡵࠣࡽࡴࡻࡲࠡࡵࡸࡦࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠠࡩࡣࡶࠤࡪࡾࡰࡪࡴࡨࡨ࠳࠭ଋ"),l1ll1_opy_ (u"ࠧࠨଌ"),l1ll1_opy_ (u"ࠨ࡛ࡲࡹࠥࡩࡡ࡯ࠢࡵࡩ࠲ࡹࡵࡣࡵࡦࡶ࡮ࡨࡥࠡࡣࡷ࠾ࠥ࡮ࡴࡵࡲ࠽࠳࠴ࡳࡡࡺࡨࡤ࡭ࡷ࡭ࡵࡪࡦࡨࡷ࠳ࡩ࡯࡮࠱ࡳࡶࡴ࠭଍"))
                    return False
                elif l1ll1_opy_ (u"ࠩࡱࡳ࠲ࡧࡣࡤࡧࡶࡷ࠲ࡸࡥࡥ࡫ࡵࡩࡨࡺࠧ଎") in content:
                    dialog.ok(l1ll1_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫࠺࠶࠹࠴ࡥ࠸ࡢࡓ࡛ࡄࡑࡏࡓࡗࠦࡦࡧࡅ࠳ࡇ࠵ࡉ࠰࡞ࡣࡼࡪࡦ࡯ࡲࠡ࡝ࡆࡓࡑࡕࡒࠡࡨࡩ࠸࠻࠾࠲ࡣ࠶ࡠࡋࡠࡉࡏࡍࡑࡕࠤ࡫࡬ࡃ࠱ࡅ࠳ࡇ࠵ࡣࡵࡪࡦࡨ࡟ࡈࡕࡌࡐࡔࠣ࡫ࡴࡲࡤ࡞ࠢࡓࡖࡔࡡ࠯ࡄࡑࡏࡓࡗࡣࠧଏ"),l1ll1_opy_ (u"ࠫࡎࡺࠠࡢࡲࡳࡩࡦࡸࡳࠡࡻࡲࡹࡷࠦࡳࡶࡤࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠥࡳࡡࡺࠢ࡫ࡥࡻ࡫ࠠࡦࡺࡳ࡭ࡷ࡫ࡤࠡࡱࡵࠤࡾࡵࡵࠡࡪࡤࡺࡪࠦࡥ࡯ࡶࡨࡶࡪࡪࠠࡸࡴࡲࡲ࡬ࠦ࡬ࡰࡩ࡬ࡲࠥࡪࡥࡵࡣ࡬ࡰࡸ࠴ࠧଐ"),l1ll1_opy_ (u"ࠬࡖ࡬ࡦࡣࡶࡩࠥࡸࡥ࡮ࡧࡰࡦࡪࡸࠠࡺࡱࡸࡶࠥ࡫࡭ࡢ࡫࡯ࠤ࡮ࡹࠠࡏࡑࡗࠤࡾࡵࡵࡳࠢࡸࡷࡪࡸ࡮ࡢ࡯ࡨ࠲ࠬ଑"),l1ll1_opy_ (u"࡙࠭ࡰࡷࠣࡧࡦࡴࠠࡳࡧ࠰ࡷࡺࡨࡳࡤࡴ࡬ࡦࡪࠦࡡࡵ࠼ࠣ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡦࡿࡦࡢ࡫ࡵ࡫ࡺ࡯ࡤࡦࡵ࠱ࡧࡴࡳ࠯ࡱࡴࡲࠫ଒"))
                    lolol.l1llll_opy_()
                    return False
                elif l1ll1_opy_ (u"ࠧ࠽࡮࡬ࠤ࡮ࡪ࠽ࠣࡹࡳ࠱ࡦࡪ࡭ࡪࡰ࠰ࡦࡦࡸ࠭࡭ࡱࡪࡳࡺࡺࠢ࠿ࠩଓ") in content:
                    self.l1l1ll1ll_opy_ = True
                    self.loggedin = True
                    threading.Timer(1, self.l11llll1l_opy_).start()
                    return True
                else:
                    l1l1lllll_opy_ = re.findall(l1ll1_opy_ (u"ࡳࠩ࠿ࡸ࡮ࡺ࡬ࡦࡀࠫ࠲࠰ࡅࠩ࠽࠱ࡷ࡭ࡹࡲࡥ࠿ࠩଔ"), content)
                    l1l1lllll_opy_ = l1ll1_opy_ (u"ࠩࠪକ").join(l1l1lllll_opy_)
                    l1l1lllll_opy_ = l1l1lllll_opy_.replace(l1ll1_opy_ (u"ࠪࡀࡸࡺࡲࡰࡰࡪࡂࠬଖ"),l1ll1_opy_ (u"ࠫࠬଗ")).replace(l1ll1_opy_ (u"ࠬࡂࡢࡳࠢ࠲ࡂࠬଘ"),l1ll1_opy_ (u"࠭ࠧଙ")).replace(l1ll1_opy_ (u"ࠧ࠽࠱ࡶࡸࡷࡵ࡮ࡨࡀࠪଚ"),l1ll1_opy_ (u"ࠨࠩଛ"))
                    if l1ll1_opy_ (u"ࠩࡳࡰࡪࡧࡳࡦࠢࡨࡱࡦ࡯࡬ࠨଜ") in content:
                        l1l1l1ll1_opy_ = re.findall(l1ll1_opy_ (u"ࡵࠫࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠬࡁࠬࡀࡦࠦࡣ࡭ࡣࡶࡷࡂࠨ࡟ࡠࡥࡩࡣࡪࡳࡡࡪ࡮ࡢࡣࠧ࠭ଝ"), content)
                        l1l1l1ll1_opy_ = l1ll1_opy_ (u"ࠫࠬଞ").join(l1l1l1ll1_opy_)
                        l1l1l1ll1_opy_ = l1l1l1ll1_opy_.replace(l1ll1_opy_ (u"ࠬࡶ࡬ࡦࡣࡶࡩࠥ࡫࡭ࡢ࡫࡯ࠤࠬଟ"),l1ll1_opy_ (u"࠭ࡰ࡭ࡧࡤࡷࡪࠦࡥ࡮ࡣ࡬ࡰࠥࡹࡵࡱࡲࡲࡶࡹࡆ࡭ࡢࡻࡩࡥ࡮ࡸࡧࡶ࡫ࡧࡩࡸ࠴ࡣࡰ࡯ࠣࡳࡷࠦࡲࡦࡲࡲࡶࡹࠦ࡯࡯ࠢࡩࡥࡨ࡫ࡢࡰࡱ࡮࠲ࠬଠ"))
                    else:
                        l1l1l1ll1_opy_ = re.findall(l1ll1_opy_ (u"ࡲࠨ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠰ࡅࠩ࠽࠱ࡥࡳࡩࡿ࠾ࠨଡ"), content)
                        l1l1l1ll1_opy_ = l1ll1_opy_ (u"ࠨࠩଢ").join(l1l1l1ll1_opy_)
                    l1l1l1ll1_opy_ = l1l1l1ll1_opy_.replace(l1ll1_opy_ (u"ࠩ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠫଣ"),l1ll1_opy_ (u"ࠪࠫତ")).replace(l1ll1_opy_ (u"ࠫࡁࡨࡲࠡ࠱ࡁࠫଥ"),l1ll1_opy_ (u"ࠬ࠭ଦ")).replace(l1ll1_opy_ (u"࠭࠼࠰ࡵࡷࡶࡴࡴࡧ࠿ࠩଧ"),l1ll1_opy_ (u"ࠧࠨନ"))
                    if l1ll1_opy_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡩࡥ࠿ࠥࡰࡴ࡭ࡩ࡯ࡡࡨࡶࡷࡵࡲࠣࡀࠪ଩") in content:
                        if l1ll1_opy_ (u"ࠩ࠿ࡷࡹࡸ࡯࡯ࡩࡁࡉࡗࡘࡏࡓ࠾࠲ࡷࡹࡸ࡯࡯ࡩࡁ࠾ࠥࡓࡡࡹࠢࡶ࡭ࡲࡻ࡬ࡵࡣࡱࡩࡴࡻࡳࠡ࡮ࡲ࡫࡮ࡴࡳࠡࡨࡲࡶࠥࡻࡳࡦࡴࡱࡥࡲ࡫ࠧପ") in content:
                            dialog.ok(l1ll1_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫࠺࠶࠹࠴ࡥ࠸ࡢࡓ࡛ࡄࡑࡏࡓࡗࠦࡦࡧࡅ࠳ࡇ࠵ࡉ࠰࡞ࡣࡼࡪࡦ࡯ࡲࠡ࡝ࡆࡓࡑࡕࡒࠡࡨࡩ࠸࠻࠾࠲ࡣ࠶ࡠࡋࡠࡉࡏࡍࡑࡕࠤ࡫࡬ࡃ࠱ࡅ࠳ࡇ࠵ࡣࡵࡪࡦࡨ࡟ࡈࡕࡌࡐࡔࠣ࡫ࡴࡲࡤ࡞ࠢࡓࡖࡔࡡ࠯ࡄࡑࡏࡓࡗࡣࠧଫ"),l1ll1_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞࡝ࡅࡡࡑࡵࡧࡪࡰࠣࡉࡷࡸ࡯ࡳࠣࠣ࠱ࠥ࡟࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡦࡺࡦࡩࡪࡪࡥࡥࠢࡰࡥࡽࠦࠨ࠴ࠫࠣࡥࡱࡲ࡯ࡸࡣࡥࡰࡪࠦࡤࡦࡸ࡬ࡧࡪࡹ࠮࡜࠱ࡅࡡࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ବ"),l1ll1_opy_ (u"ࠬࡖ࡬ࡦࡣࡶࡩࠥ࡫ࡸࡪࡶࠣࡸ࡭࡫ࠠࡨࡷ࡬ࡨࡪࠦ࡯࡯ࠢࡲࡸ࡭࡫ࡲࠡࡦࡨࡺ࡮ࡩࡥࠩࡵࠬࠤࡴࡸࠠࡸࡣ࡬ࡸࠥ࠻ࠠ࡮࡫ࡱࡹࡹ࡫ࡳࠡࡣࡱࡨࠥࡺࡲࡺࠢࡤ࡫ࡦ࡯࡮ࠢࠢࡌࡪࠥࡿ࡯ࡶࠢࡷ࡬࡮ࡴ࡫ࠡࡶ࡫࡭ࡸࠦࡩࡴࠢࡺࡶࡴࡴࡧ࠭ࠢࡳࡰࡪࡧࡳࡦࠢࡶࡹࡧࡳࡩࡵࠢࡤࠤࡹ࡯ࡣ࡬ࡧࡷ࠲ࠬଭ"),l1ll1_opy_ (u"࠭ࠧମ"))
                        else:
                            l1l1l1ll1_opy_ = re.findall(l1ll1_opy_ (u"ࡲࠨ࠾ࡧ࡭ࡻࠦࡩࡥ࠿ࠥࡰࡴ࡭ࡩ࡯ࡡࡨࡶࡷࡵࡲࠣࡀࠫ࠲࠰ࡅࠩ࡝ࡰ࠿࠳ࡩ࡯ࡶ࠿ࠩଯ"), content)
                            l1l1l1ll1_opy_ = l1ll1_opy_ (u"ࠨࠩର").join(l1l1l1ll1_opy_)
                            l1l1l1ll1_opy_ = l1l1l1ll1_opy_.replace(l1ll1_opy_ (u"ࠩ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠫ଱"),l1ll1_opy_ (u"ࠪࠫଲ")).replace(l1ll1_opy_ (u"ࠫࡁࡨࡲࠡ࠱ࡁࠫଳ"),l1ll1_opy_ (u"ࠬ࠭଴")).replace(l1ll1_opy_ (u"࠭࠼࠰ࡵࡷࡶࡴࡴࡧ࠿ࠩଵ"),l1ll1_opy_ (u"ࠧࠨଶ")).replace(l1ll1_opy_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡦࡿࡦࡢ࡫ࡵ࡫ࡺ࡯ࡤࡦࡵ࠱ࡧࡴࡳ࠯ࡱࡴࡲ࠳ࡼࡶ࠭࡭ࡱࡪ࡭ࡳ࠴ࡰࡩࡲࡂࡥࡨࡺࡩࡰࡰࡀࡰࡴࡹࡴࡱࡣࡶࡷࡼࡵࡲࡥࠤࡁࡐࡴࡹࡴࠡࡻࡲࡹࡷࠦࡰࡢࡵࡶࡻࡴࡸࡤࡀ࠾࠲ࡥࡃ࠭ଷ"),l1ll1_opy_ (u"ࠩࠪସ")).replace(l1ll1_opy_ (u"ࠪࡉࡗࡘࡏࡓ࠼ࠪହ"),l1ll1_opy_ (u"ࠫࠬ଺"))
                            l1l1l1ll1_opy_ = l1l1l1ll1_opy_.strip()
                            if l1ll1_opy_ (u"ࠬࡂࡳࡵࡴࡲࡲ࡬ࡄࡅࡓࡔࡒࡖࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄ࠺ࠡࡋࡱࡺࡦࡲࡩࡥࠢࡸࡷࡪࡸ࡮ࡢ࡯ࡨࠫ଻") in content:
                                dialog.ok(l1ll1_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡦࡧ࠶࠹࠼࠷ࡨ࠴࡞ࡏ࡞ࡇࡔࡒࡏࡓࠢࡩࡪࡈ࠶ࡃ࠱ࡅ࠳ࡡࡦࡿࡦࡢ࡫ࡵࠤࡠࡉࡏࡍࡑࡕࠤ࡫࡬࠴࠷࠺࠵ࡦ࠹ࡣࡇ࡜ࡅࡒࡐࡔࡘࠠࡧࡨࡆ࠴ࡈ࠶ࡃ࠱࡟ࡸ࡭ࡩ࡫࡛ࡄࡑࡏࡓࡗࠦࡧࡰ࡮ࡧࡡࠥࡖࡒࡐ࡝࠲ࡇࡔࡒࡏࡓ࡟଼ࠪ"), l1ll1_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡳࡧࡧࡡࡠࡈ࡝ࡍࡱࡪ࡭ࡳࠦࡅࡳࡴࡲࡶࠦࡡ࠯ࡃ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠫଽ"),l1l1l1ll1_opy_,l1ll1_opy_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡴࡨࡱࡪࡳࡢࡦࡴ࠯ࠤࡾࡵࡵࡳࠢࡨࡱࡦ࡯࡬ࠡ࡫ࡶࠤࡓࡕࡔࠡࡻࡲࡹࡷࠦࡵࡴࡧࡵࡲࡦࡳࡥ࠯ࠩା"))
                            elif l1ll1_opy_ (u"ࠩࡗ࡬ࡪࠦࡰࡢࡵࡶࡻࡴࡸࡤࠡࡻࡲࡹࠥ࡫࡮ࡵࡧࡵࡩࡩࠦࡦࡰࡴࠣࡸ࡭࡫ࠠࡦ࡯ࡤ࡭ࡱࠦࡡࡥࡦࡵࡩࡸࡹࠧି") in content:
                                dialog.ok(l1ll1_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫࠺࠶࠹࠴ࡥ࠸ࡢࡓ࡛ࡄࡑࡏࡓࡗࠦࡦࡧࡅ࠳ࡇ࠵ࡉ࠰࡞ࡣࡼࡪࡦ࡯ࡲࠡ࡝ࡆࡓࡑࡕࡒࠡࡨࡩ࠸࠻࠾࠲ࡣ࠶ࡠࡋࡠࡉࡏࡍࡑࡕࠤ࡫࡬ࡃ࠱ࡅ࠳ࡇ࠵ࡣࡵࡪࡦࡨ࡟ࡈࡕࡌࡐࡔࠣ࡫ࡴࡲࡤ࡞ࠢࡓࡖࡔࡡ࠯ࡄࡑࡏࡓࡗࡣࠧୀ"), l1ll1_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞࡝ࡅࡡࡑࡵࡧࡪࡰࠣࡉࡷࡸ࡯ࡳࠣ࡞࠳ࡇࡣ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨୁ"),l1ll1_opy_ (u"࡚ࠬࡨࡦࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤࡾࡵࡵࠡࡧࡱࡸࡪࡸࡥࡥࠢࡩࡳࡷࠦࡴࡩࡧࠣࡩࡲࡧࡩ࡭ࠢࡤࡨࡩࡸࡥࡴࡵࠣࠫୂ")+self.username+l1ll1_opy_ (u"࠭ࠠࡪࡵࠣ࡭ࡳࡩ࡯ࡳࡴࡨࡧࡹ࠴ࠧୃ"),l1ll1_opy_ (u"ࠧࡂ࡮ࡶࡳ࠱ࠦࡐ࡭ࡧࡤࡷࡪࠦࡲࡦ࡯ࡨࡱࡧ࡫ࡲࠡࡻࡲࡹࡷࠦࡥ࡮ࡣ࡬ࡰࠥ࡯ࡳࠡࡐࡒࡘࠥࡿ࡯ࡶࡴ࡙ࠣࡸ࡫ࡲ࡯ࡣࡰࡩࠦ࠭ୄ"))
                            elif l1ll1_opy_ (u"ࠨࡋࡱࡺࡦࡲࡩࡥࠢࡨࡱࡦ࡯࡬ࠡࡣࡧࡨࡷ࡫ࡳࡴࠩ୅") in content:
                                dialog.ok(l1ll1_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡩࡪ࠹࠼࠸࠳ࡤ࠷ࡡࡒࡡࡃࡐࡎࡒࡖࠥ࡬ࡦࡄ࠲ࡆ࠴ࡈ࠶࡝ࡢࡻࡩࡥ࡮ࡸࠠ࡜ࡅࡒࡐࡔࡘࠠࡧࡨ࠷࠺࠽࠸ࡢ࠵࡟ࡊ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫ࡉ࠰ࡄ࠲ࡆ࠴ࡢࡻࡩࡥࡧ࡞ࡇࡔࡒࡏࡓࠢࡪࡳࡱࡪ࡝ࠡࡒࡕࡓࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭୆"), l1ll1_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝࡜ࡄࡠࡐࡴ࡭ࡩ࡯ࠢࡈࡶࡷࡵࡲࠢࠢ࠰ࠤࡎࡴࡶࡢ࡮࡬ࡨࠥ࡫࡭ࡢ࡫࡯ࠤࡦࡪࡤࡳࡧࡶࡷࠦࡡ࠯ࡃ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠫେ"),l1ll1_opy_ (u"ࠫ࡞ࡵࡵࡳࠢࡨࡱࡦ࡯࡬ࠡࡣࡧࡨࡷ࡫ࡳࡴࠢ࡬ࡷࠥࡡࡃࡐࡎࡒࡖࠥࡸࡥࡥ࡟࡞ࡆࡢࡔࡏࡕ࡝࠲ࡆࡢࡡ࠯ࡄࡑࡏࡓࡗࡣࠠࡺࡱࡸࡶࠥࡻࡳࡦࡴࡱࡥࡲ࡫ࠬࠡ࡫ࡷࠤ࡮ࡹࠠࡵࡪࡨࠤ࡚ࡹࡥࡳࡰࡤࡱࡪࠦࡹࡰࡷࠣࡧࡷ࡫ࡡࡵࡧࡧࠤࡺࡶ࡯࡯ࠢࡶ࡭࡬ࡴࡵࡱ࠰ࠣࡍ࡫ࠦࡹࡰࡷࠣࡪࡴࡸࡧࡰࡶࠣࡸ࡭࡯ࡳ࠭ࠢࡶࡹࡧࡳࡩࡵࠢࡤࠤࡹ࡯ࡣ࡬ࡧࡷࠤࡹࡵࠠࡴࡷࡳࡴࡴࡸࡴࡁ࡯ࡤࡽ࡫ࡧࡩࡳࡩࡸ࡭ࡩ࡫ࡳ࠯ࡥࡲࡱࠬୈ"),l1ll1_opy_ (u"ࠬ࠭୉"))
                            else:
                                dialog.ok(l1ll1_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡦࡧ࠶࠹࠼࠷ࡨ࠴࡞ࡏ࡞ࡇࡔࡒࡏࡓࠢࡩࡪࡈ࠶ࡃ࠱ࡅ࠳ࡡࡦࡿࡦࡢ࡫ࡵࠤࡠࡉࡏࡍࡑࡕࠤ࡫࡬࠴࠷࠺࠵ࡦ࠹ࡣࡇ࡜ࡅࡒࡐࡔࡘࠠࡧࡨࡆ࠴ࡈ࠶ࡃ࠱࡟ࡸ࡭ࡩ࡫࡛ࡄࡑࡏࡓࡗࠦࡧࡰ࡮ࡧࡡࠥࡖࡒࡐ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ୊"), l1ll1_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡳࡧࡧࡡࡠࡈ࡝ࡍࡱࡪ࡭ࡳࠦࡅࡳࡴࡲࡶࠦࡡ࠯ࡃ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠫୋ"),l1l1l1ll1_opy_,l1ll1_opy_ (u"ࠨࠩୌ"))
                            if l1ll1_opy_ (u"ࠩ࠿ࡷࡹࡸ࡯࡯ࡩࡁࡉࡗࡘࡏࡓ࠾࠲ࡷࡹࡸ࡯࡯ࡩࡁ࠾ࠥࡏ࡮ࡷࡣ࡯࡭ࡩࠦࡵࡴࡧࡵࡲࡦࡳࡥࠨ୍") in content or l1ll1_opy_ (u"ࠪࡀࡸࡺࡲࡰࡰࡪࡂࡊࡘࡒࡐࡔ࠿࠳ࡸࡺࡲࡰࡰࡪࡂ࠿ࠦࡔࡩࡧࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡿ࡯ࡶࠢࡨࡲࡹ࡫ࡲࡦࡦࠣࡪࡴࡸࠠࡵࡪࡨࠤࡺࡹࡥࡳࡰࡤࡱࡪ࠭୎") in content:
                                lolol.l1llll_opy_()
                        return False
                    else:
                        dialog.ok(l1l1lllll_opy_,l1l1l1ll1_opy_,l1ll1_opy_ (u"ࠫࠬ୏"),l1ll1_opy_ (u"ࠬ࠭୐"))
                        return False
            except:
                lolol.hide_busy_dialog()
                import sys
                import traceback as tb
                (etype, value, traceback) = sys.exc_info()
                tb.print_exception(etype, value, traceback)
                dialog.ok(l1ll1_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡦࡧ࠶࠹࠼࠷ࡨ࠴࡞ࡏ࡞ࡇࡔࡒࡏࡓࠢࡩࡪࡈ࠶ࡃ࠱ࡅ࠳ࡡࡦࡿࡦࡢ࡫ࡵࠤࡠࡉࡏࡍࡑࡕࠤ࡫࡬࠴࠷࠺࠵ࡦ࠹ࡣࡇ࡜ࡅࡒࡐࡔࡘࠠࡧࡨࡆ࠴ࡈ࠶ࡃ࠱࡟ࡸ࡭ࡩ࡫࡛ࡄࡑࡏࡓࡗࠦࡧࡰ࡮ࡧࡡࠥࡖࡒࡐ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ୑"),l1ll1_opy_ (u"ࠧࡆࡴࡵࡳࡷࠧࠠࡖࡰࡤࡦࡱ࡫ࠠࡵࡱࠣࡧࡴࡴ࡮ࡦࡥࡷࠤࡹࡵࠠࡴࡧࡵࡺࡪࡸ࠮࠯࠰ࠪ୒"),l1ll1_opy_ (u"ࠨࠩ୓"),l1ll1_opy_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡷࡶࡾࠦࡡࡨࡣ࡬ࡲࠥࡲࡡࡵࡧࡵ࠲ࠬ୔"))
                sys.exit(1)
        else:
            dialog.ok(l1ll1_opy_ (u"ࠪࡉࡷࡸ࡯ࡳࠣࠣࡒࡴࠦࡵࡴࡧࡵࡲࡦࡳࡥࠡࡱࡵࠤࡵࡧࡳࡴࡹࡲࡶࡩ࠴ࠧ୕"),l1ll1_opy_ (u"ࠫࡒࡧࡹࡧࡣ࡬ࡶࠥࡍࡵࡪࡦࡨࡷࠥࡖࡲࡰࠢࡵࡩࡶࡻࡩࡳࡧࡶࠤࡦࡴࠠࡢࡥࡷ࡭ࡻ࡫ࠠࡴࡷࡥࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠴ࠧୖ"),l1ll1_opy_ (u"ࠬࡖ࡬ࡦࡣࡶࡩࠥ࡫࡮ࡵࡧࡵࠤࡾࡵࡵࡳࠢࡸࡷࡪࡸ࡮ࡢ࡯ࡨࠤࡦࡴࡤࠡࡲࡤࡷࡸࡽ࡯ࡳࡦ࠱ࠫୗ"),l1ll1_opy_ (u"࡙࠭ࡰࡷࠣࡧࡦࡴࠠࡱࡷࡵࡧ࡭ࡧࡳࡦࠢࡤࠤࡸࡻࡢࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠣࡥࡹࡀࠠࡩࡶࡷࡴ࠿࠵࠯࡮ࡣࡼࡪࡦ࡯ࡲࡨࡷ࡬ࡨࡪࡹ࠮ࡤࡱࡰ࠳ࡵࡸ࡯ࠨ୘"))
            lolol.l1llll_opy_()
            return False
    def logout(self, l1l1l1lll_opy_=False):
        while self.l1l1ll11l_opy_:
            xbmc.sleep(100)
        if self.l1l1ll1ll_opy_ == True:
            self.l1l1ll1ll_opy_ = False
        if self.l1ll1111l_opy_:
            try:
                request = self.l1l1llll1_opy_.post(l1ll1_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡮ࡣࡼࡪࡦ࡯ࡲࡨࡷ࡬ࡨࡪࡹ࠮ࡤࡱࡰ࠳ࡵࡸ࡯࠰ࡹࡳ࠱ࡱࡵࡧࡪࡰ࠱ࡴ࡭ࡶ࠿ࡢࡥࡷ࡭ࡴࡴ࠽࡭ࡱࡪࡳࡺࡺࠦࡠࡹࡳࡲࡴࡴࡣࡦ࠿ࠪ୙")+self.l1ll1111l_opy_)
                content = request.content
                self.l1l1llll1_opy_.close()
                if not l1ll1_opy_ (u"ࠨ࡛ࡲࡹࠥࡧࡲࡦࠢࡱࡳࡼࠦ࡬ࡰࡩࡪࡩࡩࠦ࡯ࡶࡶࠪ୚") in content and not l1l1l1lll_opy_:
                    dialog.ok(l1ll1_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡩࡪ࠹࠼࠸࠳ࡤ࠷ࡡࡒࡡࡃࡐࡎࡒࡖࠥ࡬ࡦࡄ࠲ࡆ࠴ࡈ࠶࡝ࡢࡻࡩࡥ࡮ࡸࠠ࡜ࡅࡒࡐࡔࡘࠠࡧࡨ࠷࠺࠽࠸ࡢ࠵࡟ࡊ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫ࡉ࠰ࡄ࠲ࡆ࠴ࡢࡻࡩࡥࡧ࡞ࡇࡔࡒࡏࡓࠢࡪࡳࡱࡪ࡝ࠡࡒࡕࡓࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭୛"),l1ll1_opy_ (u"ࠪࡉࡷࡸ࡯ࡳࠢ࡯ࡳ࡬࡭ࡩ࡯ࡩࠣࡳࡺࡺࠡࠨଡ଼"),l1ll1_opy_ (u"ࠫࡘࡵ࡭ࡦࡶ࡫࡭ࡳ࡭ࠠࡸࡧࡱࡸࠥࡽࡲࡰࡰࡪࠤࡼ࡯ࡴࡩࠢ࡯ࡳ࡬ࡵࡵࡵࠢࡳࡶࡴࡩࡥࡴࡵ࠱ࠫଢ଼"),l1ll1_opy_ (u"ࠬࡖ࡬ࡦࡣࡶࡩࠥࡸࡥࡱࡱࡵࡸࠥࡺࡨࡪࡵࠣࡳࡳࠦ࡯ࡶࡴࠣࡪࡦࡩࡥࡣࡱࡲ࡯ࠥ࡭ࡲࡰࡷࡳ࠲ࠬ୞"))
            except:
                if not l1l1l1lll_opy_:
                    import sys
                    import traceback as tb
                    (etype, value, traceback) = sys.exc_info()
                    tb.print_exception(etype, value, traceback)
                    dialog.ok(l1ll1_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡦࡧ࠶࠹࠼࠷ࡨ࠴࡞ࡏ࡞ࡇࡔࡒࡏࡓࠢࡩࡪࡈ࠶ࡃ࠱ࡅ࠳ࡡࡦࡿࡦࡢ࡫ࡵࠤࡠࡉࡏࡍࡑࡕࠤ࡫࡬࠴࠷࠺࠵ࡦ࠹ࡣࡇ࡜ࡅࡒࡐࡔࡘࠠࡧࡨࡆ࠴ࡈ࠶ࡃ࠱࡟ࡸ࡭ࡩ࡫࡛ࡄࡑࡏࡓࡗࠦࡧࡰ࡮ࡧࡡࠥࡖࡒࡐ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪୟ"),l1ll1_opy_ (u"ࠧࡆࡴࡵࡳࡷࠦ࡬ࡰࡩࡪ࡭ࡳ࡭ࠠࡰࡷࡷࠥࠬୠ"),l1ll1_opy_ (u"ࠨࡅࡲࡲࡳ࡫ࡣࡵ࡫ࡲࡲࠥ࡫ࡲࡳࡱࡵ࠲ࠬୡ"),l1ll1_opy_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡵࡩࡵࡵࡲࡵࠢࡷ࡬࡮ࡹࠠࡰࡰࠣࡳࡺࡸࠠࡧࡣࡦࡩࡧࡵ࡯࡬ࠢࡪࡶࡴࡻࡰ࠯ࠩୢ"))
        else:
            if self.i is not None and not l1l1l1lll_opy_:
                dialog.ok(l1ll1_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫࠺࠶࠹࠴ࡥ࠸ࡢࡓ࡛ࡄࡑࡏࡓࡗࠦࡦࡧࡅ࠳ࡇ࠵ࡉ࠰࡞ࡣࡼࡪࡦ࡯ࡲࠡ࡝ࡆࡓࡑࡕࡒࠡࡨࡩ࠸࠻࠾࠲ࡣ࠶ࡠࡋࡠࡉࡏࡍࡑࡕࠤ࡫࡬ࡃ࠱ࡅ࠳ࡇ࠵ࡣࡵࡪࡦࡨ࡟ࡈࡕࡌࡐࡔࠣ࡫ࡴࡲࡤ࡞ࠢࡓࡖࡔࡡ࠯ࡄࡑࡏࡓࡗࡣࠧୣ"),l1ll1_opy_ (u"ࠫࡊࡸࡲࡰࡴࠣࡰࡴ࡭ࡧࡪࡰࡪࠤࡴࡻࡴࠢࠩ୤"),l1ll1_opy_ (u"ࠬࡔ࡯ࠡ࡮ࡲ࡫ࡴࡻࡴࠡࡨࡲࡹࡳࡪ࠮࠯ࠩ୥"),l1ll1_opy_ (u"࠭ࡐ࡭ࡧࡤࡷࡪࠦࡲࡦࡲࡲࡶࡹࠦࡴࡩ࡫ࡶࠤࡴࡴࠠࡰࡷࡵࠤ࡫ࡧࡣࡦࡤࡲࡳࡰࠦࡧࡳࡱࡸࡴ࠳࠭୦"))
    def l11llll1l_opy_(self):
        while self.l1l1ll1ll_opy_ and self.loggedin and not self.l1l1ll11l_opy_ and not xbmc.abortRequested and not self.i.isClosing:
            xbmc.sleep(240000)
            if not self.l1l1ll1ll_opy_ or not self.loggedin or self.l1l1ll11l_opy_ or xbmc.abortRequested or self.i.isClosing:
                self.logout(True)
                break
            self.l1l1ll11l_opy_ = True
            URL     = l1ll1_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡮ࡣࡼࡪࡦ࡯ࡲࡨࡷ࡬ࡨࡪࡹ࠮ࡤࡱࡰ࠳ࡵࡸ࡯࠰࡮ࡲ࡫࡬࡫ࡤࡪࡰ࠲ࠫ୧")
            try:
                request = self.l1l1llll1_opy_.post(URL)
            except:
                xbmc.log(l1ll1_opy_ (u"ࠨࡏࡤࡽ࡫ࡧࡩࡳࠢࡊࡹ࡮ࡪࡥࡴࠢࡓࡖࡔࡀࠠࡆࡴࡵࡳࡷࠦࡣࡰࡰࡱࡩࡨࡺࡩ࡯ࡩࠣࡸࡴࠦࡳࡦࡴࡹࡩࡷࠧࠠ࡬ࡧࡨࡴࠥࡧ࡬ࡪࡸࡨࠤ࠭࠷ࠩࠨ୨"), xbmc.LOGWARNING)
                self.l1l1ll1ll_opy_ = False
            content = request.content
            code    = request.status_code
            if l1ll1_opy_ (u"ࠩࡖࡹࡨࡩࡥࡴࡵࠤࠤࡈࡻࡲࡳࡧࡱࡸࡱࡿࠠ࡭ࡱࡪ࡫ࡪࡪࠠࡪࡰࠤࠫ୩") in content:
                self.l1l1ll1ll_opy_ = True
            elif l1ll1_opy_ (u"ࠪࡉࡷࡸ࡯ࡳࠣࠣࡇࡺࡸࡲࡦࡰࡷࡰࡾࠦ࡮ࡰࡶࠣࡰࡴ࡭ࡧࡦࡦࠣ࡭ࡳࠧࠧ୪") in content:
                xbmc.log(l1ll1_opy_ (u"ࠫࡒࡧࡹࡧࡣ࡬ࡶࠥࡍࡵࡪࡦࡨࡷࠥࡖࡒࡐ࠼ࠣࡉࡷࡸ࡯ࡳࠣࠣࡇࡺࡸࡲࡦࡰࡷࡰࡾࠦ࡮ࡰࡶࠣࡰࡴ࡭ࡧࡦࡦࠣ࡭ࡳࠧࠠ࡬ࡧࡨࡴࠥࡧ࡬ࡪࡸࡨࠤ࠭࠸ࠩࠨ୫"), xbmc.LOGWARNING)
                self.l1l1ll1ll_opy_ = False
            else:
                xbmc.log(l1ll1_opy_ (u"ࠬࡓࡡࡺࡨࡤ࡭ࡷࠦࡇࡶ࡫ࡧࡩࡸࠦࡐࡓࡑ࠽ࠤࡊࡸࡲࡰࡴࠤࠤࡘࡵ࡭ࡦࡶ࡫࡭ࡳ࡭ࠠࡸࡧࡱࡸࠥࡽࡲࡰࡰࡪ࠲࠳ࠦ࡫ࡦࡧࡳࠤࡦࡲࡩࡷࡧࠣࠬ࠸࠯ࠧ୬"), xbmc.LOGWARNING)
                self.l1l1ll1ll_opy_ = False
            self.l1l1ll11l_opy_ = False
    def l1l1111ll_opy_(self, l1l1l1111_opy_):
        class TextBox():
            WINDOW=10147
            CONTROL_LABEL=1
            CONTROL_TEXTBOX=5
            def __init__(self,*args,**kwargs):
                xbmc.executebuiltin(l1ll1_opy_ (u"ࠨࡁࡤࡶ࡬ࡺࡦࡺࡥࡘ࡫ࡱࡨࡴࡽࠨࠦࡦࠬࠦ୭") % (self.WINDOW, ))
                self.win=xbmcgui.Window(self.WINDOW)
                xbmc.sleep(500)
                self.setControls()
            def setControls(self):
                self.win.getControl(self.CONTROL_LABEL).setLabel(l1ll1_opy_ (u"ࠧࡍࡣࡷࡩࡸࡺࠠ࡯ࡧࡺࡷࠥ࡬ࡲࡰ࡯ࠣ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫࠺࠶࠹࠴ࡥ࠸ࡢࡓ࡛ࡄࡑࡏࡓࡗࠦࡦࡧࡅ࠳ࡇ࠵ࡉ࠰࡞ࡣࡼࡪࡦ࡯ࡲࠡ࡝ࡆࡓࡑࡕࡒࠡࡨࡩ࠸࠻࠾࠲ࡣ࠶ࡠࡋࡠࡉࡏࡍࡑࡕࠤ࡫࡬ࡃ࠱ࡅ࠳ࡇ࠵ࡣࡵࡪࡦࡨ࡟ࡈࡕࡌࡐࡔࠣ࡫ࡴࡲࡤ࡞ࠢࡓࡖࡔࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ୮"))
                try: f=open(l1l1l1111_opy_); text=f.read()
                except: text=l1l1l1111_opy_
                self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
                return
        TextBox()
        while xbmc.getCondVisibility(l1ll1_opy_ (u"ࠨ࡙࡬ࡲࡩࡵࡷ࠯ࡋࡶ࡚࡮ࡹࡩࡣ࡮ࡨࠬ࠶࠶࠱࠵࠹ࠬࠫ୯")):
            time.sleep(.5)
    def l1_opy_(self, url):
        try:
            lolol.show_busy_dialog()
            request = self.l1l1llll1_opy_.post(url)
            data = request.content
            lolol.hide_busy_dialog()
            if l1ll1_opy_ (u"ࠩ࠿ࡷࡹࡸ࡯࡯ࡩࡁ࠸࠵࠷࠺࠽࠱ࡶࡸࡷࡵ࡮ࡨࡀࠣࡗࡴࡸࡲࡺ࠮ࠣࡥࡨࡩࡥࡴࡵࠣࡨࡪࡴࡩࡦࡦࠪ୰") in data:
                dialog.ok(l1ll1_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫࠺࠶࠹࠴ࡥ࠸ࡢࡓ࡛ࡄࡑࡏࡓࡗࠦࡦࡧࡅ࠳ࡇ࠵ࡉ࠰࡞ࡣࡼࡪࡦ࡯ࡲࠡ࡝ࡆࡓࡑࡕࡒࠡࡨࡩ࠸࠻࠾࠲ࡣ࠶ࡠࡋࡠࡉࡏࡍࡑࡕࠤ࡫࡬ࡃ࠱ࡅ࠳ࡇ࠵ࡣࡵࡪࡦࡨ࡟ࡈࡕࡌࡐࡔࠣ࡫ࡴࡲࡤ࡞ࠢࡓࡖࡔࡡ࠯ࡄࡑࡏࡓࡗࡣࠧୱ"),l1ll1_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞࡝ࡅࡡࡑࡵࡧࡪࡰࠣࡉࡷࡸ࡯ࡳࠣࠣ࠱ࠥ࡟࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡦࡺࡦࡩࡪࡪࡥࡥࠢࡰࡥࡽࠦࠨ࠴ࠫࠣࡥࡱࡲ࡯ࡸࡣࡥࡰࡪࠦࡤࡦࡸ࡬ࡧࡪࡹ࠮࡜࠱ࡅࡡࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭୲"),l1ll1_opy_ (u"ࠬࡖ࡬ࡦࡣࡶࡩࠥ࡫ࡸࡪࡶࠣࡸ࡭࡫ࠠࡨࡷ࡬ࡨࡪࠦ࡯࡯ࠢࡲࡸ࡭࡫ࡲࠡࡦࡨࡺ࡮ࡩࡥࠩࡵࠬࠤࡴࡸࠠࡸࡣ࡬ࡸࠥ࠻ࠠ࡮࡫ࡱࡹࡹ࡫ࡳࠡࡣࡱࡨࠥࡺࡲࡺࠢࡤ࡫ࡦ࡯࡮ࠢࠢࡌࡪࠥࡿ࡯ࡶࠢࡷ࡬࡮ࡴ࡫ࠡࡶ࡫࡭ࡸࠦࡩࡴࠢࡺࡶࡴࡴࡧ࠭ࠢࡳࡰࡪࡧࡳࡦࠢࡶࡹࡧࡳࡩࡵࠢࡤࠤࡹ࡯ࡣ࡬ࡧࡷ࠲ࠬ୳"),l1ll1_opy_ (u"࠭ࠧ୴"))
                self.i.close()
            if l1ll1_opy_ (u"ࠧࡤࡪࡨࡧࡰࡵࡵࡵ࠯ࡩࡳࡷࡳࠧ୵") in data:
                dialog.ok(l1ll1_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡨࡩ࠸࠻࠾࠲ࡣ࠶ࡠࡑࡠࡉࡏࡍࡑࡕࠤ࡫࡬ࡃ࠱ࡅ࠳ࡇ࠵ࡣࡡࡺࡨࡤ࡭ࡷ࡛ࠦࡄࡑࡏࡓࡗࠦࡦࡧ࠶࠹࠼࠷ࡨ࠴࡞ࡉ࡞ࡇࡔࡒࡏࡓࠢࡩࡪࡈ࠶ࡃ࠱ࡅ࠳ࡡࡺ࡯ࡤࡦ࡝ࡆࡓࡑࡕࡒࠡࡩࡲࡰࡩࡣࠠࡑࡔࡒ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ୶"),l1ll1_opy_ (u"ࠩࡌࡸࠥࡧࡰࡱࡧࡤࡶࡸࠦࡹࡰࡷࡵࠤࡸࡻࡢࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠣࡱࡦࡿࠠࡩࡣࡹࡩࠥ࡫ࡸࡱ࡫ࡵࡩࡩࠦ࡯ࡳࠢࡼࡳࡺࠦࡨࡢࡸࡨࠤࡪࡴࡴࡦࡴࡨࡨࠥࡽࡲࡰࡰࡪࠤࡱࡵࡧࡪࡰࠣࡨࡪࡺࡡࡪ࡮ࡶ࠲ࠬ୷"),l1ll1_opy_ (u"ࠪࡔࡱ࡫ࡡࡴࡧࠣࡶࡪࡳࡥ࡮ࡤࡨࡶࠥࡿ࡯ࡶࡴࠣࡩࡲࡧࡩ࡭ࠢ࡬ࡷࠥࡔࡏࡕࠢࡼࡳࡺࡸࠠࡶࡵࡨࡶࡳࡧ࡭ࡦ࠰ࠪ୸"),l1ll1_opy_ (u"ࠫ࡞ࡵࡵࠡࡥࡤࡲࠥࡸࡥ࠮ࡵࡸࡦࡸࡩࡲࡪࡤࡨࠤࡦࡺ࠺ࠡࡪࡷࡸࡵࡀ࠯࠰࡯ࡤࡽ࡫ࡧࡩࡳࡩࡸ࡭ࡩ࡫ࡳ࠯ࡥࡲࡱ࠴ࡶࡲࡰࠩ୹"))
                yesno = dialog.yesno(l1ll1_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥ࡬ࡦ࠵࠸࠻࠶ࡧ࠺࡝ࡎ࡝ࡆࡓࡑࡕࡒࠡࡨࡩࡇ࠵ࡉ࠰ࡄ࠲ࡠࡥࡾ࡬ࡡࡪࡴࠣ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫࠺࠶࠹࠴ࡥ࠸ࡢࡍ࡛ࡄࡑࡏࡓࡗࠦࡦࡧࡅ࠳ࡇ࠵ࡉ࠰࡞ࡷ࡬ࡨࡪࡡࡃࡐࡎࡒࡖࠥ࡭࡯࡭ࡦࡠࠤࡕࡘࡏ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ୺"),l1ll1_opy_ (u"࠭ࡄࡰࠢࡼࡳࡺࠦࡷࡪࡵ࡫ࠤࡹࡵࠠࡳࡧ࠰ࡩࡳࡺࡥࡳࠢࡼࡳࡺࡸࠠ࡭ࡱࡪ࡭ࡳࠦࡤࡦࡶࡤ࡭ࡱࡹࠠ࡯ࡱࡺࡃࠬ୻"),l1ll1_opy_ (u"ࠧࠨ୼"),l1ll1_opy_ (u"ࠨࠩ୽"))
                if yesno:
                    lolol.l1llll_opy_()
                self.i.close()
            else:
                return data
        except requests.exceptions.SSLError:
            lolol.hide_busy_dialog()
            dialog.ok(l1ll1_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡩࡪ࠹࠼࠸࠳ࡤ࠷ࡡࡒࡡࡃࡐࡎࡒࡖࠥ࡬ࡦࡄ࠲ࡆ࠴ࡈ࠶࡝ࡢࡻࡩࡥ࡮ࡸࠠ࡜ࡅࡒࡐࡔࡘࠠࡧࡨ࠷࠺࠽࠸ࡢ࠵࡟ࡊ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫ࡉ࠰ࡄ࠲ࡆ࠴ࡢࡻࡩࡥࡧ࡞ࡇࡔࡒࡏࡓࠢࡪࡳࡱࡪ࡝ࠡࡒࡕࡓࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭୾"),l1ll1_opy_ (u"ࠪࡍࡹࠦࡡࡱࡲࡨࡥࡷࡹࠠࡺࡱࡸࡶࠥࡹࡵࡣࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠤࡲࡧࡹࠡࡪࡤࡺࡪࠦࡥࡹࡲ࡬ࡶࡪࡪࠠࡰࡴࠣࡽࡴࡻࠠࡩࡣࡹࡩࠥ࡫࡮ࡵࡧࡵࡩࡩࠦࡷࡳࡱࡱ࡫ࠥࡲ࡯ࡨ࡫ࡱࠤࡩ࡫ࡴࡢ࡫࡯ࡷ࠳࠭୿"),l1ll1_opy_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡷ࡫࡭ࡦ࡯ࡥࡩࡷࠦࡹࡰࡷࡵࠤࡪࡳࡡࡪ࡮ࠣ࡭ࡸࠦࡎࡐࡖࠣࡽࡴࡻࡲࠡࡷࡶࡩࡷࡴࡡ࡮ࡧ࠱ࠫ஀"),l1ll1_opy_ (u"ࠬ࡟࡯ࡶࠢࡦࡥࡳࠦࡲࡦ࠯ࡶࡹࡧࡹࡣࡳ࡫ࡥࡩࠥࡧࡴ࠻ࠢ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡥࡾ࡬ࡡࡪࡴࡪࡹ࡮ࡪࡥࡴ࠰ࡦࡳࡲ࠵ࡰࡳࡱࠪ஁"))
            yesno = dialog.yesno(l1ll1_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡦࡧ࠶࠹࠼࠷ࡨ࠴࡞ࡏ࡞ࡇࡔࡒࡏࡓࠢࡩࡪࡈ࠶ࡃ࠱ࡅ࠳ࡡࡦࡿࡦࡢ࡫ࡵࠤࡠࡉࡏࡍࡑࡕࠤ࡫࡬࠴࠷࠺࠵ࡦ࠹ࡣࡇ࡜ࡅࡒࡐࡔࡘࠠࡧࡨࡆ࠴ࡈ࠶ࡃ࠱࡟ࡸ࡭ࡩ࡫࡛ࡄࡑࡏࡓࡗࠦࡧࡰ࡮ࡧࡡࠥࡖࡒࡐ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪஂ"),l1ll1_opy_ (u"ࠧࡅࡱࠣࡽࡴࡻࠠࡸ࡫ࡶ࡬ࠥࡺ࡯ࠡࡴࡨ࠱ࡪࡴࡴࡦࡴࠣࡽࡴࡻࡲࠡ࡮ࡲ࡫࡮ࡴࠠࡥࡧࡷࡥ࡮ࡲࡳࠡࡰࡲࡻࡄ࠭ஃ"),l1ll1_opy_ (u"ࠨࠩ஄"),l1ll1_opy_ (u"ࠩࠪஅ"))
            if yesno:
                lolol.l1llll_opy_()
            self.i.close()
    def l1l1l1_opy_(self, filePath):
        with open(filePath, l1ll1_opy_ (u"ࠪࡶࡧ࠭ஆ")) as may:
            l11_opy_ = hashlib.md5()
            while True:
                data = may.read(8192).decode(l1ll1_opy_ (u"ࠦ࡭࡫ࡸࠣஇ"))
                if not data:
                    break
                l11_opy_.update(data)
            return l11_opy_.hexdigest()
    def donotice(self):
        if not os.path.exists(self.NOTICE):
            l1l1lll11_opy_ = self.l1_opy_(lolol.lolf(l1ll1_opy_ (u"ࠬࡔࡏࡕࡋࡆࡉ࠳࡯࡮ࡪࠩஈ")))
            if len(l1l1lll11_opy_)>1:
                try:
                    l1l11lll1_opy_ = open(self.NOTICE, l1ll1_opy_ (u"ࠨࡷࠣஉ"))
                    l1l11lll1_opy_.write(l1l1lll11_opy_.encode(l1ll1_opy_ (u"ࠢࡩࡧࡻࠦஊ")))
                    l1l11lll1_opy_.close()
                    f = open(self.NOTICE,mode=l1ll1_opy_ (u"ࠨࡴࠪ஋")); msg = f.read(); f.close()
                    self.l1l1111ll_opy_(l1ll1_opy_ (u"ࠤࠨࡷࠧ஌") % msg.decode(l1ll1_opy_ (u"ࠥ࡬ࡪࡾࠢ஍")))
                except: pass
        else:
            l1l1l1l1l_opy_ = self.l1_opy_(lolol.lolf(l1ll1_opy_ (u"ࠫࡓࡕࡔࡊࡅࡈ࠲ࡲࡪ࠵ࠨஎ")))
            if len(l1l1l1l1l_opy_)>1:
                try:
                    if not l1l1l1l1l_opy_ == self.l1l1l1_opy_(self.NOTICE):
                        l1l1lll11_opy_ = self.l1_opy_(lolol.lolf(l1ll1_opy_ (u"ࠬࡔࡏࡕࡋࡆࡉ࠳࡯࡮ࡪࠩஏ")))
                        l1l11lll1_opy_ = open(self.NOTICE, l1ll1_opy_ (u"ࠨࡷࠣஐ"))
                        l1l11lll1_opy_.write(l1l1lll11_opy_.encode(l1ll1_opy_ (u"ࠢࡩࡧࡻࠦ஑")))
                        l1l11lll1_opy_.close()
                        f = open(self.NOTICE,mode=l1ll1_opy_ (u"ࠨࡴࠪஒ")); msg = f.read(); f.close()
                        self.l1l1111ll_opy_(l1ll1_opy_ (u"ࠤࠨࡷࠧஓ") % msg.decode(l1ll1_opy_ (u"ࠥ࡬ࡪࡾࠢஔ")))
                except: pass
    def l1l11llll_opy_(self):
        URL      = l1ll1_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡧࡹࡧࡣ࡬ࡶ࡬ࡻࡩࡥࡧࡶ࠲ࡨࡵ࡭࠰ࡲࡵࡳ࠴ࡧࡣࡤࡱࡸࡲࡹ࠵ࠧக")
        try:
            lolol.show_busy_dialog()
            request = self.l1l1llll1_opy_.post(URL)
            l1l11ll1l_opy_ = request.content
            l1ll11l1l_opy_ = re.findall(l1ll1_opy_ (u"ࡷ࠭ࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯࠭ࡂ࠭ࠧࠦ࡮ࡢ࡯ࡨࡁࠧࡽࡳࡠࡲ࡯ࡹ࡬࡯࡮ࡠࡡࡶ࠶ࡲ࡫࡭ࡣࡧࡵࡣࡵࡸ࡯ࡧ࡫࡯ࡩࡤࡻࡳࡦࡴࡢࡧࡺࡹࡴࡰ࡯ࡢࡰ࡮ࡴࡥࡶࡲࠥࠤ࡮ࡪ࠽ࠣࡹࡶ࠱ࡵࡲࡵࡨ࡫ࡱ࠱࠲ࡹ࠲࡮ࡧࡰࡦࡪࡸ࠭ࡱࡴࡲࡪ࡮ࡲࡥ࠮ࡷࡶࡩࡷ࠳ࡣࡶࡵࡷࡳࡲ࠳࡬ࡪࡰࡨࡹࡵࠨࠧ஖"), l1l11ll1l_opy_)
            l1ll11l1l_opy_ = l1ll1_opy_ (u"࠭ࠧ஗").join(l1ll11l1l_opy_)
            l1ll11l1l_opy_ = l1ll11l1l_opy_.replace(l1ll1_opy_ (u"ࠧࠧࡳࡸࡳࡹࡁࠧ஘"),l1ll1_opy_ (u"ࠨࠤࠪங"))
            try:
                l1l1lll1l_opy_ = json.loads(l1ll11l1l_opy_)
            except ValueError as e:
                if str(e) == l1ll1_opy_ (u"ࠩࡑࡳࠥࡐࡓࡐࡐࠣࡳࡧࡰࡥࡤࡶࠣࡧࡴࡻ࡬ࡥࠢࡥࡩࠥࡪࡥࡤࡱࡧࡩࡩ࠭ச"):
                    lolol.hide_busy_dialog()
                    return None
            for id,weight,visible in l1l1lll1l_opy_:
                id = id.decode(l1ll1_opy_ (u"ࠥ࡬ࡪࡾࠢ஛"))
                if id == l1ll1_opy_ (u"࡙ࠫ࡯࡭ࡦࠢࡘࡴࡩࡧࡴࡦࡦࠪஜ"):
                    lolol.hide_busy_dialog()
                    return weight
                else:
                    lolol.hide_busy_dialog()
                    return None
        except:
            lolol.hide_busy_dialog()
            import sys
            import traceback as tb
            (etype, value, traceback) = sys.exc_info()
            tb.print_exception(etype, value, traceback)
            dialog.ok(l1ll1_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥ࡬ࡦ࠵࠸࠻࠶ࡧ࠺࡝ࡎ࡝ࡆࡓࡑࡕࡒࠡࡨࡩࡇ࠵ࡉ࠰ࡄ࠲ࡠࡥࡾ࡬ࡡࡪࡴࠣ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫࠺࠶࠹࠴ࡥ࠸ࡢࡍ࡛ࡄࡑࡏࡓࡗࠦࡦࡧࡅ࠳ࡇ࠵ࡉ࠰࡞ࡷ࡬ࡨࡪࡡࡃࡐࡎࡒࡖࠥ࡭࡯࡭ࡦࡠࠤࡕࡘࡏ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ஝"),l1ll1_opy_ (u"࠭ࡓࡰ࡯ࡨࡸ࡭࡯࡮ࡨࠢࡺࡩࡳࡺࠠࡸࡴࡲࡲ࡬ࠦࡷࡪࡶ࡫ࠤ࡫࡫ࡴࡤࡪ࡬ࡲ࡬ࠦࡣࡶࡵࡷࡳࡲࠦ࡬ࡪࡰࡨࡹࡵࠦࡴࡪ࡯ࡨࠤࡩࡧࡴࡢࠢࡩࡶࡴࡳࠠࡢࡥࡦࡳࡺࡴࡴ࠯ࠩஞ"),l1ll1_opy_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡵࡴࡼࠤࡦ࡭ࡡࡪࡰ࠯ࠤࡴࡸࠠࡳࡧࡳࡳࡷࡺࠠࡵࡪ࡬ࡷࠥࡨࡵࡨࠢࡹ࡭ࡦࠦ࡯ࡶࡴࠣࡪࡦࡩࡥࡣࡱࡲ࡯ࠥࡵࡲࠡࡶ࡬ࡧࡰ࡫ࡴࠡࡵࡼࡷࡹ࡫࡭࠯ࠩட"))
            return None
    def l1l11ll11_opy_(self):
        URL      = l1ll1_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡯ࡤࡽ࡫ࡧࡩࡳࡩࡸ࡭ࡩ࡫ࡳ࠯ࡥࡲࡱ࠴ࡶࡲࡰ࠱ࡤࡧࡨࡵࡵ࡯ࡶ࠲ࠫ஠")
        try:
            request = self.l1l1llll1_opy_.post(URL)
            l1l11ll1l_opy_ = request.content
            l1ll11l1l_opy_ = re.findall(l1ll1_opy_ (u"ࡴࠪࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠱࠿ࠪࠤࠣࡲࡦࡳࡥ࠾ࠤࡺࡷࡤࡶ࡬ࡶࡩ࡬ࡲࡤࡥࡳ࠳࡯ࡨࡱࡧ࡫ࡲࡠࡲࡵࡳ࡫࡯࡬ࡦࡡࡸࡷࡪࡸ࡟ࡤࡷࡶࡸࡴࡳ࡟࡭࡫ࡱࡩࡺࡶࠢࠡ࡫ࡧࡁࠧࡽࡳ࠮ࡲ࡯ࡹ࡬࡯࡮࠮࠯ࡶ࠶ࡲ࡫࡭ࡣࡧࡵ࠱ࡵࡸ࡯ࡧ࡫࡯ࡩ࠲ࡻࡳࡦࡴ࠰ࡧࡺࡹࡴࡰ࡯࠰ࡰ࡮ࡴࡥࡶࡲࠥࠫ஡"), l1l11ll1l_opy_)
            l1ll11l1l_opy_ = l1ll1_opy_ (u"ࠪࠫ஢").join(l1ll11l1l_opy_)
            l1ll11l1l_opy_ = l1ll11l1l_opy_.replace(l1ll1_opy_ (u"ࠫࠫࡷࡵࡰࡶ࠾ࠫண"),l1ll1_opy_ (u"ࠬࠨࠧத"))
            l1l1lll1l_opy_ = json.loads(l1ll11l1l_opy_)
            self.i.kek.setCustomLineUp(l1l1lll1l_opy_)
        except:
            import sys
            import traceback as tb
            (etype, value, traceback) = sys.exc_info()
            tb.print_exception(etype, value, traceback)
            dialog.ok(l1ll1_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡦࡧ࠶࠹࠼࠷ࡨ࠴࡞ࡏ࡞ࡇࡔࡒࡏࡓࠢࡩࡪࡈ࠶ࡃ࠱ࡅ࠳ࡡࡦࡿࡦࡢ࡫ࡵࠤࡠࡉࡏࡍࡑࡕࠤ࡫࡬࠴࠷࠺࠵ࡦ࠹ࡣࡇ࡜ࡅࡒࡐࡔࡘࠠࡧࡨࡆ࠴ࡈ࠶ࡃ࠱࡟ࡸ࡭ࡩ࡫࡛ࡄࡑࡏࡓࡗࠦࡧࡰ࡮ࡧࡡࠥࡖࡒࡐ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ஥"),l1ll1_opy_ (u"ࠧࡔࡱࡰࡩࡹ࡮ࡩ࡯ࡩࠣࡻࡪࡴࡴࠡࡹࡵࡳࡳ࡭ࠠࡸ࡫ࡷ࡬ࠥ࡬ࡥࡵࡥ࡫࡭ࡳ࡭ࠠࡤࡷࡶࡸࡴࡳࠠ࡭࡫ࡱࡩࡺࡶࠠࡥࡣࡷࡥࠥ࡬ࡲࡰ࡯ࠣࡥࡨࡩ࡯ࡶࡰࡷ࠲ࠬ஦"),l1ll1_opy_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡶࡵࡽࠥࡧࡧࡢ࡫ࡱ࠰ࠥࡵࡲࠡࡴࡨࡴࡴࡸࡴࠡࡶ࡫࡭ࡸࠦࡢࡶࡩࠣࡺ࡮ࡧࠠࡰࡷࡵࠤ࡫ࡧࡣࡦࡤࡲࡳࡰࠦ࡯ࡳࠢࡷ࡭ࡨࡱࡥࡵࠢࡶࡽࡸࡺࡥ࡮࠰ࠪ஧"))
    def submituserlineup(self):
        URL      = l1ll1_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡥࡾ࡬ࡡࡪࡴࡪࡹ࡮ࡪࡥࡴ࠰ࡦࡳࡲ࠵ࡰࡳࡱ࠲ࡥࡨࡩ࡯ࡶࡰࡷ࠳ࠬந")
        l1l111ll1_opy_ = self.i.kek.getCustomLineUp()
        try:
            request = self.l1l1llll1_opy_.post(URL)
            l1l11ll1l_opy_ = request.content
            l1l1ll111_opy_ = re.findall(l1ll1_opy_ (u"ࡵࠫࡳࡧ࡭ࡦ࠿ࠥࡻࡸࡥࡰ࡭ࡷࡪ࡭ࡳࡥ࡟ࡴ࠴ࡰࡩࡲࡨࡥࡳࡡࡳࡶࡴ࡬ࡩ࡭ࡧࡢࡨ࡮ࡹࡰ࡭ࡣࡼࡣࡳࡧ࡭ࡦࠤࠣ࡭ࡩࡃࠢࡸࡵ࠰ࡴࡱࡻࡧࡪࡰ࠰࠱ࡸ࠸࡭ࡦ࡯ࡥࡩࡷ࠳ࡰࡳࡱࡩ࡭ࡱ࡫࠭ࡥ࡫ࡶࡴࡱࡧࡹ࠮ࡰࡤࡱࡪࠨࠠࡤ࡮ࡤࡷࡸࡃࠢࡸࡵ࠰ࡴࡱࡻࡧࡪࡰ࠰࠱ࡸ࠸࡭ࡦ࡯ࡥࡩࡷ࠳ࡰࡳࡱࡩ࡭ࡱ࡫࠭ࡧ࡫ࡨࡰࡩࠦࡦࡰࡴࡰ࠱ࡨࡵ࡮ࡵࡴࡲࡰࠧࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯࠭ࡂ࠭ࠧࠦࡴࡢࡤ࡬ࡲࡩ࡫ࡸ࠾ࠩன"), l1l11ll1l_opy_)
            l1l1ll111_opy_ = l1ll1_opy_ (u"ࠫࠬப").join(l1l1ll111_opy_)
            email = re.findall(l1ll1_opy_ (u"ࡷ࠭࡮ࡢ࡯ࡨࡁࠧࡽࡳࡠࡲ࡯ࡹ࡬࡯࡮ࡠࡡࡶ࠶ࡲ࡫࡭ࡣࡧࡵࡣࡵࡸ࡯ࡧ࡫࡯ࡩࡤ࡫࡭ࡢ࡫࡯ࠦࠥ࡯ࡤ࠾ࠤࡺࡷ࠲ࡶ࡬ࡶࡩ࡬ࡲ࠲࠳ࡳ࠳࡯ࡨࡱࡧ࡫ࡲ࠮ࡲࡵࡳ࡫࡯࡬ࡦ࠯ࡨࡱࡦ࡯࡬ࠣࠢࡦࡰࡦࡹࡳ࠾ࠤࡺࡷ࠲ࡶ࡬ࡶࡩ࡬ࡲ࠲࠳ࡳ࠳࡯ࡨࡱࡧ࡫ࡲ࠮ࡲࡵࡳ࡫࡯࡬ࡦ࠯ࡩ࡭ࡪࡲࡤࠡࡨࡲࡶࡲ࠳ࡣࡰࡰࡷࡶࡴࡲࠢࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠯ࡄ࠯ࠢࠡࡶࡤࡦ࡮ࡴࡤࡦࡺࡀࠫ஫"), l1l11ll1l_opy_)
            email = l1ll1_opy_ (u"࠭ࠧ஬").join(email)
            l1l1ll1l1_opy_ = re.findall(l1ll1_opy_ (u"ࡲࠨࡰࡤࡱࡪࡃࠢࡸࡵࡢࡴࡱࡻࡧࡪࡰࡢࡣࡸ࠸࡭ࡦ࡯ࡥࡩࡷࡥࡰࡳࡱࡩ࡭ࡱ࡫࡟ࡧ࡫ࡵࡷࡹࡥ࡮ࡢ࡯ࡨࠦࠥ࡯ࡤ࠾ࠤࡺࡷ࠲ࡶ࡬ࡶࡩ࡬ࡲ࠲࠳ࡳ࠳࡯ࡨࡱࡧ࡫ࡲ࠮ࡲࡵࡳ࡫࡯࡬ࡦ࠯ࡩ࡭ࡷࡹࡴ࠮ࡰࡤࡱࡪࠨࠠࡤ࡮ࡤࡷࡸࡃࠢࡸࡵ࠰ࡴࡱࡻࡧࡪࡰ࠰࠱ࡸ࠸࡭ࡦ࡯ࡥࡩࡷ࠳ࡰࡳࡱࡩ࡭ࡱ࡫࠭ࡧ࡫ࡨࡰࡩࠦࡦࡰࡴࡰ࠱ࡨࡵ࡮ࡵࡴࡲࡰࠧࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯࠭ࡂ࠭ࠧࠦࡴࡢࡤ࡬ࡲࡩ࡫ࡸ࠾ࠩ஭"), l1l11ll1l_opy_)
            l1l1ll1l1_opy_ = l1ll1_opy_ (u"ࠨࠩம").join(l1l1ll1l1_opy_)
            l1ll11ll1_opy_ = re.findall(l1ll1_opy_ (u"ࡴࠪࡲࡦࡳࡥ࠾ࠤࡺࡷࡤࡶ࡬ࡶࡩ࡬ࡲࡤࡥࡳ࠳࡯ࡨࡱࡧ࡫ࡲࡠࡲࡵࡳ࡫࡯࡬ࡦࡡ࡯ࡥࡸࡺ࡟࡯ࡣࡰࡩࠧࠦࡩࡥ࠿ࠥࡻࡸ࠳ࡰ࡭ࡷࡪ࡭ࡳ࠳࠭ࡴ࠴ࡰࡩࡲࡨࡥࡳ࠯ࡳࡶࡴ࡬ࡩ࡭ࡧ࠰ࡰࡦࡹࡴ࠮ࡰࡤࡱࡪࠨࠠࡤ࡮ࡤࡷࡸࡃࠢࡸࡵ࠰ࡴࡱࡻࡧࡪࡰ࠰࠱ࡸ࠸࡭ࡦ࡯ࡥࡩࡷ࠳ࡰࡳࡱࡩ࡭ࡱ࡫࠭ࡧ࡫ࡨࡰࡩࠦࡦࡰࡴࡰ࠱ࡨࡵ࡮ࡵࡴࡲࡰࠧࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯࠭ࡂ࠭ࠧࠦࡴࡢࡤ࡬ࡲࡩ࡫ࡸ࠾ࠩய"), l1l11ll1l_opy_)
            l1ll11ll1_opy_ = l1ll1_opy_ (u"ࠪࠫர").join(l1ll11ll1_opy_)
            save = re.findall(l1ll1_opy_ (u"ࡶࠬࡴࡡ࡮ࡧࡀࠦࡼࡹ࡟ࡱ࡮ࡸ࡫࡮ࡴ࡟ࡠࡵ࠵ࡱࡪࡳࡢࡦࡴࡢࡴࡷࡵࡦࡪ࡮ࡨࡣࡸࡧࡶࡦࠤࠣ࡭ࡩࡃࠢࡸࡵ࠰ࡴࡱࡻࡧࡪࡰ࠰࠱ࡸ࠸࡭ࡦ࡯ࡥࡩࡷ࠳ࡰࡳࡱࡩ࡭ࡱ࡫࠭ࡴࡣࡹࡩࠧࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯࠭ࡂ࠭ࠧࠦ࠯࠿ࠩற"), l1l11ll1l_opy_)
            save = l1ll1_opy_ (u"ࠬ࠭ல").join(save)
            l1l111l11_opy_ = re.findall(l1ll1_opy_ (u"ࡸࠧ࡯ࡣࡰࡩࡂࠨࡷࡴࡡࡳࡰࡺ࡭ࡩ࡯ࡡࡢࡷ࠷ࡳࡥ࡮ࡤࡨࡶࡤࡹࡣࡠࡲࡵࡳ࡫࡯࡬ࡦࡡࡶࡥࡻ࡫ࠢࠡ࡫ࡧࡁࠧࡽࡳ࠮ࡲ࡯ࡹ࡬࡯࡮࠮࠯ࡶ࠶ࡲ࡫࡭ࡣࡧࡵ࠱ࡸࡩ࠭ࡱࡴࡲࡪ࡮ࡲࡥ࠮ࡵࡤࡺࡪࠨࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠮ࡃ࠮ࠨࠠ࠰ࡀࠪள"), l1l11ll1l_opy_)
            l1l111l11_opy_ = l1ll1_opy_ (u"ࠧࠨழ").join(l1l111l11_opy_)
            data  = {l1ll1_opy_ (u"ࠨࡹࡶࡣࡵࡲࡵࡨ࡫ࡱࡣࡤࡹ࠲࡮ࡧࡰࡦࡪࡸ࡟ࡱࡴࡲࡪ࡮ࡲࡥࡠࡧࡰࡥ࡮ࡲࠧவ") : email, l1ll1_opy_ (u"ࠩࡺࡷࡤࡶ࡬ࡶࡩ࡬ࡲࡤࡥࡳ࠳࡯ࡨࡱࡧ࡫ࡲࡠࡲࡵࡳ࡫࡯࡬ࡦࡡࡩ࡭ࡷࡹࡴࡠࡰࡤࡱࡪ࠭ஶ") : l1l1ll1l1_opy_, l1ll1_opy_ (u"ࠪࡻࡸࡥࡰ࡭ࡷࡪ࡭ࡳࡥ࡟ࡴ࠴ࡰࡩࡲࡨࡥࡳࡡࡳࡶࡴ࡬ࡩ࡭ࡧࡢࡰࡦࡹࡴࡠࡰࡤࡱࡪ࠭ஷ") : l1ll11ll1_opy_, l1ll1_opy_ (u"ࠫࡼࡹ࡟ࡱ࡮ࡸ࡫࡮ࡴ࡟ࡠࡵ࠵ࡱࡪࡳࡢࡦࡴࡢࡴࡷࡵࡦࡪ࡮ࡨࡣࡩ࡯ࡳࡱ࡮ࡤࡽࡤࡴࡡ࡮ࡧࠪஸ") : l1l1ll111_opy_, l1ll1_opy_ (u"ࠬࡽࡳࡠࡲ࡯ࡹ࡬࡯࡮ࡠࡡࡶ࠶ࡲ࡫࡭ࡣࡧࡵࡣࡵࡸ࡯ࡧ࡫࡯ࡩࡤࡻࡳࡦࡴࡢࡧࡺࡹࡴࡰ࡯ࡢࡰ࡮ࡴࡥࡶࡲࠪஹ") : l1l111ll1_opy_, l1ll1_opy_ (u"࠭ࡷࡴࡡࡳࡰࡺ࡭ࡩ࡯ࡡࡢࡷ࠷ࡳࡥ࡮ࡤࡨࡶࡤࡶࡲࡰࡨ࡬ࡰࡪࡥࡰࡢࡵࡶࡻࡴࡸࡤ࠲ࠩ஺") : l1ll1_opy_ (u"ࠧࠨ஻"), l1ll1_opy_ (u"ࠨࡹࡶࡣࡵࡲࡵࡨ࡫ࡱࡣࡤࡹ࠲࡮ࡧࡰࡦࡪࡸ࡟ࡱࡴࡲࡪ࡮ࡲࡥࡠࡲࡤࡷࡸࡽ࡯ࡳࡦ࠵ࠫ஼") : l1ll1_opy_ (u"ࠩࠪ஽"), l1ll1_opy_ (u"ࠪࡻࡸࡥࡰ࡭ࡷࡪ࡭ࡳࡥ࡟ࡴ࠴ࡰࡩࡲࡨࡥࡳࡡࡶࡧࡤࡶࡲࡰࡨ࡬ࡰࡪࡥࡳࡢࡸࡨࠫா") : l1l111l11_opy_, l1ll1_opy_ (u"ࠫࡼࡹ࡟ࡱ࡮ࡸ࡫࡮ࡴ࡟ࡠࡵ࠵ࡱࡪࡳࡢࡦࡴࡢࡴࡷࡵࡦࡪ࡮ࡨࡣࡸࡧࡶࡦࠩி") : save}
            request  = self.l1l1llll1_opy_.post(URL, data=data)
        except:
            import sys
            import traceback as tb
            (etype, value, traceback) = sys.exc_info()
            tb.print_exception(etype, value, traceback)
            dialog.ok(l1ll1_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥ࡬ࡦ࠵࠸࠻࠶ࡧ࠺࡝ࡎ࡝ࡆࡓࡑࡕࡒࠡࡨࡩࡇ࠵ࡉ࠰ࡄ࠲ࡠࡥࡾ࡬ࡡࡪࡴࠣ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫࠺࠶࠹࠴ࡥ࠸ࡢࡍ࡛ࡄࡑࡏࡓࡗࠦࡦࡧࡅ࠳ࡇ࠵ࡉ࠰࡞ࡷ࡬ࡨࡪࡡࡃࡐࡎࡒࡖࠥ࡭࡯࡭ࡦࡠࠤࡕࡘࡏ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩீ"),l1ll1_opy_ (u"࠭ࡅࡳࡴࡲࡶࠦࠦࡓࡰ࡯ࡨࡸ࡭࡯࡮ࡨࠢࡺࡩࡳࡺࠠࡸࡴࡲࡲ࡬ࠦࡷࡪࡶ࡫ࠤࡸࡻࡢ࡮࡫ࡷࡸ࡮ࡴࡧࠡࡥࡸࡷࡹࡵ࡭ࠡ࡮࡬ࡲࡪࡻࡰࠡࡦࡤࡸࡦࠦࡴࡰࠢࡤࡧࡨࡵࡵ࡯ࡶ࠱ࠫு"),l1ll1_opy_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡵࡴࡼࠤࡦ࡭ࡡࡪࡰ࠯ࠤࡴࡸࠠࡳࡧࡳࡳࡷࡺࠠࡵࡪ࡬ࡷࠥࡨࡵࡨࠢࡹ࡭ࡦࠦ࡯ࡶࡴࠣࡪࡦࡩࡥࡣࡱࡲ࡯ࠥࡵࡲࠡࡶ࡬ࡧࡰ࡫ࡴࠡࡵࡼࡷࡹ࡫࡭࠯ࠩூ"))
    def doacclu(self):
        l1l1l11l1_opy_ = self.l1l11llll_opy_()
        if gui.ADDON.getSetting(l1ll1_opy_ (u"ࠨࡣࡦࡧࡱࡻࠧ௃")) == l1ll1_opy_ (u"ࠩࡷࡶࡺ࡫ࠧ௄"):
            if gui.ADDON.getSetting(l1ll1_opy_ (u"ࠪࡧ࡭ࡴ࡯ࡳࡦࡨࡶࠬ௅")) == l1ll1_opy_ (u"ࠫࡈࡻࡳࡵࡱࡰࠫெ") and not l1l1l11l1_opy_:
                self.submituserlineup()
            if gui.ADDON.getSetting(l1ll1_opy_ (u"ࠬࡧࡣࡤ࡮ࡸࡰࡦࡹࡴࡶࡲࡧࡥࡹ࡫ࠧே")) != l1l1l11l1_opy_ and l1l1l11l1_opy_ is not None or gui.ADDON.getSetting(l1ll1_opy_ (u"࠭ࡣࡩࡰࡲࡶࡩ࡫ࡲࠨை")) != l1ll1_opy_ (u"ࠧࡄࡷࡶࡸࡴࡳࠧ௉") and l1l1l11l1_opy_ is not None:
                self.l1l11ll11_opy_()