# -*- coding: utf-8 -*-
import sys
l1l11_opy_ = sys.version_info [0] == 2
l111l_opy_ = 2048
l111_opy_ = 7
def l1ll1_opy_ (ll_opy_):
	global l11ll_opy_
	l1l1ll_opy_ = ord (ll_opy_ [-1])
	l1l1l_opy_ = ll_opy_ [:-1]
	l1ll1l_opy_ = l1l1ll_opy_ % len (l1l1l_opy_)
	l1l1_opy_ = l1l1l_opy_ [:l1ll1l_opy_] + l1l1l_opy_ [l1ll1l_opy_:]
	if l1l11_opy_:
		l1111_opy_ = unicode () .join ([unichr (ord (char) - l111l_opy_ - (l1lll_opy_ + l1l1ll_opy_) % l111_opy_) for l1lll_opy_, char in enumerate (l1l1_opy_)])
	else:
		l1111_opy_ = str () .join ([chr (ord (char) - l111l_opy_ - (l1lll_opy_ + l1l1ll_opy_) % l111_opy_) for l1lll_opy_, char in enumerate (l1l1_opy_)])
	return eval (l1111_opy_)
import zipfile
import time
import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui
import os
import re
import requests
import lolol
import sys
import cfscrape
import pickle
import base64
import shutil
import pyxbmct.addonwindow as pyxbmct
TITLE = l1ll1_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡧࡨ࠷࠺࠽࠸ࡢ࠵࡟ࡐ࡟࠴ࡉࡏࡍࡑࡕࡡࡠࡉࡏࡍࡑࡕࠤ࡫࡬ࡃ࠱ࡅ࠳ࡇ࠵ࡣࡡࡺࡨࡤ࡭ࡷ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝࡜ࡅࡒࡐࡔࡘࠠࡧࡨ࠷࠺࠽࠸ࡢ࠵࡟ࡊ࡟࠴ࡉࡏࡍࡑࡕࡡࡠࡉࡏࡍࡑࡕࠤ࡫࡬ࡃ࠱ࡅ࠳ࡇ࠵ࡣࡵࡪࡦࡨ࡟࠴ࡉࡏࡍࡑࡕࡡࡠࡉࡏࡍࡑࡕࠤ࡬ࡵ࡬ࡥ࡟ࠣࡔࡗࡕ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ࣪")
addon_id = l1ll1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡲࡵࡳ࡬ࡸࡡ࡮࠰ࡰࡸࡻ࡭ࡵࡪࡦࡨࡴࡷࡵࠧ࣫")
ADDON = xbmcaddon.Addon(id=addon_id)
l1lllll1l_opy_ = ADDON.getSetting(l1ll1_opy_ (u"ࠩࡶ࡯࡮ࡴࠧ࣬"))
l1lll1lll_opy_=l1ll1_opy_ (u"ࠪ࠳ࡷ࡫ࡳࡰࡷࡵࡧࡪࡹ࠯ࡱࡰࡪ࠳࣭ࠬ")
cookiefile = xbmc.translatePath(os.path.join(l1ll1_opy_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡱࡴࡲࡪ࡮ࡲࡥࠨ࣮"), l1ll1_opy_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢ࣯ࠩ"), l1ll1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡰࡳࡱࡪࡶࡦࡳ࠮࡮ࡶࡹ࡫ࡺ࡯ࡤࡦࡲࡵࡳࣰࠬ"), l1ll1_opy_ (u"ࠧࡤࡱࡲ࡯࡮࡫ࣱࠧ")))
basePath = xbmc.translatePath(os.path.join(l1ll1_opy_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡵࡸ࡯ࡧ࡫࡯ࡩࣲࠬ"), l1ll1_opy_ (u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭ࣳ"), l1ll1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡴࡷࡵࡧࡳࡣࡰ࠲ࡲࡺࡶࡨࡷ࡬ࡨࡪࡶࡲࡰࠩࣴ")))
l1ll1l11l_opy_ = xbmc.translatePath(os.path.join(l1ll1_opy_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩ࠴ࡧࡤࡥࡱࡱࡷ࠴࠭ࣵ") + addon_id + l1lll1lll_opy_, l1ll1_opy_ (u"ࠬ࡬࡯ࡤࡷࡶ࠲ࡵࡴࡧࠨࣶ")))
l1lll1l1l_opy_ = xbmc.translatePath(os.path.join(l1ll1_opy_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫࠯ࡢࡦࡧࡳࡳࡹ࠯ࠨࣷ") + addon_id + l1lll1lll_opy_, l1ll1_opy_ (u"ࠧࡣࡣࡦ࡯࡬ࡸ࡯ࡶࡰࡧ࠲ࡵࡴࡧࠨࣸ")))
window  = pyxbmct.AddonDialogWindow(TITLE)
dialog = xbmcgui.Dialog()
window.setGeometry(1000, 500, 100, 50)
background=pyxbmct.Image(l1lll1l1l_opy_)
window.placeControl(background, -2, 0, 114, 52)
def l1lll1l11_opy_():
	text=l1ll1_opy_ (u"ࠨ࠲ࡻࡊࡋࡌࡆ࠱࠲࠳࠴ࣹࠬ")
	global List
	global l1lll1ll1_opy_
	global l1llll11l_opy_
	global l1lllllll_opy_
	global Version
	global l1llll111_opy_
	lolol.show_busy_dialog()
	List = pyxbmct.List(buttonFocusTexture=l1ll1l11l_opy_,_space=11,_itemTextYOffset=-7,textColor=text)
	l1lll1ll1_opy_=pyxbmct.Image(l1ll1_opy_ (u"ࣺࠩࠪ"), aspectRatio=2)
	l1111111_opy_ = pyxbmct.Button(l1ll1_opy_ (u"ࠪࡇࡱࡵࡳࡦࠩࣻ"))
	l1llll11l_opy_ = pyxbmct.Label(l1ll1_opy_ (u"ࠫࠬࣼ"))
	l1lllllll_opy_ = pyxbmct.Label(l1ll1_opy_ (u"ࠬ࠭ࣽ"))
	Version = pyxbmct.Label(l1ll1_opy_ (u"࠭ࠧࣾ"))
	l1llll111_opy_ = pyxbmct.Label(l1ll1_opy_ (u"ࠧࠨࣿ"))
	l1lll111l_opy_ = pyxbmct.Label(l1ll1_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡩࡲࡰࡩࡣ࡛ࡃ࡟ࡓࡰࡪࡧࡳࡦࠢࡦ࡬ࡴࡵࡳࡦࠢࡤࠤࡸࡱࡩ࡯ࠢࡷࡳࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡢࡰࡧࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡠ࠵ࡂ࡞࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪऀ"))
	window.placeControl(l1lll111l_opy_, 0, 15, 110, 30)
	window.placeControl(List, 10, 1, 110, 30)
	window.placeControl(l1lll1ll1_opy_, 34, 32, 60, 18)
	window.placeControl(l1111111_opy_, 100, 46, 10, 5)
	window.placeControl(l1llll11l_opy_, 10, 32, 10, 20)
	window.placeControl(l1lllllll_opy_, 17, 32, 10, 20)
	window.placeControl(Version, 24, 32, 10, 20)
	window.placeControl(l1llll111_opy_, 31, 32, 10, 20)
	window.connectEventList(
	[pyxbmct.ACTION_MOVE_DOWN,
	pyxbmct.ACTION_MOVE_UP,
		pyxbmct.ACTION_MOUSE_MOVE],
	l1lll1111_opy_)
	List.controlRight(l1111111_opy_)
	l1111111_opy_.controlLeft(List)
	window.connect(List, getSkin)
	window.connect(l1111111_opy_, window.close)
	window.connect(pyxbmct.ACTION_NAV_BACK, window.close)
	l1ll1l1l1_opy_()
	lolol.hide_busy_dialog()
def l1ll1l1l1_opy_():
	global l1ll1ll11_opy_
	global l1lll11l1_opy_
	global l1ll1llll_opy_
	global l1llll1ll_opy_
	global l1ll1ll1l_opy_
	global l1lllll11_opy_
	global l1ll1lll1_opy_
	global headers
	l1ll1ll11_opy_=[]
	l1lll11l1_opy_=[]
	l1ll1llll_opy_=[]
	l1llll1ll_opy_=[]
	l1ll1ll1l_opy_=[]
	l1lllll11_opy_=[]
	l1ll1lll1_opy_=[]
	skins = lolol.lolf(l1ll1_opy_ (u"ࠩࡶ࡯࡮ࡴࡳ࠰ࡵ࡮࡭ࡳࡹ࠮ࡪࡰ࡬ࠫँ"))
	path  = os.path.join(basePath, l1ll1_opy_ (u"ࠪࡶࡪࡹ࡯ࡶࡴࡦࡩࡸ࠭ं"), l1ll1_opy_ (u"ࠫࡸࡱࡩ࡯ࡵࠪः"))
	try:
		currenttime = time.time()
		cookieexpire = currenttime - 870
		if os.path.exists(cookiefile):
			cookiemodifedtime = os.path.getmtime(cookiefile)
		if not os.path.exists(cookiefile) or cookiemodifedtime < cookieexpire:
			session = requests.session()
			scraper = cfscrape.create_scraper(sess=session)
			r = scraper.get(skins, auth=(lolol.lolu(), lolol.lolp()), verify=False)
			save_cookies(scraper.cookies, cookiefile)
			session.close
		else:
			r = requests.get(skins, auth=(lolol.lolu(), lolol.lolp()), verify=False, cookies=load_cookies(cookiefile))
		if r.status_code != 200:
			error = r.content.replace(l1ll1_opy_ (u"ࠬࡂࡳࡵࡴࡲࡲ࡬ࡄࠧऄ"),l1ll1_opy_ (u"࠭ࠧअ")).replace(l1ll1_opy_ (u"ࠧ࠽ࡤࡵࠤ࠴ࡄࠧआ"),l1ll1_opy_ (u"ࠨࠩइ")).replace(l1ll1_opy_ (u"ࠩ࠿࠳ࡸࡺࡲࡰࡰࡪࡂࠬई"),l1ll1_opy_ (u"ࠪࠫउ")).replace(l1ll1_opy_ (u"ࠫ࠹࠶࠱࠻ࠢࡖࡳࡷࡸࡹ࠭ࠢࡤࡧࡨ࡫ࡳࡴࠢࡧࡩࡳ࡯ࡥࡥ࠰ࠪऊ"),l1ll1_opy_ (u"࡙ࠬ࡯ࡳࡴࡼ࠰ࠥࡇࡣࡤࡧࡶࡷࠥࡪࡥ࡯࡫ࡨࡨࠦࠦࡐ࡭ࡧࡤࡷࡪࠦ࡭ࡢ࡭ࡨࠤࡸࡻࡲࡦࠢࡼࡳࡺࠦࡨࡢࡸࡨࠤࡪࡴࡴࡦࡴࡨࡨࠥࡿ࡯ࡶࡴࠣࠫऋ")+TITLE+l1ll1_opy_ (u"࠭ࠠ࡭ࡱࡪ࡭ࡳࠦࡤࡦࡶࡤ࡭ࡱࡹࠠࡤࡱࡵࡶࡪࡩࡴ࡭ࡻࠤࠫऌ"))
			dialog.ok(TITLE,l1ll1_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡳࡧࡧࡡࡊࡸࡲࡰࡴࠤ࡟࠴ࡉࡏࡍࡑࡕࡡࠬऍ"),error,l1ll1_opy_ (u"ࠨࠩऎ"))
		match = re.compile(l1ll1_opy_ (u"ࠩࡶ࡯࡮ࡴࠠ࡯ࡣࡰࡩࡂࠨࠨ࠯࠭ࡂ࠭ࠧࠦࡵࡳ࡮ࡀࠦ࠭࠴ࠫࡀࠫࠥࠤࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯࠿ࠥࠬ࠳࠱࠿ࠪࠤࠣࡺࡪࡸࡳࡪࡱࡱࡁࠧ࠮࠮ࠬࡁࠬࠦࠥ࡯࡭ࡢࡩࡨࡁࠧ࠮࠮ࠬࡁࠬࠦࠬए")).findall(r.content)
		l1ll1ll11_opy_.append(l1ll1_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡰ࡮ࡳࡥࡨࡴࡨࡩࡳࡣࡗࡢࡰࡷࠤࡹࡵࠠࡴࡷࡥࡱ࡮ࡺࠠࡢࠢࡶ࡯࡮ࡴ࠿ࠡࡅ࡯࡭ࡨࡱࠠࡩࡧࡵࡩࠥ࡬࡯ࡳࠢࡰࡳࡷ࡫ࠠࡪࡰࡩࡳࠦࡡ࠯ࡄࡑࡏࡓࡗࡣࠧऐ"))
		l1lll11l1_opy_.append(os.path.join(l1ll1_opy_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩ࠴ࡧࡤࡥࡱࡱࡷࠬऑ"), addon_id, l1ll1_opy_ (u"ࠬ࡯ࡣࡰࡰ࠱ࡴࡳ࡭ࠧऒ")))
		l1ll1llll_opy_.append(l1ll1_opy_ (u"࠭ࡎࡰࡰࡨࠫओ"))
		l1llll1ll_opy_.append(l1ll1_opy_ (u"ࠧࠨऔ"))
		l1ll1ll1l_opy_.append(l1ll1_opy_ (u"ࠨࠩक"))
		l1ll1lll1_opy_.append(l1ll1_opy_ (u"ࠩࠪख"))
		l1lllll11_opy_.append(l1ll1_opy_ (u"ࠪࠫग"))
		List.addItem(l1ll1_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡱ࡯࡭ࡦࡩࡵࡩࡪࡴ࡝ࡘࡣࡱࡸࠥࡺ࡯ࠡࡵࡸࡦࡲ࡯ࡴࠡࡣࠣࡷࡰ࡯࡮ࡀࠢࡆࡰ࡮ࡩ࡫ࠡࡪࡨࡶࡪࠦࡦࡰࡴࠣࡱࡴࡸࡥࠡ࡫ࡱࡪࡴ࡛ࠧ࠰ࡅࡒࡐࡔࡘ࡝ࠨघ"))
		for name,url,desc,ver,image in match:
			l1lllll11_opy_.append(url)
			url = lolol.lolf(l1ll1_opy_ (u"ࠬࡹ࡫ࡪࡰࡶ࠳ࠬङ")+url)
			if name == l1lllll1l_opy_ and os.path.exists(os.path.join(path, name)):
				name = name+l1ll1_opy_ (u"ࠨ࡛ࡄࡑࡏࡓࡗࠦ࡬ࡪ࡯ࡨ࡫ࡷ࡫ࡥ࡯࡟ࠣ࡟ࡈࡻࡲࡳࡧࡱࡸࡱࡿࠠࡊࡰࡶࡸࡦࡲ࡬ࡦࡦࡠ࡟࠴ࡉࡏࡍࡑࡕࡡࠧच")
			l1ll1ll11_opy_.append(name)
			l1lll11l1_opy_.append(image)
			l1ll1llll_opy_.append(url)
			l1llll1ll_opy_.append(desc)
			l1ll1ll1l_opy_.append(ver)
			if os.path.exists(os.path.join(path, name.replace(l1ll1_opy_ (u"ࠢ࡜ࡅࡒࡐࡔࡘࠠ࡭࡫ࡰࡩ࡬ࡸࡥࡦࡰࡠࠤࡠࡉࡵࡳࡴࡨࡲࡹࡲࡹࠡࡋࡱࡷࡹࡧ࡬࡭ࡧࡧࡡࡠ࠵ࡃࡐࡎࡒࡖࡢࠨछ"),l1ll1_opy_ (u"ࠨࠩज")))):
				l1ll1lll1_opy_.append(l1ll1_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢ࡯࡭ࡲ࡫ࡧࡳࡧࡨࡲࡢ࡟ࡥࡴ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪझ"))
			else:
				l1ll1lll1_opy_.append(l1ll1_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝ࡏࡱ࡞࠳ࡈࡕࡌࡐࡔࡠࠫञ"))
			List.addItem(name)
			window.setFocus(List)
	except:
		lolol.hide_busy_dialog()
		import sys
		import traceback as tb
		(etype, value, traceback) = sys.exc_info()
		tb.print_exception(etype, value, traceback)
def l1lll1111_opy_():
	global l1lll11ll_opy_
	global l1llll1l1_opy_
	global name
	global l1ll1l111_opy_
	if window.getFocus() == List:
		pos=List.getSelectedPosition()
		l1llll1l1_opy_=l1lll11l1_opy_[pos]
		name=l1ll1ll11_opy_[pos]
		author=l1llll1ll_opy_[pos]
		version=l1ll1ll1l_opy_[pos]
		downloaded=l1ll1lll1_opy_[pos]
		l1lll11ll_opy_=l1ll1llll_opy_[pos]
		l1ll1l111_opy_=l1lllll11_opy_[pos]
		l1llll11l_opy_.setLabel(l1ll1_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤ࡬ࡵ࡬ࡥ࡟ࡖ࡯࡮ࡴࠠࡏࡣࡰࡩ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨट")+name)
		l1lllllll_opy_.setLabel(l1ll1_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥ࡭࡯࡭ࡦࡠࡅࡺࡺࡨࡰࡴ࠽ࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ठ")+author)
		Version.setLabel(l1ll1_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡧࡰ࡮ࡧࡡ࡛࡫ࡲࡴ࡫ࡲࡲ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨड")+version)
		l1llll111_opy_.setLabel(l1ll1_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡨࡱ࡯ࡨࡢࡊ࡯ࡸࡰ࡯ࡳࡦࡪࡥࡥ࠼ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬढ")+downloaded)
		l1lll1ll1_opy_.setImage(l1llll1l1_opy_)
def l1llllll1_opy_():
	play=xbmc.Player()
	liz=xbmcgui.ListItem(name, iconImage=l1llll1l1_opy_,thumbnailImage=l1llll1l1_opy_)
	window.close()
	play.play(l1lll11ll_opy_, liz, False)
def getSkin():
	label = name.replace(l1ll1_opy_ (u"ࠣ࡝ࡆࡓࡑࡕࡒࠡ࡮࡬ࡱࡪ࡭ࡲࡦࡧࡱࡡࠥࡡࡃࡶࡴࡵࡩࡳࡺ࡬ࡺࠢࡌࡲࡸࡺࡡ࡭࡮ࡨࡨࡢࡡ࠯ࡄࡑࡏࡓࡗࡣࠢण"),l1ll1_opy_ (u"ࠩࠪत"))
	url = l1lll11ll_opy_
	path    = os.path.join(basePath, l1ll1_opy_ (u"ࠪࡶࡪࡹ࡯ࡶࡴࡦࡩࡸ࠭थ"), l1ll1_opy_ (u"ࠫࡸࡱࡩ࡯ࡵࠪद"))
	if l1ll1_opy_ (u"ࠬ࡝ࡡ࡯ࡶࠣࡸࡴࠦࡳࡶࡤࡰ࡭ࡹࠦࡡࠡࡵ࡮࡭ࡳ࠭ध") in name:
		dialog.ok(TITLE,l1ll1_opy_ (u"࠭ࡉࡧࠢࡼࡳࡺࠦࡷࡪࡵ࡫ࠤࡹࡵࠠࡴࡷࡥࡱ࡮ࡺࠠࡢࠢࡶ࡯࡮ࡴࠠࡴࡱࠣࡻࡪࠦࡣࡢࡰࠣ࡬ࡦࡼࡥࠡ࡫ࡷࠤࡦࡼࡡࡪ࡮ࡤࡦࡱ࡫ࠠࡧࡱࡵࠤࡴࡺࡨࡦࡴࠣࡹࡸ࡫ࡲࡴࠢࡷࡳࠥࡻࡳࡦ࠮ࠣࡴࡱ࡫ࡡࡴࡧࠣࡩࡲࡧࡩ࡭ࠢࡶ࡯࡮ࡴࡀ࡮ࡣࡼࡪࡦ࡯ࡲࡨࡷ࡬ࡨࡪࡹ࠮ࡤࡱࡰࠫन"),l1ll1_opy_ (u"ࠧࡢࡰࡧࠤࡠࡉࡏࡍࡑࡕࠤࡱ࡯࡭ࡦࡩࡵࡩࡪࡴ࡝ࡱࡴࡲࡺ࡮ࡪࡥࠡࡵ࡮࡭ࡳࠦ࡮ࡢ࡯ࡨ࠰ࡦࡻࡴࡩࡱࡵ࠰ࡸࡩࡲࡦࡧࡱࡷ࡭ࡵࡴࠡࡱࡩࠤࡸࡱࡩ࡯ࠢࡤࡲࡩࠦࡴࡩࡧࠣࡷࡰ࡯࡮ࠡࡨࡲࡰࡩ࡫ࡲࠡࡼ࡬ࡴࡵ࡫ࡤࠡࡷࡳࠤࡦࡹࠠࡦ࡯ࡤ࡭ࡱࠦࡡࡵࡶࡤࡧ࡭ࡳࡥ࡯ࡶ࠱࡟࠴ࡉࡏࡍࡑࡕࡡࠬऩ"),l1ll1_opy_ (u"ࠨࠩप"))
		dialog.ok(TITLE,l1ll1_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡵࡩࡩࡣࡐ࡭ࡧࡤࡷࡪࠦ࡮ࡰࡶࡨ࠰ࠥࡽࡥࠡࡹ࡬ࡰࡱࠦ࡮ࡰࡶࠣ࡬ࡪࡲࡰࠡࡷࡶࡩࡷࡹࠠࡤࡴࡨࡥࡹ࡫ࠠࡴ࡭࡬ࡲࡸ࠴࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨफ"),l1ll1_opy_ (u"ࠪࠫब"),l1ll1_opy_ (u"ࠫࠬभ"))
		return
	if not os.path.exists(os.path.join(path, label)):
		if DialogYesNo(l1ll1_opy_ (u"ࠬ࡝࡯ࡶ࡮ࡧࠤࡾࡵࡵࠡ࡮࡬࡯ࡪࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡦࡴࡤࠡ࡫ࡱࡷࡹࡧ࡬࡭ࠢࠪम") + l1ll1_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡯ࡳࡣࡱ࡫ࡪࡣࠧय") + label + l1ll1_opy_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩर") + l1ll1_opy_ (u"ࠨࠢࡶ࡯࡮ࡴࠠࡢࡰࡧࠤࡲࡧ࡫ࡦࠢ࡬ࡸࠥࡿ࡯ࡶࡴࠣࡥࡨࡺࡩࡷࡧࠣࡷࡰ࡯࡮ࡀࠩऱ"), l1ll1_opy_ (u"ࠩࠪल"), l1ll1_opy_ (u"ࠪࡍࡹࠦࡷࡪ࡮࡯ࠤࡧ࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࡧࡧࠤࡦࡴࡤࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤ࡮ࡴࡴࡰࠢࡼࡳࡺࡸࠠࡴࡻࡶࡸࡪࡳ࠮ࠨळ")):
			download = l1ll1l1ll_opy_(label, url, l1ll1l111_opy_)
			if download == l1ll1_opy_ (u"࡙ࠫࡸࡵࡦࠩऴ"):
				ADDON.setSetting(l1ll1_opy_ (u"ࠬࡹ࡫ࡪࡰࠪव"), label)
				dialog.ok(TITLE,l1ll1_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡯ࡳࡣࡱ࡫ࡪࡣࠧश") + label + l1ll1_opy_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩष") + l1ll1_opy_ (u"ࠨࠢࡶ࡯࡮ࡴࠠࡩࡣࡶࠤࡧ࡫ࡥ࡯ࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥࡹࡵࡤࡥࡨࡷࡸ࡬ࡵ࡭࡮ࡼ࠲ࠬस"), l1ll1_opy_ (u"ࠩࠪह"), l1ll1_opy_ (u"ࠪࡍࡹࠦࡩࡴࠢࡱࡳࡼࠦࡳࡦࡶࠣࡥࡸࠦࡹࡰࡷࡵࠤࡦࡩࡴࡪࡸࡨࠤࡸࡱࡩ࡯ࠣࠪऺ"))
				window.close()
				ADDON.openSettings()
			elif download == l1ll1_opy_ (u"ࠫࡊࡸࡲࡰࡴࠪऻ"):
				dialog.ok(TITLE,l1ll1_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡸࡥࡥ࡟ࡈࡶࡷࡵࡲࠡࡦࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬ࠦࡡ࡯ࡦࠣ࡭ࡳࡹࡴࡢ࡮࡯࡭ࡳ࡭ࠠࠨ़") + l1ll1_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡯ࡳࡣࡱ࡫ࡪࡣࠧऽ") + label + l1ll1_opy_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩा") + l1ll1_opy_ (u"ࠨࠢࡶ࡯࡮ࡴࠡ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩि"),l1ll1_opy_ (u"ࠩࡖࡳࡲ࡫ࡴࡩ࡫ࡱ࡫ࠥࡽࡥ࡯ࡶࠣࡻࡷࡵ࡮ࡨ࠰࠱ࠤࡕࡲࡥࡢࡵࡨࠤࡷ࡫ࡰࡰࡴࡷࠤࡹ࡮ࡩࡴࠢࡷࡳࠥࡹࡵࡱࡲࡲࡶࡹࠧࠧी"),l1ll1_opy_ (u"ࠪࠫु"))
	else:
		if DialogYesNo(l1ll1_opy_ (u"ࠫ࡞ࡵࡵࠡࡣ࡯ࡶࡪࡧࡤࡺࠢ࡫ࡥࡻ࡫ࠠ࡜ࡅࡒࡐࡔࡘࠠࡰࡴࡤࡲ࡬࡫࡝ࠨू") + label + l1ll1_opy_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧृ") + l1ll1_opy_ (u"࠭ࠠࡴ࡭࡬ࡲࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡥࡥ࠰࡛ࠣࡴࡻ࡬ࡥࠢࡼࡳࡺࠦ࡬ࡪ࡭ࡨࠤࡹࡵࠠࡥࡧ࡯ࡩࡹ࡫ࠠࡢࡰࡧࠤࡺࡴࡩ࡯ࡵࡷࡥࡱࡲࠠ࡜ࡅࡒࡐࡔࡘࠠࡰࡴࡤࡲ࡬࡫࡝ࠨॄ") + label + l1ll1_opy_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩॅ") + l1ll1_opy_ (u"ࠨࠢࡲࡶࠥࡳࡡ࡬ࡧࠣ࡭ࡹࠦࡹࡰࡷࡵࠤࡦࡩࡴࡪࡸࡨࠤࡸࡱࡩ࡯ࡁࠪॆ"), l1ll1_opy_ (u"ࠩࠪे"), l1ll1_opy_ (u"ࠪࠫै"), l1ll1_opy_ (u"ࠫࡉ࡫࡬ࡦࡶࡨࠤࡦࡴࡤࠡࡷࡱ࡭ࡳࡹࡴࡢ࡮࡯ࠫॉ"), l1ll1_opy_ (u"࡙ࠬࡥࡵࠢࡤࡷࠥࡧࡣࡵ࡫ࡹࡩࠥࡹ࡫ࡪࡰࠪॊ")):
			ADDON.setSetting(l1ll1_opy_ (u"࠭ࡳ࡬࡫ࡱࠫो"), label)
			dialog.ok(TITLE,l1ll1_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡰࡴࡤࡲ࡬࡫࡝ࠨौ") + label + l1ll1_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟्ࠪ") + l1ll1_opy_ (u"ࠩࠣࡷࡰ࡯࡮ࠡ࡫ࡶࠤࡳࡵࡷࠡࡵࡨࡸࠥࡧࡳࠡࡻࡲࡹࡷࠦࡡࡤࡶ࡬ࡺࡪࠦࡳ࡬࡫ࡱࠥࠬॎ"), l1ll1_opy_ (u"ࠪࠫॏ"), l1ll1_opy_ (u"ࠫࠬॐ"))
			window.close()
			ADDON.openSettings()
		else:
			if not label == l1ll1_opy_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭॑"):
				if DialogYesNo(l1ll1_opy_ (u"࠭ࡁࡳࡧࠣࡽࡴࡻࠠࡴࡷࡵࡩࠥࡿ࡯ࡶࠢࡺࡥࡳࡺࠠࡵࡱࠣࡨࡪࡲࡥࡵࡧࠣࡥࡳࡪࠠࡶࡰ࡬ࡲࡸࡺࡡ࡭࡮ࠣ࡟ࡈࡕࡌࡐࡔࠣࡳࡷࡧ࡮ࡨࡧࡠ॒ࠫ") + label + l1ll1_opy_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ॓") + l1ll1_opy_ (u"ࠨࡁࠪ॔"),l1ll1_opy_ (u"ࠩࠪॕ"),l1ll1_opy_ (u"ࠪࡘ࡭࡯ࡳࠡࡹ࡬ࡰࡱࠦࡰࡦࡴࡰࡥࡳ࡫࡮ࡵ࡮ࡼࠤࡩ࡫࡬ࡦࡶࡨࠤࡹ࡮ࡩࡴࠢࡶ࡯࡮ࡴࠠࡧࡴࡲࡱࠥࡿ࡯ࡶࡴࠣࡷࡾࡹࡴࡦ࡯࠱ࠫॖ")):
					for root, dirs, files in os.walk(os.path.join(path, label)):
						file_count = 0
						file_count += len(files)
						if file_count > 0:
							for f in files:
								try:
									os.unlink(os.path.join(root, f))
								except: pass
							for d in dirs:
								try:
									shutil.rmtree(os.path.join(root, d))
								except: pass
					if os.path.exists(os.path.join(path, label)):
						try:
							shutil.rmtree(os.path.join(path, label))
						except: pass
					if label == l1lllll1l_opy_:
						ADDON.setSetting(l1ll1_opy_ (u"ࠫࡸࡱࡩ࡯ࠩॗ"), l1ll1_opy_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭क़"))
			else:
				dialog.ok(TITLE,l1ll1_opy_ (u"࠭ࡅࡳࡴࡲࡶ࡙ࠦࠦࡰࡷࠣࡧࡦࡴ࡮ࡰࡶࠣࡨࡪࡲࡥࡵࡧࠣࡥࡳࡪࠠࡶࡰ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡸ࡭࡫ࠠࡅࡧࡩࡥࡺࡲࡴࠡࡵ࡮࡭ࡳࠧࠧख़"),l1ll1_opy_ (u"ࠧࠨग़"),l1ll1_opy_ (u"ࠨࠩज़"))
def DialogYesNo(line1, line2=l1ll1_opy_ (u"ࠩࠪड़"), line3=l1ll1_opy_ (u"ࠪࠫढ़"), noLabel=None, yesLabel=None):
	d = xbmcgui.Dialog()
	if noLabel == None or yesLabel == None:
		return d.yesno(TITLE, line1, line2 , line3) == True
	else:
		return d.yesno(TITLE, line1, line2 , line3, noLabel, yesLabel) == True
def l1ll1l1ll_opy_(label, url, filename):
	try:
		path    = os.path.join(basePath, l1ll1_opy_ (u"ࠫࡷ࡫ࡳࡰࡷࡵࡧࡪࡹࠧफ़"), l1ll1_opy_ (u"ࠬࡹ࡫ࡪࡰࡶࠫय़"), filename)
		tmpFile = os.path.join(basePath, l1ll1_opy_ (u"࠭ࡲࡦࡵࡲࡹࡷࡩࡥࡴࠩॠ"), l1ll1_opy_ (u"ࠧࡴ࡭࡬ࡲࡸ࠭ॡ"), l1ll1_opy_ (u"ࠨࡶࡰࡴࠬॢ"))
		if os.path.exists(tmpFile):
			try:
				os.remove(tmpFile)
			except:
				pass
		if os.path.exists(path):
			try:
				os.remove(path)
			except:
				pass
		if os.path.exists(path.replace(l1ll1_opy_ (u"ࠩ࠱ࡾ࡮ࡶࠧॣ"),l1ll1_opy_ (u"ࠪࠫ।"))):
			try:
				for root, dirs, files in os.walk(os.path.join(path, label)):
					file_count = 0
					file_count += len(files)
					if file_count > 0:
						for f in files:
							try:
								os.unlink(os.path.join(root, f))
							except: pass
						for d in dirs:
							try:
								shutil.rmtree(os.path.join(root, d))
							except: pass
				if os.path.exists(os.path.join(path, label)):
					try:
						shutil.rmtree(os.path.join(path, label))
					except: pass
			except:
				pass
		tmpData = mayfairdownloader(url,tmpFile,label)
		if tmpData:
			if os.path.getsize(tmpFile) > 0:
				os.rename(tmpFile, path)
				zin = zipfile.ZipFile(path, l1ll1_opy_ (u"ࠫࡷ࠭॥"))
				zin.extractall(os.path.join(basePath, l1ll1_opy_ (u"ࠬࡸࡥࡴࡱࡸࡶࡨ࡫ࡳࠨ०"), l1ll1_opy_ (u"࠭ࡳ࡬࡫ࡱࡷࠬ१")))
				zin.close()
				os.remove(path)
				return l1ll1_opy_ (u"ࠧࡕࡴࡸࡩࠬ२")
		else:
			return l1ll1_opy_ (u"ࠨࡈࡤࡰࡸ࡫ࠧ३")
	except:
		import sys
		import traceback as tb
		(etype, value, traceback) = sys.exc_info()
		tb.print_exception(etype, value, traceback)
		return l1ll1_opy_ (u"ࠩࡈࡶࡷࡵࡲࠨ४")
def mayfairdownloader(url, dest, label):
	BUFFSIZE = 1024 * 4
	progress = xbmcgui.DialogProgress()
	progress.create(TITLE,l1ll1_opy_ (u"ࠥࡈࡴࡽ࡮࡭ࡱࡤࡨ࡮ࡴࡧࠡࠨࠣࡍࡳࡹࡴࡢ࡮࡯࡭ࡳ࡭ࠠࠣ५")+label+l1ll1_opy_ (u"࡙ࠦࠥ࡫ࡪࡰ࠱࠲ࠧ६"), l1ll1_opy_ (u"ࠬࠦࠧ७"), l1ll1_opy_ (u"࠭ࠠࠨ८"))
	currenttime = time.time()
	cookieexpire = currenttime - 870
	if os.path.exists(cookiefile):
		cookiemodifedtime = os.path.getmtime(cookiefile)
	if not os.path.exists(cookiefile) or cookiemodifedtime < cookieexpire:
		session = requests.session()
		scraper = cfscrape.create_scraper(sess=session)
		r = scraper.get(url, auth=(lolol.lolu(), lolol.lolp()), verify=False, stream=True)
		save_cookies(scraper.cookies, cookiefile)
		session.close
	else:
		r = requests.get(url, auth=(lolol.lolu(), lolol.lolp()), verify=False, cookies=load_cookies(cookiefile), stream=True)
	if r.status_code != 200:
		progress.close()
		error = r.content.replace(l1ll1_opy_ (u"ࠧ࠽ࡵࡷࡶࡴࡴࡧ࠿ࠩ९"),l1ll1_opy_ (u"ࠨࠩ॰")).replace(l1ll1_opy_ (u"ࠩ࠿ࡦࡷࠦ࠯࠿ࠩॱ"),l1ll1_opy_ (u"ࠪࠫॲ")).replace(l1ll1_opy_ (u"ࠫࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄࠧॳ"),l1ll1_opy_ (u"ࠬ࠭ॴ"))
		dialog.ok(TITLE,l1ll1_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡲࡦࡦࡠࡉࡷࡸ࡯ࡳࠢࡧࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭ࠠࡢࡰࡧࠤ࡮ࡴࡳࡵࡣ࡯ࡰ࡮ࡴࡧࠡࠩॵ") + l1ll1_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡰࡴࡤࡲ࡬࡫࡝ࠨॶ") + label + l1ll1_opy_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪॷ") + l1ll1_opy_ (u"ࠩࠣࡷࡰ࡯࡮ࠢ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪॸ"),error,l1ll1_opy_ (u"ࠪࠫॹ"))
		return False
	downloaded = 0
	total = r.headers[l1ll1_opy_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸ࠲ࡲࡥ࡯ࡩࡷ࡬ࠬॺ")]\
		if l1ll1_opy_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠳࡬ࡦࡰࡪࡸ࡭࠭ॻ") in r.headers else None
	with open(dest, l1ll1_opy_ (u"࠭ࡷࡣࠩॼ")) as outfile:
		start_time = time.time()
		for chunk in r.iter_content(chunk_size=BUFFSIZE):
			outfile.write(chunk)
			downloaded += len(chunk)
			text = [l1ll1_opy_ (u"ࠧࡅࡱࡺࡲࡱࡵࡡࡥࡧࡧࠤࠪ࠴࠲ࡧࠢࡐࠫॽ") % (downloaded / 1024.0 / 1024.0)]
			completion = 0
			if total:
				elapsed = time.time() - start_time
				completion = downloaded / float(total)
				if completion > 0:
					remaining = elapsed / completion - elapsed
					text.append(l1ll1_opy_ (u"ࠨࡖ࡬ࡱࡪࠦࡲࡦ࡯ࡤ࡭ࡳ࡯࡮ࡨ࠼ࠣࠩࡸ࠭ॾ") %
								format_delta(remaining))
			progress.update(int(completion) * 100, l1ll1_opy_ (u"ࠤࡇࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭ࠠࠧࠢࡌࡲࡸࡺࡡ࡭࡮࡬ࡲ࡬ࠦࠢॿ")+label+l1ll1_opy_ (u"ࠥࠤࡘࡱࡩ࡯࠰࠱ࠦঀ"), *text)
			if progress.iscanceled():
				break
	outfile.close()
	progress.close()
	return True
def format_delta(s):
    s = int(s)
def load_cookies(filename):
    with open(filename, l1ll1_opy_ (u"ࠫࡷࡨࠧঁ")) as f:
        return pickle.load(f)
def save_cookies(requests_cookiejar, filename):
    with open(filename, l1ll1_opy_ (u"ࠬࡽࡢࠨং")) as f:
        pickle.dump(requests_cookiejar, f)
xbmc.executebuiltin(l1ll1_opy_ (u"࠭ࡄࡪࡣ࡯ࡳ࡬࠴ࡃ࡭ࡱࡶࡩ࠭࠷࠰࠲࠶࠳࠭ࠬঃ"))
l1lll1l11_opy_()
window.doModal()
del window