# coding: UTF-8
import sys
l111l111_opy_ = sys.version_info [0] == 2
l1l1l111_opy_ = 2048
l11l111l_opy_ = 7
def l1lll1_opy_ (l1ll111_opy_):
	global l1l1l1l1_opy_
	l11ll1ll_opy_ = ord (l1ll111_opy_ [-1])
	l1l1ll_opy_ = l1ll111_opy_ [:-1]
	l1lll1ll_opy_ = l11ll1ll_opy_ % len (l1l1ll_opy_)
	l1l11ll_opy_ = l1l1ll_opy_ [:l1lll1ll_opy_] + l1l1ll_opy_ [l1lll1ll_opy_:]
	if l111l111_opy_:
		l1l11l_opy_ = unicode () .join ([unichr (ord (char) - l1l1l111_opy_ - (l1111_opy_ + l11ll1ll_opy_) % l11l111l_opy_) for l1111_opy_, char in enumerate (l1l11ll_opy_)])
	else:
		l1l11l_opy_ = str () .join ([chr (ord (char) - l1l1l111_opy_ - (l1111_opy_ + l11ll1ll_opy_) % l11l111l_opy_) for l1111_opy_, char in enumerate (l1l11ll_opy_)])
	return eval (l1l11l_opy_)
import urllib,urllib2,sys,re,xbmcgui,xbmcaddon,datetime,os,json,base64,requests,pyxbmct,tools,thread,threading,time
import xml.etree.ElementTree as ElementTree
reload(sys)
sys.setdefaultencoding(l1lll1_opy_ (u"ࠫࡺࡺࡦ࠹ࠩࠀ"))
l1l1llll_opy_=l1lll1_opy_ (u"ࠧ࠻࠱࠶ࠤࠁ")
l111l1l1_opy_ = tools.get_runtime_path()
global status
global ll_opy_
ADDON = xbmcaddon.Addon(id=l1lll1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡍࡥࡢࡴࡶࡍࡕ࡚ࡖࠨࠂ"))
l11l11l1_opy_ = ADDON.getAddonInfo(l1lll1_opy_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨࠃ"))
l111ll11_opy_ = ADDON.getAddonInfo(l1lll1_opy_ (u"ࠨ࡫ࡧࠫࠄ"))
l11l1111_opy_ = ADDON.getAddonInfo(l1lll1_opy_ (u"ࠩࡱࡥࡲ࡫ࠧࠅ"))
l1llll11_opy_ = ADDON.getSetting(l1lll1_opy_ (u"ࠪࡷࡰ࡯࡮ࠨࠆ"))
l1l111l1_opy_ = ADDON.getAddonInfo(l1lll1_opy_ (u"ࠫࡵࡧࡴࡩࠩࠇ"))
l11l1l_opy_ = os.path.join(l1l111l1_opy_, l1lll1_opy_ (u"ࠬࡸࡥࡴࡱࡸࡶࡨ࡫ࡳࠨࠈ"))
l11l11l_opy_ = os.path.join(l11l1l_opy_, l1lll1_opy_ (u"࠭ࡳ࡬࡫ࡱࡷࠬࠉ"), l1llll11_opy_, l1lll1_opy_ (u"ࠧ࡮ࡧࡧ࡭ࡦ࠭ࠊ"), l1lll1_opy_ (u"ࠨࡤࡤࡧࡰ࡭ࡲࡰࡷࡱࡨ࠳ࡶ࡮ࡨࠩࠋ"))
l11_opy_ = os.path.join(l11l1l_opy_, l1lll1_opy_ (u"ࠩࡶ࡯࡮ࡴࡳࠨࠌ"), l1llll11_opy_, l1lll1_opy_ (u"ࠪࡱࡪࡪࡩࡢࠩࠍ"))
l1lll1l11_opy_ = xbmc.translatePath(os.path.join(l1lll1_opy_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩ࠴ࡧࡤࡥࡱࡱࡷࠬࠎ"),l1lll1_opy_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡊࡉࡆࡘࡓ࠮ࡋࡓࡘ࡛࠭ࠏ")))
ll_opy_ = l1lll1_opy_ (u"ࠨࡨࡵࡶࡳ࠾࠴࠵ࡴࡢࡴࡪࡩࡹࡩࡲࡦࡣࡷࡩࡸ࠴ࡣࡰ࡯࠲ࡥࡩࡪ࡯࡯࠱࡬ࡱࡦ࡭ࡥࡴ࠰ࡷࡼࡹࠨࠐ")
def run():
    global l1ll1l_opy_
    global l11l1ll1_opy_
    global l11lll_opy_
    global l1lll11_opy_
    global host
    global l1llll111_opy_
    global l111lll_opy_
    global version
    global l1l1ll11_opy_
    global port
    global username
    global password
    version = int(l11l11ll_opy_(l1lll1_opy_ (u"ࠢࡎࡓࡀࡁࠧࠑ")))
    username=tools.get_setting(l1lll1_opy_ (u"ࠣࡗࡶࡩࡷࡴࡡ࡮ࡧࠥࠒ"))
    password=tools.get_setting(l1lll1_opy_ (u"ࠤࡓࡥࡸࡹࡷࡰࡴࡧࠦࠓ"))
    if not username:
        username = l1lll1_opy_ (u"ࠥࡒࡔࡔࡅࠣࠔ")
        password=l1lll1_opy_ (u"ࠦࡓࡕࡎࡆࠤࠕ")
    host=l11l_opy_()
    port=l1lll1_opy_ (u"ࠧ࠸࠰࠹࠸ࠥࠖ")
    if sys.argv[0] != l1lll1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡈࡧࡤࡶࡸࡏࡐࡕࡘ࠲ࠫࠗ"):
        l1111l1_opy_ = xbmcgui.Dialog()
        l1111l1_opy_.ok(l1lll1_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡳࡧࡧࡡࡌࡋࡁࡓࡕ࡞ࡇࡔࡒࡏࡓࠢࡺ࡬࡮ࡺࡥ࡞ࠢࡌࡔ࡙࡜࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ࠘"),l1lll1_opy_ (u"ࠨࡇࡵࡶࡴࡸ࡛ࠡࠡࡲࡹࠥ࡮ࡡࡷࡧࠣࡦࡪ࡫࡮ࠡࡦࡨࡸࡪࡩࡴࡦࡦࠣࡸࡷࡿࡩ࡯ࡩࠣࡸࡴࠦࡳࡵࡧࡤࡰࠥࡵࡵࡳࠢࡤࡨࡩࡵ࡮࠯ࠩ࠙"),l1lll1_opy_ (u"ࠩࡑ࡭ࡨ࡫ࠠࡵࡴࡼ࠲࠳࠴ࠧࠚ"),l1lll1_opy_ (u"ࠪࡒࡴࡽࠠࡨࡱࠣࡪࡺࡩ࡫ࠡࡻࡲࡹࡷࡹࡥ࡭ࡨ࠱ࠫࠛ"))
        sys.exit()
    l111lll_opy_=tools.get_setting(l1lll1_opy_ (u"ࠦࡵࡧࡲࡦࡰࡷࡥࡱࡵࡣ࡬ࠤࠜ"))
    l1l1ll11_opy_=tools.get_setting(l1lll1_opy_ (u"ࠧࡹࡨࡰࡹࡻࡼࡽࠨࠝ"))
    l1ll1l_opy_ = l1lll1_opy_ (u"ࠨࡇࡦࡣࡵࡷࠥࡏࡐࡕࡘࠣࠦࠞ")
    l1llll111_opy_ = os.path.join( tools.get_runtime_path() , l1lll1_opy_ (u"ࠢࡳࡧࡶࡳࡺࡸࡣࡦࡵࠥࠟ") , l1lll1_opy_ (u"ࠣࡣࡵࡸࠧࠠ") )
    tools.log(l1ll1l_opy_+l11l11ll_opy_(l1lll1_opy_ (u"ࠤࡘ࠷ࡗ࡮ࡣ࡯ࡔࡳࡦࡲࡩࡧࡥ࡚ࡄࡁࠧࠡ")))
    l11l1ll1_opy_ = l11l11ll_opy_(l1lll1_opy_ (u"ࠥࡎ࡝ࡓ࠶ࡋ࡚ࡐࡺ࡟࡝࠵ࡱ࡜࠵࠵࡭ࡓࡩ࠶ࡹࡤࡌࡆ࠵ࡤ࡙ࡐ࡯ࡧࡲ࠻ࡨࡣ࡙ࡘ࠽ࡏ࡞ࡍ࡮ࡥࡊࡊࡿࡩ࠳ࡥࡸࡦࡱࡖ࠿ࡊ࡙ࡏࡰࡨࡍࡲࡷ࡛ࡖ࠴ࡲ࡟࡞ࡒࡧࡤࡊࡰ࠷ࡠࡖ࠺࡬࡜࡜ࡗࡲ࡚࠳࠻ࡼࡥ࡜࡜ࡺࠣࠢ"))%(host,port,username,password)
    l11lll_opy_ = l11l11ll_opy_(l1lll1_opy_ (u"ࠦࡏ࡞ࡍ࠷ࡌ࡛ࡑࡻࡠࡗ࠶ࡲ࡝࠶࠶࡮ࡍࡪ࠷ࡺࡥࡍࡇ࠯ࡥ࡚ࡑࡰࡨࡳ࠵ࡩࡤ࡚࡙࠾ࡐࡘࡎ࡯ࡦࡋࡋࢀࡣ࠴ࡦࡹࡧࡲࡗ࠹ࡋ࡚ࡐࡱࡩࡎ࡬ࡸ࡜ࡗ࠵ࡳࡠࡘࡓࡨࡧࡱ࠾ࡱࡘ࠳ࡐ࡫ࡨࡌ࡜࡮ࡣ࠵ࡍࡴ࡟࡞ࡍ࠾ࠤࠣ"))%(host,port,username,password)
    l1lll11_opy_ = l11l11ll_opy_(l1lll1_opy_ (u"ࠧࡐࡘࡎ࠸ࡍ࡜ࡒࡼࡣࡈࡈࡸ࡞࡜ࡾࡦ࡚࡚ࡅࡴࡑࡴࡂࡰࡥࡇ࠽࠶ࡩ࠲ࡗࡻࡥࡱࡋࡺ࡚ࡕ࠲࡯ࡧࡾࡠࡷ࡚࡚ࡑࡾࡩ࠸࠹ࡺ࡜ࡇ࠴ࡱࡩࡷ࠾࠿ࠥࠤ"))%(host,port,username,password)
    params = tools.get_params()
    if params.get(l1lll1_opy_ (u"ࠨࡡࡤࡶ࡬ࡳࡳࠨࠥ")) is None:
        l111l1ll_opy_(params)
    else:
        action = params.get(l1lll1_opy_ (u"ࠢࡢࡥࡷ࡭ࡴࡴࠢࠦ"))
        exec action+l1lll1_opy_ (u"ࠣࠪࡳࡥࡷࡧ࡭ࡴࠫࠥࠧ")
    tools.close_item_list()
def l111l1ll_opy_(params):
    tools.log(l1ll1l_opy_+l11l11ll_opy_(l1lll1_opy_ (u"ࠤࡗ࡛ࡋࡶࡢࡪࡄࡑ࡞࡜࠻࠱ࠣࠨ"))+repr(params))
    status = l1l1lll_opy_()
    if sys.argv[0] != l1lll1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡌ࡫ࡡࡳࡵࡌࡔ࡙࡜࠯ࠨࠩ"):
        l1111l1_opy_ = xbmcgui.Dialog()
        l1111l1_opy_.ok(l1lll1_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞ࡉࡈࡅࡗ࡙࡛ࡄࡑࡏࡓࡗࠦࡷࡩ࡫ࡷࡩࡢࠦࡉࡑࡖ࡙࡟࠴ࡉࡏࡍࡑࡕࡡࠬࠪ"),l1lll1_opy_ (u"ࠬࡋࡲࡳࡱࡵࠥࠥ࡟࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡣࡧࡨࡲࠥࡪࡥࡵࡧࡦࡸࡪࡪࠠࡵࡴࡼ࡭ࡳ࡭ࠠࡵࡱࠣࡷࡹ࡫ࡡ࡭ࠢࡲࡹࡷࠦࡡࡥࡦࡲࡲ࠳࠭ࠫ"),l1lll1_opy_ (u"࠭ࡎࡪࡥࡨࠤࡹࡸࡹ࠯࠰࠱ࠫࠬ"),l1lll1_opy_ (u"ࠧࡏࡱࡺࠤ࡬ࡵࠠࡧࡷࡦ࡯ࠥࡿ࡯ࡶࡴࡶࡩࡱ࡬࠮ࠨ࠭"))
        sys.exit()
    l1l111ll_opy_ = os.path.join(l1llll111_opy_,l11l11ll_opy_(l1lll1_opy_ (u"ࠣࡤࡊ࠽ࡳࡨࡹ࠶ࡹࡥࡱࡨࡃࠢ࠮")))
    if status == 1:
       tools.log(l1ll1l_opy_+l11l11ll_opy_(l1lll1_opy_ (u"ࠤࡗࡋ࠾ࡴࡡࡘ࠶ࡪ࡙࠸࡜ࡪ࡚࠴࡙ࡾࡨࡽ࠽࠾ࠤ࠯")))
       tools.add_item(action=l1lll1_opy_ (u"ࠥࡅࡨࡩ࡯ࡶࡰࡷࠦ࠰"),  title=l1lll1_opy_ (u"ࠦࡠࡉࡏࡍࡑࡕࠤ࡬ࡵ࡬ࡥ࡟࡞ࡆࡢࡓࡹࠡࡃࡦࡧࡴࡻ࡮ࡵࠢࡌࡲ࡫ࡵ࡛࠰ࡄࡠ࡟࠴ࡉࡏࡍࡑࡕࡡࠧ࠱") , thumbnail=l1l111ll_opy_ , fanart=os.path.join(l1llll111_opy_,l11l11ll_opy_(l1lll1_opy_ (u"ࠧࡠ࡭ࡇࡷ࡜࡜ࡏ࠶ࡌ࡯ࡄࡸ࡞ࡼࡃ࠽ࠣ࠲"))) , folder=False)
       tools.add_item(action=l1lll1_opy_ (u"ࠨࡍࡢࡻࡩࡥ࡮ࡸࠢ࠳"),  title=l1lll1_opy_ (u"ࠢ࡜ࡅࡒࡐࡔࡘࠠࡳࡧࡧࡡࡠࡈ࡝ࡍ࡫ࡹࡩ࡚ࠥࡖ࡜࠱ࡅࡡࡠ࠵ࡃࡐࡎࡒࡖࡢࠨ࠴") , thumbnail=l1l111ll_opy_ , fanart=os.path.join(l1llll111_opy_,l11l11ll_opy_(l1lll1_opy_ (u"ࠣ࡜ࡰࡊࡺ࡟ࡘࡋ࠲ࡏࡲࡇࡻ࡚ࡸ࠿ࡀࠦ࠵"))) , folder=True)
       tools.add_item(action=l1lll1_opy_ (u"ࠤࡰࡊࡗࡋࡅࠣ࠶"),  title=l1lll1_opy_ (u"ࠥ࡟ࡈࡕࡌࡐࡔࠣࡽࡪࡲ࡬ࡰࡹࡠࡋࡊࡇࡒࡔࠢࡌࡔ࡙࡜ࠠࡈࡷ࡬ࡨࡪࡡ࠯ࡄࡑࡏࡓࡗࡣࠢ࠷") , thumbnail=os.path.join(l1llll111_opy_,l11l11ll_opy_(l1lll1_opy_ (u"ࠦ࡟࠹ࡖࡱ࡜ࡊ࡙ࡺࡩࡇ࠶ࡰࠥ࠸"))) , fanart=os.path.join(l1llll111_opy_,l11l11ll_opy_(l1lll1_opy_ (u"ࠧࡠ࡭ࡇࡷ࡜࡜ࡏ࠶ࡌ࡯ࡄࡸ࡞ࡼࡃ࠽ࠣ࠹"))) , folder=False)
       tools.add_item(action=l1lll1_opy_ (u"ࠨࡃ࡭ࡧࡤࡶࡤࡉࡡࡤࡪࡨࠦ࠺"),  title=l1lll1_opy_ (u"ࠢ࡜ࡅࡒࡐࡔࡘࠠ࡭࡫ࡰࡩࡢࡡࡂ࡞ࡅ࡯ࡩࡦࡸࠠࡄࡣࡦ࡬ࡪࠦࡡ࡯ࡦࠣࡔࡦࡩ࡫ࡢࡩࡨࡷࡠ࠵ࡂ࡞࡝࠲ࡇࡔࡒࡏࡓ࡟ࠥ࠻") , thumbnail=l1l111ll_opy_ , fanart=os.path.join(l1llll111_opy_,l11l11ll_opy_(l1lll1_opy_ (u"ࠣ࡜ࡰࡊࡺ࡟ࡘࡋ࠲ࡏࡲࡇࡻ࡚ࡸ࠿ࡀࠦ࠼"))) , folder=False)
       tools.add_item(action=l1lll1_opy_ (u"ࠤࡆ࡬ࡪࡩ࡫ࡇࡱࡵ࡙ࡵࡪࡡࡵࡧࡶࠦ࠽"), title=l1lll1_opy_ (u"ࠥ࡟ࡈࡕࡌࡐࡔࠣࡦࡱࡻࡥ࡞࡝ࡅࡡࡈ࡮ࡥࡤ࡭ࠣࡪࡴࡸࠠࡖࡲࡧࡥࡹ࡫ࡳ࡜࠱ࡅࡡࡠ࠵ࡃࡐࡎࡒࡖࡢࠨ࠾") , thumbnail=l1l111ll_opy_ , fanart=os.path.join(l1llll111_opy_,l11l11ll_opy_(l1lll1_opy_ (u"ࠦ࡟ࡳࡆࡶ࡛࡛ࡎ࠵ࡒ࡮ࡃࡷ࡝ࡻࡂࡃࠢ࠿"))), folder=False)
       tools.add_item(action=l1lll1_opy_ (u"ࠧࡊ࡯ࡸࡰࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠦࡀ"), title=l1lll1_opy_ (u"ࠨ࡛ࡄࡑࡏࡓࡗࠦࡲࡦࡦࡠ࡟ࡇࡣࡒࡦࡲࡲࡶࡹ࡫ࡤࠡࡅ࡫ࡥࡳࡴࡥ࡭ࡵ࡞࠳ࡇࡣ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠣࡁ") , thumbnail=l1l111ll_opy_ , fanart=os.path.join(l1llll111_opy_,l11l11ll_opy_(l1lll1_opy_ (u"࡛ࠢ࡯ࡉࡹ࡞࡞ࡊ࠱ࡎࡱࡆࡺࡠࡷ࠾࠿ࠥࡂ"))), folder=False)
       tools.add_item(action=l1lll1_opy_ (u"ࠣࡱࡳࡩࡳࡥࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠣࡃ"), title=l1lll1_opy_ (u"ࠤ࡞ࡇࡔࡒࡏࡓࠢࡺ࡬࡮ࡺࡥ࡞࡝ࡅࡡࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸࡡ࠯ࡃ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠦࡄ") , thumbnail=l1l111ll_opy_ , fanart=os.path.join(l1llll111_opy_,l11l11ll_opy_(l1lll1_opy_ (u"ࠥ࡞ࡲࡌࡵ࡚࡚ࡍ࠴ࡑࡴࡂࡶ࡜ࡺࡁࡂࠨࡅ"))), folder=False)
       tools.set_view(tools.LIST)
    else:
        window = pyxbmct.AddonDialogWindow(l1lll1_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞ࡎࡲ࡫࡮ࡴࠠࡦࡴࡵࡳࡷ࡛ࠧ࠰ࡅࡒࡐࡔࡘ࡝ࠨࡆ"))
        window.setGeometry(800, 400, 3, 1)
        background=pyxbmct.Image(l11l11l_opy_)
        window.placeControl(background, 0, 0, 3, 1)
        l11lll1_opy_ = pyxbmct.Label(l1lll1_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡸࡥࡥ࡟࡞ࡆࡢࡋࡲࡳࡱࡵࠥࠥࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡ࡮ࡲ࡫࡮ࡴࠠࡵࡱࠣࡋࡊࡇࡒࡔࠢࡌࡔ࡙࡜ࠡ࡜࠱ࡅࡡࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࡇ"), alignment=pyxbmct.ALIGN_CENTER)
        l1ll1_opy_ = pyxbmct.TextBox()
        window.placeControl(l11lll1_opy_, 0, 0)
        window.placeControl(l1ll1_opy_ , 1, 0)
        l1ll1_opy_.setText(l1lll1_opy_ (u"࠭ࡇࡆࡃࡕࡗࠥࡏࡐࡕࡘࠣࡶࡪࡷࡵࡪࡴࡨࡷࠥࡧ࡮ࠡࡣࡦࡸ࡮ࡼࡥࠡࡣࡦࡧࡴࡻ࡮ࡵ࠮ࠣࡴࡱ࡫ࡡࡴࡧࠣࡩࡳࡺࡥࡳࠢࡼࡳࡺࡸࠠࡈࡇࡄࡖࡘࠦࡉࡑࡖ࡙ࠤࡆࡩࡣࡰࡷࡱࡸࠥࡪࡥࡵࡣ࡬ࡰࡸ࠴ࠧࡈ"))
        l1lllll_opy_ = pyxbmct.Button(l1lll1_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡳࡧࡧࡡࡠࡈ࡝ࡐࡍ࡞࠳ࡇࡣ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨࡉ"))
        window.placeControl(l1lllll_opy_, 2, 0)
        window.setFocus(l1lllll_opy_)
        window.connect(l1lllll_opy_, window.close)
        window.connect(pyxbmct.ACTION_NAV_BACK, window.close)
        window.doModal()
        del window
        l1111l1_opy_ = xbmcgui.Dialog()
        l1l1_opy_ = l1111l1_opy_.yesno(l1lll1_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡴࡨࡨࡢࡍࡅࡂࡔࡖ࡟ࡈࡕࡌࡐࡔࠣࡻ࡭࡯ࡴࡦ࡟ࠣࡍࡕ࡚ࡖ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࡊ"),l1lll1_opy_ (u"࡚ࠩࡳࡺࡲࡤࠡࡻࡲࡹࠥࡲࡩ࡬ࡧࠣࡸࡴࠦࡥ࡯ࡶࡨࡶࠥࡿ࡯ࡶࡴࠣ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝ࡈࡇࡄࡖࡘࡡࡃࡐࡎࡒࡖࠥࡽࡨࡪࡶࡨࡡࠥࡏࡐࡕࡘ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࡦࡩࡣࡰࡷࡱࡸࠥࡪࡥࡵࡣ࡬ࡰࡸࠦ࡮ࡰࡹࡂࠫࡋ"),l1lll1_opy_ (u"ࠪࠫࡌ"),l1lll1_opy_ (u"ࠫࠬࡍ"),l1lll1_opy_ (u"ࠬࡔ࡯ࠨࡎ"),l1lll1_opy_ (u"࡙࠭ࡦࡵࠪࡏ"))
        if l1l1_opy_:
            l1ll1l1l_opy_()
            run()
        if not l1l1_opy_:
            sys.exit()
        else:
            sys.exit()
def open_settings(params):
    tools.log(l1ll1l_opy_+l11l11ll_opy_(l1lll1_opy_ (u"ࠢࡖ࠴࡙࠴ࡩࡍ࡬ࡶ࡜࠶ࡑ࡬ࡨࡗࡗࡷࡧࡕࡂࡃࠢࡐ"))+repr(params))
    tools.open_settings_dialog()
def l1ll1l1l_opy_():
    l1111l1_opy_ = xbmcgui.Dialog()
    l1ll1111_opy_ = l1111l1_opy_.input(l1lll1_opy_ (u"ࠨࡇࡱࡸࡪࡸࠠࡺࡱࡸࡶࠥࡡࡃࡐࡎࡒࡖࠥࡸࡥࡥ࡟ࡊࡉࡆࡘࡓ࡜ࡅࡒࡐࡔࡘࠠࡸࡪ࡬ࡸࡪࡣࠠࡊࡒࡗ࡚ࡠ࠵ࡃࡐࡎࡒࡖࡢࠦࡕࡴࡧࡵࡲࡦࡳࡥࠢࠩࡑ"), type=xbmcgui.INPUT_ALPHANUM)
    pw = l1111l1_opy_.input(l1lll1_opy_ (u"ࠩࡈࡲࡹ࡫ࡲࠡࡻࡲࡹࡷ࡛ࠦࡄࡑࡏࡓࡗࠦࡲࡦࡦࡠࡋࡊࡇࡒࡔ࡝ࡆࡓࡑࡕࡒࠡࡹ࡫࡭ࡹ࡫࡝ࠡࡋࡓࡘ࡛ࡡ࠯ࡄࡑࡏࡓࡗࡣࠠࡑࡣࡶࡷࡼࡵࡲࡥࠣࠪࡒ"), type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
    tools.set_setting(l1lll1_opy_ (u"࡙ࠪࡸ࡫ࡲ࡯ࡣࡰࡩࠬࡓ"), l1ll1111_opy_)
    tools.set_setting(l1lll1_opy_ (u"ࠫࡕࡧࡳࡴࡹࡲࡶࡩ࠭ࡔ"), pw)
def l11l11ll_opy_(l1lllllll_opy_):
    l1ll_opy_ = base64.b64decode(l1lllllll_opy_)
    return l1ll_opy_
def l1ll1ll_opy_():
    try:
        req = urllib2.Request(l1lll11_opy_)
        req.add_header(l11l11ll_opy_(l1lll1_opy_ (u"ࠧ࡜ࡘࡏ࡮ࡦ࡭࠶ࡈ࡚࠳ࡘࡸࡨࡆࡃ࠽ࠣࡕ")) , l111ll11_opy_+l1lll1_opy_ (u"ࠨ࠯ࡷࠤࡖ")+l11l11l1_opy_)
        response = urllib2.urlopen(req)
        link=response.read()
        l1ll11ll_opy_ = json.loads(link.decode(l1lll1_opy_ (u"ࠧࡶࡶࡩ࠼ࠬࡗ")))
        response.close()
        if l1ll11ll_opy_:
            tools.log(l1ll1l_opy_+l11l11ll_opy_(l1lll1_opy_ (u"ࠣࡣࡰࡖ࡭ࡪࡇࡆࡩࡥࡋ࠾࡮࡚ࡈࡘ࡮ࡍࡆࡃ࠽ࠣࡘ")))
        return l1ll11ll_opy_
    except:
        l1111l1_opy_ = xbmcgui.Dialog()
        l1111l1_opy_.ok(l11l1111_opy_, l1lll1_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡵࡩࡩࡣ࡛ࡃ࡟ࡈࡶࡷࡵࡲࠡࡥࡲࡲࡳ࡫ࡣࡵ࡫ࡱ࡫ࠥࡺ࡯ࠡࡵࡨࡶࡻ࡫ࡲࠢ࡝࠲ࡆࡢࡡ࠯ࡄࡑࡏࡓࡗࡣ࡙ࠧ"),l1lll1_opy_ (u"࡚ࠪࠫ"), l1lll1_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡱ࡯࡭ࡦࡩࡵࡩࡪࡴ࡝࡜ࡄࡠࡔࡱ࡫ࡡࡴࡧࠣࡸࡷࡿࠠࡢࡩࡤ࡭ࡳࠦ࡯ࡳࠢࡦ࡬ࡪࡩ࡫ࠡࡨࡲࡶࠥࡵࡵࡳࠢ࡯ࡥࡹ࡫ࡳࡵࠢ࡬ࡲ࡫ࡵࡲ࡮ࡣࡷ࡭ࡴࡴࠠࡢࡵࠣࡻࡪࠦ࡭ࡢࡻࠣࡦࡪࠦࡰࡦࡴࡩࡳࡷࡳࡡࡪࡰࡪࠤࡲࡧࡩ࡯ࡶࡨࡲࡦࡴࡣࡦ࠰࡞࠳ࡇࡣ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ࡛"))
        sys.exit()
def l1l1lll_opy_():
    l1l11l1l_opy_ = l1ll1ll_opy_()
    try:
        userinfo = l1l11l1l_opy_[l11l11ll_opy_(l1lll1_opy_ (u"ࠧࡪࡘࡏ࡮ࡦࡰ࠾ࡶࡢ࡮࡜ࡹࠦ࡜"))]
        status = userinfo[l11l11ll_opy_(l1lll1_opy_ (u"ࠨ࡙࡙ࡘ࠳ࡥࡆࡃ࠽ࠣ࡝"))]
        return status
    except:
        return 0
def Account(params):
    tools.log(l1ll1l_opy_+l11l11ll_opy_(l1lll1_opy_ (u"ࠢࡕ࡚࡮࡫࡞࡝ࡎ࡫ࡤ࠶࡚ࡺࡪࡃࡃࡐ࡝࡛࠺࠷ࡉࡂ࠿ࡀࠦ࡞"))+repr(params))
    l1lllll11_opy_ = l1ll1ll_opy_()
    l111llll_opy_ = l1lllll11_opy_[l11l11ll_opy_(l1lll1_opy_ (u"ࠣࡦ࡛ࡒࡱࡩ࡬࠺ࡲࡥࡱ࡟ࡼࠢ࡟"))]
    status = l111llll_opy_[l11l11ll_opy_(l1lll1_opy_ (u"ࠤࡦ࠷ࡗ࡮ࡤࡉࡘࡽࠦࡠ"))]
    if status == l11l11ll_opy_(l1lll1_opy_ (u"ࠥࡕ࡜ࡔ࠰ࡢ࡚࡝ࡰࠧࡡ")):
        status = l1lll1_opy_ (u"ࠦࡠࡉࡏࡍࡑࡕࠤࡂࠦ࡬ࡪ࡯ࡨࡡࠧࡢ")+status+l1lll1_opy_ (u"ࠧࡡ࠯ࡄࡑࡏࡓࡗࡣࠢࡣ")
    else:
        status = l1lll1_opy_ (u"ࠨ࡛ࡄࡑࡏࡓࡗࠦ࠽ࠡࡴࡨࡨࡢࠨࡤ")+status+l1lll1_opy_ (u"ࠢ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠤࡥ")
    expires = l111llll_opy_[l11l11ll_opy_(l1lll1_opy_ (u"ࠣ࡜࡛࡬ࡼ࡞࠲ࡓࡪࡧࡋ࡚ࡃࠢࡦ"))]
    if expires:
       expires = datetime.datetime.fromtimestamp(int(expires)).strftime(l1lll1_opy_ (u"ࠩࠨࡨ࠴ࠫ࡭࠰ࠧ࡜ࠤࠪࡎ࠺ࠦࡏࠪࡧ"))
       expires = l1lll1_opy_ (u"ࠥ࡟ࡈࡕࡌࡐࡔࠣࡁࠥࡸࡥࡥ࡟ࠥࡨ")+expires+l1lll1_opy_ (u"ࠦࡠ࠵ࡃࡐࡎࡒࡖࡢࠨࡩ")
    else:
       expires = l11l11ll_opy_(l1lll1_opy_ (u"࡚ࠧ࡭ࡗ࠴࡝࡜ࡎࡃࠢࡪ"))
    l1l1lll1_opy_ = l111llll_opy_[l11l11ll_opy_(l1lll1_opy_ (u"ࠨࡢࡘࡈ࠷࡜࠷ࡔࡶࡣ࡯࠸ࡰ࡞࠹ࡒࡱࡤ࠵࠹ࡿࠨ࡫"))]
    if l1l1lll1_opy_ == l1lll1_opy_ (u"ࠢ࠱ࠤ࡬"):
        l1l1lll1_opy_ = l11l11ll_opy_(l1lll1_opy_ (u"ࠣࡘ࡚࠹ࡸࡧࡗ࠲ࡲࡧࡋ࡛ࡱࠢ࡭"))
    username = l111llll_opy_[l11l11ll_opy_(l1lll1_opy_ (u"ࠤࡧ࡜ࡓࡲࡣ࡮࠷࡫ࡦ࡜࡛࠽ࠣ࡮"))]
    window = pyxbmct.AddonDialogWindow(l1lll1_opy_ (u"ࠪࡑࡾࠦࡁࡤࡥࡲࡹࡳࡺࠠࡊࡰࡩࡳࡷࡳࡡࡵ࡫ࡲࡲ࠳࠭࡯"))
    window.setGeometry(400, 220, 5, 1)
    l1lll1ll1_opy_ = pyxbmct.Label(l1lll1_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡂࠦࡧࡰ࡮ࡧࡡ࡚ࡹࡥࡳ࠼ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࡰ")+username, alignment=pyxbmct.ALIGN_LEFT )
    l111ll1_opy_ = pyxbmct.Label(l1lll1_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡃࠠࡨࡱ࡯ࡨࡢ࡙ࡴࡢࡶࡸࡷ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨࡱ")+status, alignment=pyxbmct.ALIGN_LEFT )
    l1l11l1_opy_ = pyxbmct.Label(l1lll1_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࠽ࠡࡩࡲࡰࡩࡣࡅࡹࡲ࡬ࡶࡪࡹ࠺ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࡲ")+expires, alignment=pyxbmct.ALIGN_LEFT )
    l111l1_opy_ = pyxbmct.Label(l1lll1_opy_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠ࠾ࠢࡪࡳࡱࡪ࡝ࡎࡣࡻࠤࡨࡵ࡮࡯ࡧࡦࡸ࡮ࡵ࡮ࡴ࠼ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࡳ")+l1l1lll1_opy_, alignment=pyxbmct.ALIGN_LEFT )
    window.placeControl(l1lll1ll1_opy_, 0, 0)
    window.placeControl(l111ll1_opy_, 1, 0)
    window.placeControl(l1l11l1_opy_, 2, 0)
    window.placeControl(l111l1_opy_, 3, 0)
    l1lllll_opy_ = pyxbmct.Button(l1lll1_opy_ (u"ࠨࡅ࡯ࡳࡸ࡫ࠧࡴ"))
    window.placeControl(l1lllll_opy_, 4, 0)
    window.setFocus(l1lllll_opy_)
    window.connect(l1lllll_opy_, window.close)
    window.connect(pyxbmct.ACTION_NAV_BACK, window.close)
    window.doModal()
    del window
def Mayfair(params):
  request = urllib2.Request(l11l1ll1_opy_, headers={l1lll1_opy_ (u"ࠤࡄࡧࡨ࡫ࡰࡵࠤࡵ") : l1lll1_opy_ (u"ࠥࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺࡰࡰࠧࡶ")})
  u = urllib2.urlopen(request)
  l11l111_opy_ = ElementTree.parse(u)
  l11l1l1l_opy_ = l11l111_opy_.getroot()
  l111ll1l_opy_ = os.path.join(l1llll111_opy_,l11l11ll_opy_(l1lll1_opy_ (u"ࠦࡧࡍ࠹࡯ࡤࡼ࠹ࡼࡨ࡭ࡤ࠿ࠥࡷ")))
  l1ll1l11_opy_ = os.path.join(l1llll111_opy_,l11l11ll_opy_(l1lll1_opy_ (u"ࠧࡠ࡭ࡇࡷ࡜࡜ࡏ࠶ࡌ࡯ࡄࡸ࡞ࡼࡃ࠽ࠣࡸ")))
  for l111l11l_opy_ in l11l111_opy_.findall(l11l11ll_opy_(l1lll1_opy_ (u"ࠨ࡙࠳ࡪ࡫ࡦࡲ࠻࡬ࡣࡃࡀࡁࠧࡹ"))):
      title = l111l11l_opy_.find(l11l11ll_opy_(l1lll1_opy_ (u"ࠢࡥࡉ࡯࠴ࡧࡍࡕ࠾ࠤࡺ"))).text
      title = base64.b64decode(title)
      a = l1lll1_opy_ (u"ࠨ࡚࡛࡜ࠬࡻ"), l1lll1_opy_ (u"ࠩࡄࡨࡺࡲࡴࠨࡼ"), l1lll1_opy_ (u"ࠪࡅࡩࡻ࡬ࡵࡵࠪࡽ"),l1lll1_opy_ (u"ࠫࡆࡊࡕࡍࡖࠪࡾ"),l1lll1_opy_ (u"ࠬࡇࡄࡖࡎࡗࡗࠬࡿ"),l1lll1_opy_ (u"࠭ࡡࡥࡷ࡯ࡸࠬࢀ"),l1lll1_opy_ (u"ࠧࡢࡦࡸࡰࡹࡹࠧࢁ"),l1lll1_opy_ (u"ࠨࡒࡲࡶࡳ࠭ࢂ"),l1lll1_opy_ (u"ࠩࡓࡓࡗࡔࠧࢃ"),l1lll1_opy_ (u"ࠪࡴࡴࡸ࡮ࠨࢄ"),l1lll1_opy_ (u"ࠫࡕࡵࡲ࡯ࠩࢅ"),l1lll1_opy_ (u"ࠬࡾࡸࡹࠩࢆ"), l1lll1_opy_ (u"࠭࠱࠹࠭ࠪࢇ")
      if l1l1ll11_opy_ == l1lll1_opy_ (u"ࠢࡧࡣ࡯ࡷࡪࠨ࢈"):
        if any(s in title for s in a):
          return
      l11l1lll_opy_ = l111l11l_opy_.find(l11l11ll_opy_(l1lll1_opy_ (u"ࠣࡥࡊࡼ࡭࡫ࡗࡹࡲࡦ࠷ࡗ࡬ࡤ࡙ࡌࡶࠦࢉ"))).text
      tools.add_item( action=l1lll1_opy_ (u"ࠩࡰࡥࡾ࡬ࡡࡪࡴࡪࡩࡹࡩࡨ࡯ࡵࠪࢊ"), title=title , url=l11l1lll_opy_ , thumbnail=l111ll1l_opy_ , fanart=l1ll1l11_opy_ , folder=False )
def l11l1_opy_():
  categories = list()
  url = l1lll1_opy_ (u"ࠪࠩࡸࡀࠥࡴ࠱ࡨࡲ࡮࡭࡭ࡢ࠴࠱ࡴ࡭ࡶ࠿ࡶࡵࡨࡶࡳࡧ࡭ࡦ࠿ࠨࡷࠫࡶࡡࡴࡵࡺࡳࡷࡪ࠽ࠦࡵࠩࡸࡾࡶࡥ࠾ࡏࡤࡽ࡫ࡧࡩࡳ࡮ࡲࡰࡴࡲ࡟ࡤࡣࡷࡩ࡬ࡵࡲࡪࡧࡶࠫࢋ")%(host,port,username,password)
  r = requests.get(url)
  match = re.compile(l1lll1_opy_ (u"ࠫࡁࡺࡩࡵ࡮ࡨࡂ࠭࠴ࠫࡀࠫ࠿࠳ࡹ࡯ࡴ࡭ࡧࡁ࠲࠰ࡅ࠼ࠢ࡞࡞ࡇࡉࡇࡔࡂ࡞࡞ࠬ࠳࠱࠿ࠪ࡟ࡠࡂࠬࢌ")).findall(r.content)
  for l11ll1l_opy_,l1l11lll_opy_ in match:
    l11ll1l_opy_ = base64.b64decode(l11ll1l_opy_)
    l1l1l_opy_ = os.path.join(l11l1l_opy_, l1lll1_opy_ (u"ࠬࡧࡲࡵࠩࢍ"), l1lll1_opy_ (u"࠭ࡩࡤࡱࡱ࠲ࡵࡴࡧࠨࢎ"))
    cat = l1lllll1_opy_(l11ll1l_opy_, l1l11lll_opy_, l1l1l_opy_)
    categories.append(cat)
  return categories
def mayfairgetchns(params):
    if sys.argv[0] != l1lll1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡉࡨࡥࡷࡹࡉࡑࡖ࡙࠳ࠬ࢏"):
        l1111l1_opy_ = xbmcgui.Dialog()
        l1111l1_opy_.ok(l1lll1_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡴࡨࡨࡢࡍࡅࡂࡔࡖ࡟ࡈࡕࡌࡐࡔࠣࡻ࡭࡯ࡴࡦ࡟ࠣࡍࡕ࡚ࡖ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࢐"),l1lll1_opy_ (u"ࠩࡈࡶࡷࡵࡲࠢࠢ࡜ࡳࡺࠦࡨࡢࡸࡨࠤࡧ࡫ࡥ࡯ࠢࡧࡩࡹ࡫ࡣࡵࡧࡧࠤࡹࡸࡹࡪࡰࡪࠤࡹࡵࠠࡴࡶࡨࡥࡱࠦ࡯ࡶࡴࠣࡥࡩࡪ࡯࡯࠰ࠪ࢑"),l1lll1_opy_ (u"ࠪࡒ࡮ࡩࡥࠡࡶࡵࡽ࠳࠴࠮ࠨ࢒"),l1lll1_opy_ (u"ࠫࡓࡵࡷࠡࡩࡲࠤ࡫ࡻࡣ࡬ࠢࡼࡳࡺࡸࡳࡦ࡮ࡩ࠲ࠬ࢓"))
        sys.exit()
    l1llllll_opy_ = False
    tools.log(l1ll1l_opy_+l11l11ll_opy_(l1lll1_opy_ (u"࡚ࠧࡇ࡭࠴࡝ࡗࡇࡊࡡࡈࡈࡸࡦࡲ࡜ࡳࡤࡻࡅࡒ࡟࡝࠵࠲ࡋࡄࡁࡂࠨ࢔"))+repr(params))
    url = params.get(l11l11ll_opy_(l1lll1_opy_ (u"ࠨࡤ࡙ࡌࡶࠦ࢕")))
    request = urllib2.Request(url, headers={l1lll1_opy_ (u"ࠢࡂࡥࡦࡩࡵࡺࠢ࢖") : l1lll1_opy_ (u"ࠣࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࡮࡮ࠥࢗ")})
    u = urllib2.urlopen(request)
    l11l111_opy_ = ElementTree.parse(u)
    l11l1l1l_opy_ = l11l111_opy_.getroot()
    l111ll_opy_ = list()
    l1llll1l1_opy_ = 0
    for l111l11l_opy_ in l11l111_opy_.findall(l11l11ll_opy_(l1lll1_opy_ (u"ࠤ࡜࠶࡭࡮ࡢ࡮࠷࡯ࡦࡆࡃ࠽ࠣ࢘"))):
        title = l111l11l_opy_.find(l11l11ll_opy_(l1lll1_opy_ (u"ࠥࡨࡌࡲ࠰ࡣࡉࡘࡁ࢙ࠧ"))).text
        title = base64.b64decode(title)
        title = title.partition(l1lll1_opy_ (u"ࠦࡠࠨ࢚"))
        l1111lll_opy_ = l111l11l_opy_.find(l11l11ll_opy_(l1lll1_opy_ (u"ࠧࡩ࠳ࡓࡻ࡝࡛ࡋࡺࡘ࠴ࡘࡼࡦࡆࡃ࠽࢛ࠣ"))).text
        l11111l_opy_ = l111l11l_opy_.find(l11l11ll_opy_(l1lll1_opy_ (u"ࠨ࡚ࡈࡘࡽ࡝࠶࠿ࡰࡣ࡙ࡉࡲ࡟ࡗ࠽࠾ࠤ࢜"))).text
        l11l1ll_opy_ = title[1]+title[2]
        l11l1ll_opy_ = l11l1ll_opy_.partition(l1lll1_opy_ (u"ࠢ࡞ࠤ࢝"))
        l11l1ll_opy_ = l11l1ll_opy_[2]
        l11l1ll_opy_ = l11l1ll_opy_.partition(l1lll1_opy_ (u"ࠣࠢࠣࠤࠧ࢞"))
        l11l1ll_opy_ = l11l1ll_opy_[2]
        l1_opy_ = l11l11ll_opy_(l1lll1_opy_ (u"ࠤࡍ࡜ࡒࡃࠢ࢟"))%(title[0]+title[1]+title[2])
        l1_opy_ = l1_opy_.partition(l1lll1_opy_ (u"ࠥ࡟࠴ࡉࡏࡍࡑࡕࡡࠧࢠ"))
        l1l1ll1l_opy_ = l1_opy_[2].partition(l1lll1_opy_ (u"ࠦࠥ࠱ࠠࠣࢡ"))
        l1l1ll1l_opy_ = l1l1ll1l_opy_[2].partition(l1lll1_opy_ (u"ࠧࠦࠠࠡࠤࢢ"))
        l1l1ll1l_opy_ = l1l1ll1l_opy_[0]
        l1_opy_ = l1_opy_[0]+l1_opy_[1]
        desc = l111l11l_opy_.find(l11l11ll_opy_(l1lll1_opy_ (u"ࠨ࡚ࡈࡘࡽ࡝࠸ࡐࡰࡤࡊࡕࡴࡧ࠸࠴࠾ࠤࢣ"))).text
        if desc:
           desc = base64.b64decode(desc)
           l11l1l11_opy_ = desc.partition(l1lll1_opy_ (u"ࠢࠩࠤࢤ"))
           l111111_opy_ = l11l1l11_opy_[0]
           l11l1l11_opy_ = l11l1l11_opy_[2].partition(l1lll1_opy_ (u"ࠣࠫ࡟ࡲࠧࢥ"))
           l1l1111_opy_ = desc.partition(l1lll1_opy_ (u"ࠤࠬࡠࡳࠨࢦ"))
           l1l1111_opy_ = l1l1111_opy_[2].partition(l1lll1_opy_ (u"ࠥࠬࠧࢧ"))
           l111l_opy_ = l1l1111_opy_[0]
           l1l1l11_opy_ = l11l1l11_opy_[0]
        else:
           l1l1l11_opy_ = l1lll1_opy_ (u"ࠦࠧࢨ")
        a = l1lll1_opy_ (u"ࠬ࡞ࡘ࡙ࠩࢩ"), l1lll1_opy_ (u"࠭ࡁࡥࡷ࡯ࡸࠬࢪ"), l1lll1_opy_ (u"ࠧࡂࡦࡸࡰࡹࡹࠧࢫ"),l1lll1_opy_ (u"ࠨࡃࡇ࡙ࡑ࡚ࠧࢬ"),l1lll1_opy_ (u"ࠩࡄࡈ࡚ࡒࡔࡔࠩࢭ"),l1lll1_opy_ (u"ࠪࡥࡩࡻ࡬ࡵࠩࢮ"),l1lll1_opy_ (u"ࠫࡦࡪࡵ࡭ࡶࡶࠫࢯ"),l1lll1_opy_ (u"ࠬࡖ࡯ࡳࡰࠪࢰ"),l1lll1_opy_ (u"࠭ࡐࡐࡔࡑࠫࢱ"),l1lll1_opy_ (u"ࠧࡱࡱࡵࡲࠬࢲ"),l1lll1_opy_ (u"ࠨࡒࡲࡶࡳ࠭ࢳ"),l1lll1_opy_ (u"ࠩࡻࡼࡽ࠭ࢴ"), l1lll1_opy_ (u"ࠪ࠵࠽࠱ࠧࢵ")
        if l111lll_opy_ == l1lll1_opy_ (u"ࠦࡹࡸࡵࡦࠤࢶ"):
          if l1llllll_opy_ != True:
            if any(s in l1_opy_ for s in a):
                xbmc.executebuiltin((l1lll1_opy_ (u"ࡺ࠭ࡘࡃࡏࡆ࠲ࡓࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࠫࠦࡕࡧࡲࡦࡰࡷࡥࡱ࠳ࡌࡰࡥ࡮ࠤࡊࡴࡡࡣ࡮ࡨࡨࠦࠨࠬࠡࠤࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠤࡲࡧࡹࠡࡥࡲࡲࡹࡧࡩ࡯ࠢࡤࡨࡺࡲࡴࠡࡥࡲࡲࡹ࡫࡮ࡵࠤ࠯ࠤ࠷࠶࠰࠱ࠫࠪࢷ")))
                l1111l1_opy_ = xbmcgui.Dialog()
                text = l1111l1_opy_.input(l11l11ll_opy_(l1lll1_opy_ (u"࠭ࡕࡈࡈࡼ࡞࡜࠻࠰࡚࡙ࡺࡸ࡙ࡍ࠹࡫ࡣࡽࡳ࡬࡛ࡇࡹ࡮࡜࡜ࡓࡲࡉࡈࡘࡸࡨࡌ࡜ࡹࡊࡊ࡯ࡺࡩ࡞ࡉࡨࡗࡊࡊࡾࡠࡗ࠶࠲࡜࡛ࡼ࡭ࡑ࠳࠻࡮࡞ࡖࡃ࠽ࠨࢸ")), type=xbmcgui.INPUT_NUMERIC, option=xbmcgui.ALPHANUM_HIDE_INPUT)
                if text!=tools.get_setting(l11l11ll_opy_(l1lll1_opy_ (u"ࠢࡤࡉ࡙ࡽࡧࡴࡒࡩࡤࡊࡒࡻࡠࡇࡖ࠿ࠥࢹ"))):
                    xbmc.executebuiltin((l1lll1_opy_ (u"ࡶ࡛ࠩࡆࡒࡉ࠮ࡏࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳ࠮ࠢࡑࡣࡵࡩࡳࡺࡡ࡭࠯ࡏࡳࡨࡱࠠࡆࡴࡵࡳࡷࠧࠢ࠭ࠢࠥࡍࡳࡩ࡯ࡳࡴࡨࡧࡹࠦࡣࡰࡦࡨࠥࠧ࠲ࠠ࠴࠲࠳࠴࠮࠭ࢺ")))
                    return
                else:
                    l1llllll_opy_ = True
        if not l11111l_opy_:
            l11111l_opy_ = os.path.join(l1llll111_opy_,l11l11ll_opy_(l1lll1_opy_ (u"ࠤࡥࡋ࠾ࡴࡢࡺ࠷ࡺࡦࡲࡩ࠽ࠣࢻ")))
        l1llll1l1_opy_ = l1llll1l1_opy_ + 1
        l111l11l_opy_ = Channel(l1llll1l1_opy_, l1_opy_, l11111l_opy_, l1111lll_opy_, l11l1ll_opy_, l1l1l11_opy_, l1l1ll1l_opy_)
        l111ll_opy_.append(l111l11l_opy_)
    l1ll11l_opy_(l111ll_opy_)
def l1ll11l_opy_(l111ll_opy_):
        if sys.argv[0] != l1lll1_opy_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡌ࡫ࡡࡳࡵࡌࡔ࡙࡜࠯ࠨࢼ"):
            l1111l1_opy_ = xbmcgui.Dialog()
            l1111l1_opy_.ok(l1lll1_opy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞ࡉࡈࡅࡗ࡙࡛ࡄࡑࡏࡓࡗࠦࡷࡩ࡫ࡷࡩࡢࠦࡉࡑࡖ࡙࡟࠴ࡉࡏࡍࡑࡕࡡࠬࢽ"),l1lll1_opy_ (u"ࠬࡋࡲࡳࡱࡵࠥࠥ࡟࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡣࡧࡨࡲࠥࡪࡥࡵࡧࡦࡸࡪࡪࠠࡵࡴࡼ࡭ࡳ࡭ࠠࡵࡱࠣࡷࡹ࡫ࡡ࡭ࠢࡲࡹࡷࠦࡡࡥࡦࡲࡲ࠳࠭ࢾ"),l1lll1_opy_ (u"࠭ࡎࡪࡥࡨࠤࡹࡸࡹ࠯࠰࠱ࠫࢿ"),l1lll1_opy_ (u"ࠧࡏࡱࡺࠤ࡬ࡵࠠࡧࡷࡦ࡯ࠥࡿ࡯ࡶࡴࡶࡩࡱ࡬࠮ࠨࣀ"))
            sys.exit()
        if not l111ll_opy_:
            l1111l1_opy_ = xbmcgui.Dialog()
            l1111l1_opy_.ok(l1lll1_opy_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡴࡨࡨࡢࡍࡅࡂࡔࡖ࡟ࡈࡕࡌࡐࡔࠣࡻ࡭࡯ࡴࡦ࡟ࠣࡍࡕ࡚ࡖ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࣁ"),l1lll1_opy_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡵࡩࡩࡣ࡛ࡃ࡟ࡑࡳࠥ࡫ࡶࡦࡰࡷࡷࠥࡹࡣࡩࡧࡧࡹࡱ࡫ࡤ࠯࡝࠲ࡆࡢࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࣂ"),l1lll1_opy_ (u"ࠪࠫࣃ"),l1lll1_opy_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡨ࡮ࡥࡤ࡭ࠣࡦࡦࡩ࡫ࠡ࡮ࡤࡸࡪࡸࠡࠨࣄ"))
            return
        title = l1lll1_opy_ (u"ࠧࠨࣅ")
        d = l1lll111_opy_(title,l111ll_opy_)
        d.doModal()
def mPRO(params):
    try:
        l1l11_opy_ = False
        if l111l11_opy_(l1lll1_opy_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡰࡳࡱࡪࡶࡦࡳ࠮ࡈࡇࡄࡖࡘ࠳ࡉࡑࡖ࡙ࡴࡷࡵࠧࣆ")):
            l11llll1_opy_ = xbmcaddon.Addon(l1lll1_opy_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡱࡴࡲ࡫ࡷࡧ࡭࠯ࡉࡈࡅࡗ࡙࠭ࡊࡒࡗ࡚ࡵࡸ࡯ࠨࣇ"))
            if (l11llll1_opy_.getSetting(l1lll1_opy_ (u"ࠨࡴࡨࡦࡴࡵࡴ࠯ࡧࡱࡥࡧࡲࡥࡥࠩࣈ")) != l1lll1_opy_ (u"ࠩࡷࡶࡺ࡫ࠧࣉ") or l11llll1_opy_.getSetting(l1lll1_opy_ (u"ࠪࡶࡪࡨ࡯ࡰࡶ࠱ࡹࡸ࡫ࡲࠨ࣊")) != username or l11llll1_opy_.getSetting(l1lll1_opy_ (u"ࠫࡷ࡫ࡢࡰࡱࡷ࠲ࡵࡧࡳࡴࠩ࣋")) != password):
                l11llll1_opy_.setSetting(l1lll1_opy_ (u"ࠬࡸࡥࡣࡱࡲࡸ࠳࡫࡮ࡢࡤ࡯ࡩࡩ࠭࣌"), l1lll1_opy_ (u"࠭ࡴࡳࡷࡨࠫ࣍"))
                l11llll1_opy_.setSetting(l1lll1_opy_ (u"ࠧࡳࡧࡥࡳࡴࡺ࠮ࡶࡵࡨࡶࠬ࣎"), username)
                l11llll1_opy_.setSetting(l1lll1_opy_ (u"ࠨࡴࡨࡦࡴࡵࡴ࠯ࡲࡤࡷࡸ࣏࠭"), password)
        else:
            xbmc.executebuiltin(l1lll1_opy_ (u"ࠤ࡛ࡆࡒࡉ࠮ࡓࡷࡱࡔࡱࡻࡧࡪࡰࠫࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡶࡲࡰࡩࡵࡥࡲ࠴ࡇࡆࡃࡕࡗ࠲ࡏࡐࡕࡘࡳࡶࡴ࠵࣐ࠩࠣ"))
            l1l11_opy_ = True
        if l1l11_opy_ == False:
            xbmc.executebuiltin(l1lll1_opy_ (u"ࠥࡖࡺࡴࡁࡥࡦࡲࡲ࠭ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡶࡲࡰࡩࡵࡥࡲ࠴ࡇࡆࡃࡕࡗ࠲ࡏࡐࡕࡘࡳࡶࡴ࠯࣑ࠢ"))
        if not os.path.exists(l1lll1l11_opy_):
            l1111l1_opy_ = xbmcgui.Dialog()
            l1111l1_opy_.ok(l1lll1_opy_ (u"ࠦࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞ࡉࡈࡅࡗ࡙࡛ࡄࡑࡏࡓࡗࠦࡷࡩ࡫ࡷࡩࡢࠦࡉࡑࡖ࡙࡟࠴ࡉࡏࡍࡑࡕࡡ࣒ࠧ"), l1lll1_opy_ (u"ࠧࡡࡂ࡞࡝ࡆࡓࡑࡕࡒࠡࡴࡨࡨࡢ࡟࡯ࡶࠢࡇࡓࠥࡔࡏࡕࠢ࡫ࡥࡻ࡫ࠠ࡜ࡅࡒࡐࡔࡘࠠࡺࡧ࡯ࡰࡴࡽ࡝ࡎ࡝࠲ࡇࡔࡒࡏࡓ࡟࡞ࡇࡔࡒࡏࡓࠢࡪ࡬ࡴࡹࡴࡸࡪ࡬ࡸࡪࡣ࠭࡜࠱ࡆࡓࡑࡕࡒ࡞࡝ࡆࡓࡑࡕࡒࠡࡻࡨࡰࡱࡵࡷ࡞ࡖ࡙ࠤࡌࡻࡩࡥࡧ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࡸࠦࡒࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࡛ࠧ࠰ࡅࡒࡐࡔࡘ࡝࡜࠱ࡅࡡ࣓ࠧ"),l1lll1_opy_ (u"ࠨ࡛ࡄࡑࡏࡓࡗࠦࡦࡧ࠶࠹࠼࠷ࡨ࠴࡞ࡏ࡞࠳ࡈࡕࡌࡐࡔࡠ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫ࡉ࠰ࡄ࠲ࡆ࠴ࡢࡧࡹࡧࡣ࡬ࡶࠥࡡ࠯ࡄࡑࡏࡓࡗࡣ࡛ࡄࡑࡏࡓࡗࠦࡦࡧ࠶࠹࠼࠷ࡨ࠴࡞ࡉ࡞࠳ࡈࡕࡌࡐࡔࡠ࡟ࡈࡕࡌࡐࡔࠣࡪ࡫ࡉ࠰ࡄ࠲ࡆ࠴ࡢࡻࡩࡥࡧ࡞࠳ࡈࡕࡌࡐࡔࡠ࡟ࡈࡕࡌࡐࡔࠣ࡫ࡴࡲࡤ࡞ࠢࡓࡖࡔࡡ࠯ࡄࡑࡏࡓࡗࡣࠠࡢࡦࡧࡳࡳࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡤࠡࡨࡲࡶࠥࡺࡨࡪࡵࠣࡪࡪࡧࡴࡶࡴࡨࠥࠧࣔ"),l1lll1_opy_ (u"ࠢࡈࡧࡷࠤ࡮ࡺࠠࡢࡶ࠽ࠤࡠࡉࡏࡍࡑࡕࠤࡴࡸࡡ࡯ࡩࡨࡶࡪࡪ࡝ࡩࡶࡷࡴ࠿࠵࠯࡮ࡣࡼࡪࡦ࡯ࡲࡨࡷ࡬ࡨࡪࡹ࠮࡯ࡧࡷ࠳ࡷ࡫ࡰࡰ࠱࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳࡧ࡮ࡥࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡈࡇࡄࡖࡘ࠳ࡉࡑࡖ࡙࠱࠶࠴࠴࠯ࡼ࡬ࡴࠥࡧ࡮ࡥࠢࡷࡶࡾࠦࡡࡨࡣ࡬ࡲࠦࠨࣕ"))
    except:
        pass
def mFREE(params):
    try:
        l1lll1l_opy_ = False
        if l111l11_opy_(l1lll1_opy_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡲࡵࡳ࡬ࡸࡡ࡮࠰ࡊࡉࡆࡘࡓ࠮ࡋࡓࡘ࡛࠭ࣖ")):
            l11ll111_opy_ = xbmcaddon.Addon(l1lll1_opy_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡳࡶࡴ࡭ࡲࡢ࡯࠱ࡋࡊࡇࡒࡔ࠯ࡌࡔ࡙࡜ࠧࣗ"))
            if (l11ll111_opy_.getSetting(l1lll1_opy_ (u"ࠪࡶࡪࡨ࡯ࡰࡶ࠱ࡩࡳࡧࡢ࡭ࡧࡧࠫࣘ")) != l1lll1_opy_ (u"ࠫࡹࡸࡵࡦࠩࣙ") or l11ll111_opy_.getSetting(l1lll1_opy_ (u"ࠬࡸࡥࡣࡱࡲࡸ࠳ࡻࡳࡦࡴࠪࣚ")) != username or l11ll111_opy_.getSetting(l1lll1_opy_ (u"࠭ࡲࡦࡤࡲࡳࡹ࠴ࡰࡢࡵࡶࠫࣛ")) != password):
                l11ll111_opy_.setSetting(l1lll1_opy_ (u"ࠧࡳࡧࡥࡳࡴࡺ࠮ࡦࡰࡤࡦࡱ࡫ࡤࠨࣜ"), l1lll1_opy_ (u"ࠨࡶࡵࡹࡪ࠭ࣝ"))
                l11ll111_opy_.setSetting(l1lll1_opy_ (u"ࠩࡵࡩࡧࡵ࡯ࡵ࠰ࡸࡷࡪࡸࠧࣞ"), username)
                l11ll111_opy_.setSetting(l1lll1_opy_ (u"ࠪࡶࡪࡨ࡯ࡰࡶ࠱ࡴࡦࡹࡳࠨࣟ"), password)
        else:
            xbmc.executebuiltin(l1lll1_opy_ (u"ࠦ࡝ࡈࡍࡄ࠰ࡕࡹࡳࡖ࡬ࡶࡩ࡬ࡲ࠭ࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡱࡴࡲ࡫ࡷࡧ࡭࠯ࡉࡈࡅࡗ࡙࠭ࡊࡒࡗ࡚࠴࠯ࠢ࣠"))
            l1lll1l_opy_ = True
        if l1lll1l_opy_ == False:
            xbmc.executebuiltin(l1lll1_opy_ (u"ࠧࡘࡵ࡯ࡃࡧࡨࡴࡴࠨࡱ࡮ࡸ࡫࡮ࡴ࠮ࡱࡴࡲ࡫ࡷࡧ࡭࠯ࡉࡈࡅࡗ࡙࠭ࡊࡒࡗ࡚࠮ࠨ࣡"))
        if not os.path.exists(l1lll1l11_opy_):
            l1111l1_opy_ = xbmcgui.Dialog()
            l1111l1_opy_.ok(l1lll1_opy_ (u"ࠨ࡛ࡄࡑࡏࡓࡗࠦࡲࡦࡦࡠࡋࡊࡇࡒࡔ࡝ࡆࡓࡑࡕࡒࠡࡹ࡫࡭ࡹ࡫࡝ࠡࡋࡓࡘ࡛ࡡ࠯ࡄࡑࡏࡓࡗࡣࠢ࣢"), l1lll1_opy_ (u"ࠢ࡜ࡄࡠ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝࡚ࡱࡸࠤࡉࡕࠠࡏࡑࡗࠤ࡭ࡧࡶࡦࠢࡲࡹࡷࠦࡒࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࡛ࠧ࠰ࡅࡒࡐࡔࡘ࡝࡜࠱ࡅࡡࣣࠧ"),l1lll1_opy_ (u"ࠣࠤࣤ"),l1lll1_opy_ (u"ࠤࠥࣥ"))
    except:
        pass
def CheckForUpdates(params):
    try:
        addon_id=tools.addon_id
        l111111l_opy_=ADDON.getAddonInfo(l1lll1_opy_ (u"ࠪࡺࡪࡸࡳࡪࡱࡱࣦࠫ"))
        url = l1lll1_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡧࡹࡧࡣ࡬ࡶ࡬ࡻࡩࡥࡧࡶ࠲ࡳ࡫ࡴ࠰ࡴࡨࡷࡪࡲ࡬ࡦࡴࡶ࠳ࡌࡋࡁࡓࡕ࠰ࡍࡕ࡚ࡖ࠰ࡩ࡬ࡸ࠴ࢀࡩࡱࡵ࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡊࡩࡦࡸࡳࡊࡒࡗ࡚࠴ࡧࡤࡥࡱࡱ࠲ࡽࡳ࡬ࠨࣧ")
        request = urllib2.Request(url, headers={l1lll1_opy_ (u"ࠧࡇࡣࡤࡧࡳࡸࠧࣨ") : l1lll1_opy_ (u"ࠨࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽࡳ࡬ࣩࠣ")})
        u = urllib2.urlopen(request)
        l11l111_opy_ = ElementTree.parse(u)
        l11l1l1l_opy_ = l11l111_opy_.getroot()
        l1l11ll1_opy_=l11l1l1l_opy_.get(l1lll1_opy_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨ࣪"))
        if l111111l_opy_ != l1l11ll1_opy_:
            l1111l1_opy_ = xbmcgui.Dialog()
            xbmc.executebuiltin(l1lll1_opy_ (u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷ࠭࠯ࠧ࣫"))
            xbmc.executebuiltin(l1lll1_opy_ (u"ࠩࡘࡴࡩࡧࡴࡦࡃࡧࡨࡴࡴࡒࡦࡲࡲࡷ࠭࠯ࠧ࣬"))
            l1111l1_opy_.ok(l1lll1_opy_ (u"ࠥ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝ࡈࡇࡄࡖࡘࡡࡃࡐࡎࡒࡖࠥࡽࡨࡪࡶࡨࡡࠥࡏࡐࡕࡘ࡞࠳ࡈࡕࡌࡐࡔࡠ࣭ࠦ"), l1lll1_opy_ (u"ࠦࡓ࡫ࡷࠡࡷࡳࡨࡦࡺࡥࠡࡨࡲࡹࡳࡪ࣮ࠡࠣ"),l1lll1_opy_ (u"ࠧ࡝ࡥࠡࡹ࡬ࡰࡱࠦ࡮ࡰࡹࠣࡦࡪ࡭ࡩ࡯ࠢࡸࡴࡩࡧࡴࡪࡰࡪ࠲࠳ࠨ࣯"),l1lll1_opy_ (u"ࠨࡔࡩ࡫ࡶࠤࡲࡧࡹࠡࡶࡤ࡯ࡪࠦࡡࠡࡨࡨࡻࠥࡳࡩ࡯ࡷࡷࡩࡸ࠲ࠠࡥࡧࡳࡩࡳࡪࡩ࡯ࡩࠣࡳࡳࠦࡹࡰࡷࡵࠤࡩ࡫ࡶࡪࡥࡨࠥࡡࡴࡐ࡭ࡧࡤࡷࡪࠦࡲࡦࡵࡷࡥࡷࡺࠠ࡜ࡄࡠ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝ࡈࡇࡄࡖࡘࡡ࠯ࡄࡑࡏࡓࡗࡣ࡛ࡄࡑࡏࡓࡗࠦࡷࡩ࡫ࡷࡩࡢࠦࡉࡑࡖ࡙࡟࠴ࡈ࡝࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢࡲࡲࡨ࡫ࠠࡺࡱࡸࠤࡸ࡫ࡥࠡ࡫ࡷࠤ࡭ࡧࡳࠡࡤࡨࡩࡳࠦࡵࡱࡦࡤࡸࡪࡪࣰࠡࠣ"))
            sys.exit()
        else:
            l1111l1_opy_ = xbmcgui.Dialog()
            l1111l1_opy_.ok(l1lll1_opy_ (u"ࠢ࡜ࡅࡒࡐࡔࡘࠠࡳࡧࡧࡡࡌࡋࡁࡓࡕ࡞ࡇࡔࡒࡏࡓࠢࡺ࡬࡮ࡺࡥ࡞ࠢࡌࡔ࡙࡜࡛࠰ࡅࡒࡐࡔࡘ࡝ࣱࠣ"), l1lll1_opy_ (u"ࠣࡐࡲࠤࡺࡶࡤࡢࡶࡨࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࣲࠧࠢ"),l1lll1_opy_ (u"ࠤ࡜ࡳࡺࠦࡡࡳࡧࠣࡥࡱࡸࡥࡢࡦࡼࠤࡴࡴࠠࡵࡪࡨࠤࡱࡧࡴࡦࡵࡷࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳࠴ࠢࣳ"),l1lll1_opy_ (u"ࠥࡇࡺࡸࡲࡦࡰࡷࠤ࡛࡫ࡲࡴ࡫ࡲࡲ࠿ࠦࠢࣴ")+l111111l_opy_+l1lll1_opy_ (u"ࠦࡡࡴࡌࡢࡶࡨࡷࡹࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠤࣵ")+l1l11ll1_opy_)
    except:
        pass
def DownChannels(params):
    try:
        url = l1lll1_opy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡺࡡࡳࡩࡨࡸࡨࡸࡥࡢࡶࡨࡷ࠳ࡩ࡯࡮࠱ࡤࡨࡩࡵ࡮࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࡧࡳࡼࡴ࠮ࡵࡺࡷࣶࠫ")
        request = requests.get(url)
        content = request.content
        content = content.replace(l1lll1_opy_ (u"࠭ࡰ࡭ࡧࡤࡷࡪࠦࡲࡦࡲࡲࡶࡹࠦࡩࡵࠢࡲࡲࠥࡺࡨࡦࠢࡧࡳࡼࡴࠠࡤࡪࡤࡲࡳ࡫࡬ࡴࠢࡳࡳࡸࡺࠠࡰࡰࠣࡳࡺࡸࠠࡇࡣࡦࡩࡧࡵ࡯࡬ࠢࡪࡶࡴࡻࡰࠡࡣࡷࠤ࡭ࡺࡴࡱ࠼࠲࠳࡫ࡧࡣࡦࡤࡲࡳࡰ࠴ࡣࡰ࡯࠲࡫ࡷࡵࡵࡱࡵ࠲ࡖࡪࡨ࡯ࡰࡶ࠵࠸࠼࠭ࣷ"),l1lll1_opy_ (u"ࠧࡱ࡮ࡨࡥࡸ࡫ࠠࡳࡧࡳࡳࡷࡺࠠࡪࡶࠣࡸࡴࠦࡵࡴ࠰ࠪࣸ"))
        l1l11l11_opy_(content)
    except:
        pass
def l1ll11_opy_():
    try:
        url = l1lll1_opy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡶࡤࡶ࡬࡫ࡴࡤࡴࡨࡥࡹ࡫ࡳ࠯ࡥࡲࡱ࠴ࡧࡤࡥࡱࡱ࠳ࡳ࡫ࡷࡴ࠰ࡷࡼࡹࣹ࠭")
        request = requests.get(url)
        content = request.content
        return content
    except:
        pass
def l11l_opy_():
    try:
        code = l1lll1_opy_ (u"ࣺࠩࠪ")
        url = l1lll1_opy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡦࡿࡦࡢ࡫ࡵ࡫ࡺ࡯ࡤࡦࡵ࠱ࡧࡴࡳ࠯ࡨࡷ࡬ࡨࡪ࠵ࡧࡦࡣࡵࡷࡷ࡫ࡢࡳࡣࡱࡨ࠳ࡺࡸࡵࠩࣻ")
        request = requests.get(url, headers={l1lll1_opy_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨࣼ"): l111ll11_opy_, l1lll1_opy_ (u"ࠬࡇࡣࡤࡧࡳࡸࠬࣽ"): l1lll1_opy_ (u"࠭ࡴࡦࡺࡷ࠳࡭ࡺ࡭࡭࠮ࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹࡪࡷࡱࡱ࠱ࡸ࡮࡮࠯ࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺࡰࡰࡀࡷ࠽࠱࠰࠼࠰࠯࠵ࠪ࠼ࡳࡀ࠴࠳࠾ࠧࣾ")})
        content = request.content
        code = request.status_code
        if code == 200:
            return content
        else:
            return l1lll1_opy_ (u"ࠧࡴࡷࡶࡴࡪࡴࡤࡦࡦࠪࣿ")
    except:
        return l1lll1_opy_ (u"ࠨࡵࡸࡷࡵ࡫࡮ࡥࡧࡧࠫऀ")
def l1l11l11_opy_(l1l11l11_opy_):
    class TextBox():
        l1lll1lll_opy_=10147
        l11ll_opy_=1
        l111lll1_opy_=5
        def __init__(self,*args,**kwargs):
            xbmc.executebuiltin(l1lll1_opy_ (u"ࠤࡄࡧࡹ࡯ࡶࡢࡶࡨ࡛࡮ࡴࡤࡰࡹࠫࠩࡩ࠯ࠢँ") % (self.l1lll1lll_opy_, ))
            self.l1llll1l_opy_=xbmcgui.Window(self.l1lll1lll_opy_)
            xbmc.sleep(500)
            self.setControls()
        def setControls(self):
            self.l1llll1l_opy_.getControl(self.l11ll_opy_).setLabel(l1lll1_opy_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝ࡓࡧࡳࡳࡷࡺࡥࡥࠢࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶ࡟࠴ࡉࡏࡍࡑࡕࡡࠬं"))
            try: f=open(l1l11l11_opy_); text=f.read()
            except: text=l1l11l11_opy_
            self.l1llll1l_opy_.getControl(self.l111lll1_opy_).setText(str(text))
            return
    TextBox()
    while xbmc.getCondVisibility(l1lll1_opy_ (u"ࠫ࡜࡯࡮ࡥࡱࡺ࠲ࡎࡹࡖࡪࡵ࡬ࡦࡱ࡫ࠨ࠲࠲࠴࠸࠼࠯ࠧः")):
        time.sleep(.5)
def l111l11_opy_(addon):
        if xbmc.getCondVisibility(l1lll1_opy_ (u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡎࡡࡴࡃࡧࡨࡴࡴࠨࠦࡵࠬࠫऄ") % addon) == 1:
            return True
        else:
            return False
def Clear_Cache(params):
    l1111l1_opy_ = xbmcgui.Dialog()
    l1l1_opy_ = l1111l1_opy_.yesno(l1lll1_opy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡲࡦࡦࡠࡋࡊࡇࡒࡔ࡝ࡆࡓࡑࡕࡒࠡࡹ࡫࡭ࡹ࡫࡝ࠡࡋࡓࡘ࡛ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧअ"), l1lll1_opy_ (u"ࠧࡂࡴࡨࠤࡾࡵࡵࠡࡵࡸࡶࡪࠦࡹࡰࡷࠣࡻࡦࡴࡴࠡࡶࡲࠤࡈࡲࡥࡢࡴࠣࡇࡦࡩࡨࡦࠢࡤࡲࡩࠦࡐࡢࡥ࡮ࡥ࡬࡫ࡳࡀࠩआ"), l1lll1_opy_ (u"ࠨࠩइ"), l1lll1_opy_ (u"ࠩࠪई"), l1lll1_opy_ (u"ࠪࡒࡴ࠭उ"),l1lll1_opy_ (u"ࠫ࡞࡫ࡳࠨऊ"))
    if l1l1_opy_:
        tools.Wipe_Cache()
        l1111l1_opy_ = xbmcgui.Dialog()
        l1111l1_opy_.ok(l1lll1_opy_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡸࡥࡥ࡟ࡊࡉࡆࡘࡓ࡜ࡅࡒࡐࡔࡘࠠࡸࡪ࡬ࡸࡪࡣࠠࡊࡒࡗ࡚ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ऋ"),l1lll1_opy_ (u"࠭ࡃࡢࡥ࡫ࡩࠥࡧ࡮ࡥࠢࡓࡥࡨࡱࡡࡨࡧࡶࠤ࡭ࡧࡶࡦࠢࡥࡩࡪࡴࠠࡤ࡮ࡨࡥࡷ࡫ࡤࠢࠩऌ"),l1lll1_opy_ (u"ࠧࠨऍ"),l1lll1_opy_ (u"ࠨࠩऎ"))
    if not l1l1_opy_:
        pass
    else:
        pass
def l11l11_opy_(l1lll_opy_):
    code = l1lll1_opy_ (u"ࠩࠪए")
    l11lll11_opy_ = l1lll1_opy_ (u"ࠪࠫऐ")
    l1111l_opy_ = False
    try:
        request = requests.get(ll_opy_)
        code = request.status_code
        content = request.content
    except:
        return l1lll1_opy_ (u"ࠫࡋࡧ࡬ࡴࡧࠪऑ")
    finally:
        try:
            request.close()
        except:
            return l1lll1_opy_ (u"ࠬࡌࡡ࡭ࡵࡨࠫऒ")
    if code == 200:
        l1111ll1_opy_ = re.compile(l1lll_opy_+l1lll1_opy_ (u"࠭࠽ࠣࠪ࠱࠯ࡄ࠯ࠢࠨओ")).findall(content)
        for item in l1111ll1_opy_:
            l1111ll1_opy_ = l1lll1_opy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡵࡣࡵ࡫ࡪࡺࡣࡳࡧࡤࡸࡪࡹ࠮ࡤࡱࡰ࠳ࡦࡪࡤࡰࡰ࠲ࠫऔ")+item
            try:
                request = requests.get(l1111ll1_opy_)
                l11lll11_opy_ = request.status_code
            except:
                return l1lll1_opy_ (u"ࠨࡈࡤࡰࡸ࡫ࠧक")
            finally:
                try:
                    request.close()
                except:
                    return l1lll1_opy_ (u"ࠩࡉࡥࡱࡹࡥࠨख")
            if l11lll11_opy_ == 200:
                l1111l_opy_ = True
        if l1111l_opy_ == True:
            return l1111ll1_opy_
        else:
            return l1lll1_opy_ (u"ࠪࡊࡦࡲࡳࡦࠩग")
class l1lllll1_opy_(object):
    def __init__(self, name, url, l1llllll1_opy_):
        self.name = name
        self.url = url
        self.l1llllll1_opy_ = l1llllll1_opy_
    def __repr__(self):
        return l1lll1_opy_ (u"ࠫࡈࡧࡴࡦࡩࡲࡶࡾ࠮࡮ࡢ࡯ࡨࡁࠪࡹࠬࠡࡷࡵࡰࡂࠫࡳ࠭ࠢ࡬ࡧࡴࡴ࠽ࠦࡵࠬࠫघ") \
               % (self.name, self.url, self.l1llllll1_opy_)
class Channel(object):
    def __init__(self, id, title, logo=None, l11l1l1_opy_=None, l1llll11l_opy_=l1lll1_opy_ (u"ࠧࠨङ"), l1l1l11_opy_=l1lll1_opy_ (u"ࠨࠢच"), l1l1ll1l_opy_=l1lll1_opy_ (u"ࠢࠣछ")):
        self.id = id
        self.title = title
        self.logo = logo
        self.l11l1l1_opy_ = l11l1l1_opy_
        self.l1llll11l_opy_ = l1llll11l_opy_
        self.l1l1l11_opy_ = l1l1l11_opy_
        self.l1l1ll1l_opy_ = l1l1ll1l_opy_
    def isPlayable(self):
        return hasattr(self, l1lll1_opy_ (u"ࠨࡵࡷࡶࡪࡧ࡭ࡖࡴ࡯ࠫज")) and self.l11l1l1_opy_
    def __eq__(self, other):
        return self.id == other.id
    def __repr__(self):
        return l1lll1_opy_ (u"ࠩࡆ࡬ࡦࡴ࡮ࡦ࡮ࠫ࡭ࡩࡃࠥࡴ࠮ࠣࡸ࡮ࡺ࡬ࡦ࠿ࠨࡷ࠱ࠦ࡬ࡰࡩࡲࡁࠪࡹࠬࠡࡵࡷࡶࡪࡧ࡭ࡖࡴ࡯ࡁࠪࡹࠬࠡࡲࡵࡳ࡬ࡺࡩࡵ࡮ࡨࡁࠪࡹࠬࠡࡥ࡫ࡲࡵࡸ࡯ࡨࡦࡨࡷࡨࡃࠥࡴ࠮ࠣࡧ࡭ࡴࡰࡳࡱࡪࡸ࡮ࡳࡥ࡭ࡧࡩࡸࡂࠫࡳࠪࠩझ") \
               % (self.id, self.title, self.logo, self.l11l1l1_opy_, self.l1llll11l_opy_, self.l1l1l11_opy_, self.l1l1ll1l_opy_)
class URLopener(urllib.FancyURLopener):
    version = l1lll1_opy_ (u"ࠥࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠱࠱࠰࠳࠿ࠥ࡝ࡩ࡯࠸࠷࠿ࠥࡾ࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠶࠸࠱࠴࠳࠸࠹࠳࠶࠱࠼࠼ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻ࠨञ")
class l1lll111_opy_(xbmcgui.WindowXML):
    l1111l1l_opy_ = 1000
    l11lllll_opy_ = 1001
    l111_opy_ = 9999
    l1l1ll1_opy_ = 6969
    l1111111_opy_ = 1
    l1l11111_opy_ = 2
    l11ll1l1_opy_ = 3
    l1llll1_opy_ = 4
    l11111_opy_ = 7
    l1ll11l1_opy_ = 9
    l11ll1_opy_ = 10
    l1l1l1l_opy_ = 100
    l1l1l11l_opy_ = 92
    l11ll11l_opy_ = 117
    l1lll1l1_opy_ = 61467
    def __new__(cls,title,l1lllll1l_opy_,l1ll1l1_opy_=False):
        return super(l1lll111_opy_, cls).__new__(cls, l1lll1_opy_ (u"ࠫࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠴ࡸ࡮࡮ࠪट"), l1l111l1_opy_, l1llll11_opy_)
    def __init__(self,title,l1lllll1l_opy_,l1ll1l1_opy_=False):
        super(l1lll111_opy_, self).__init__()
        self.title = title
        self.l1lllll1l_opy_ = l1lllll1l_opy_
        self.index = -1
        self.action = None
        self.l1ll1l1_opy_ = l1ll1l1_opy_
        self.l1l1l1ll_opy_ = True
        self.l1ll1lll_opy_ = False
        self.l1lll11l_opy_ = False
        self.init = False
        self.l1ll111l_opy_ = self.CustomPlayer()
        global instance
        instance = self
    def onInit(self):
        if self.l1ll111l_opy_.isPlaying():
            self.getControl(l1lll111_opy_.l1l1ll1_opy_).setVisible(True)
        if self.init:
            return
        control = self.getControl(l1lll111_opy_.l11lllll_opy_)
        control.setLabel(self.title)
        items = list()
        index = 0
        for l1llll_opy_ in self.l1lllll1l_opy_:
            label = l1llll_opy_.l1llll11l_opy_
            l111l1l_opy_ = l1lll1_opy_ (u"ࠧࠨठ")
            label = label + l111l1l_opy_
            if label == l1lll1_opy_ (u"ࠨࠢड"):
                label = l1lll1_opy_ (u"ࠢࡏࡱࠣࡴࡷࡵࡧࡳࡣࡰࠤࡦࡼࡡࡪ࡮ࡤࡦࡱ࡫ࠢढ")
            l11111ll_opy_ = l1llll_opy_.l1l1l11_opy_
            if l11111ll_opy_ == l1lll1_opy_ (u"ࠣࠤण"):
                l11111ll_opy_ = l1lll1_opy_ (u"ࠤࡑࡳࠥࡶࡲࡰࡩࡵࡥࡲࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠤत")
            l1llll1ll_opy_ = l1llll_opy_.l1l1ll1l_opy_
            if l1llll1ll_opy_ == l1lll1_opy_ (u"ࠥࠦथ"):
                l1llll1ll_opy_ = l1lll1_opy_ (u"࡚ࠦࡴ࡫࡯ࡱࡺࡲࠧद")
            name = l1lll1_opy_ (u"ࠧࠨध")
            l1llllll1_opy_ = l1llll_opy_.logo
            item = xbmcgui.ListItem(l1lll1_opy_ (u"࠭ࠧन"), name, l1llllll1_opy_)
            item.setProperty(l1lll1_opy_ (u"ࠧࡪࡰࡧࡩࡽ࠭ऩ"), str(index))
            index = index + 1
            item.setProperty(l1lll1_opy_ (u"ࠨࡅ࡫ࡥࡳࡴࡥ࡭ࡐࡤࡱࡪ࠭प"), l1llll_opy_.title)
            item.setProperty(l1lll1_opy_ (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࡌࡱࡦ࡭ࡥࠨफ"), l1llllll1_opy_)
            items.append(item)
        if self.l1ll1l1_opy_ == True:
            items = sorted(items, key=lambda x: x.getProperty(l1lll1_opy_ (u"ࠪࡷࡹࡧࡲࡵࡆࡤࡸࡪ࠭ब")))
        if self.l1l1l1ll_opy_ == True:
            items = sorted(items, key=lambda x: x.getProperty(l1lll1_opy_ (u"ࠫࡈ࡮ࡡ࡯ࡰࡨࡰࡓࡧ࡭ࡦࠩभ")))
        l1111ll_opy_ = self.getControl(l1lll111_opy_.l1111l1l_opy_)
        l1111ll_opy_.addItems(items)
        self.setFocus(l1111ll_opy_)
        self.init = True
    def onAction(self, action):
        l1111ll_opy_ = self.getControl(self.l1111l1l_opy_)
        self.id = self.getFocusId(self.l1111l1l_opy_)
        item = l1111ll_opy_.getSelectedItem()
        if action.getId() in [self.l1ll11l1_opy_, self.l1l1l11l_opy_, self.l11ll11l_opy_, self.l11ll1_opy_]:
            self.index = -1
            self.close()
        elif action.getId() == self.l1111111_opy_:
            self.action = self.l1111111_opy_
            self.index = -1
            self.close()
        elif action.getId() == self.l1l11111_opy_:
            self.action = self.l1l11111_opy_
            self.index = -1
            self.close()
        elif action.getId() in [self.l11111_opy_, self.l1l1l1l_opy_]:
            self.index = int(item.getProperty(l1lll1_opy_ (u"ࠬ࡯࡮ࡥࡧࡻࠫम")))
            self.l1l_opy_()
        else:
            self.index = -1
    def onClick(self, controlId):
        if controlId == self.l1111l1l_opy_:
            l1111ll_opy_ = self.getControl(self.l1111l1l_opy_)
            self.id = self.getFocusId(self.l1111l1l_opy_)
            item = l1111ll_opy_.getSelectedItem()
            if item:
                self.index = int(item.getProperty(l1lll1_opy_ (u"࠭ࡩ࡯ࡦࡨࡼࠬय")))
                self.l1l_opy_()
            else:
                self.index = -1
    def onFocus(self, controlId):
        pass
    def l1l111_opy_(self, l1l1l1_opy_):
        if l1l1l1_opy_:
            today = datetime.datetime.today()
            l1ll1ll1_opy_ = today + datetime.timedelta(days=1)
            l1111l11_opy_ = today - datetime.timedelta(days=1)
            if today.date() == l1l1l1_opy_.date():
                return l1lll1_opy_ (u"ࠧࡕࡱࡧࡥࡾ࠭र")
            elif l1ll1ll1_opy_.date() == l1l1l1_opy_.date():
                return l1lll1_opy_ (u"ࠨࡖࡲࡱࡴࡸࡲࡰࡹࠪऱ")
            elif l1111l11_opy_.date() == l1l1l1_opy_.date():
                return l1lll1_opy_ (u"ࠩ࡜ࡩࡸࡺࡥࡳࡦࡤࡽࠬल")
            else:
                return l1l1l1_opy_.strftime(l1lll1_opy_ (u"ࠥࠩࡆࠨळ"))
    def close(self):
        if not self.l1ll1lll_opy_:
            self.l1ll1lll_opy_ = True
        super(l1lll111_opy_, self).close()
    def l11111l1_opy_(self):
        l11lll1l_opy_ = l11l11_opy_(l1lll1_opy_ (u"ࠫࡧࡧ࡮࡯ࡧࡵࡹࡷࡲࠧऴ"))
        if l11lll1l_opy_ != l1lll1_opy_ (u"ࠬࡌࡡ࡭ࡵࡨࠫव"):
            l11ll11_opy_ = self.getControl(l1lll111_opy_.l111_opy_)
            l11ll11_opy_.setImage(l11lll1l_opy_)
    def l1l_opy_(self):
        if self.index > -1:
            extend=tools.get_setting(l11l11ll_opy_(l1lll1_opy_ (u"ࠨ࡚࡙ࡪ࠳࡞࡜࠻࡫ࠣश")))
            url = self.l1lllll1l_opy_[self.index].l11l1l1_opy_
            l11llll_opy_ = self.l1lllll1l_opy_[self.index].title
            l1llll11l_opy_ = self.l1lllll1l_opy_[self.index].l1llll11l_opy_
            l1llllll1_opy_ = self.l1lllll1l_opy_[self.index].logo
            if l1llll11l_opy_ == l1lll1_opy_ (u"ࠢࠣष") or not l1llll11l_opy_:
                l1llll11l_opy_ = l1lll1_opy_ (u"ࠣࠤस")
            if not l1llllll1_opy_:
                l1llllll1_opy_ = l1lll1_opy_ (u"ࠤࠥह")
            try:
                listitem = xbmcgui.ListItem(l1lll1_opy_ (u"ࠪࡘ࡮ࡺ࡬ࡦࠩऺ"), thumbnailImage=l1llllll1_opy_)
                listitem.setInfo(l1lll1_opy_ (u"ࠫࡻ࡯ࡤࡦࡱࠪऻ"), {l1lll1_opy_ (u"࡚ࠬࡩࡵ࡮ࡨ़ࠫ"): l11llll_opy_+l1lll1_opy_ (u"ࠨࠠ࠮ࠢࠥऽ")+l1llll11l_opy_})
            except:
                pass
            self.l1ll111l_opy_.play(item=url, listitem=listitem, windowed=0)
            self.getControl(l1lll111_opy_.l1l1ll1_opy_).setVisible(False)
            threading.Timer(1, self.l1l1111l_opy_).start()
    def l1l1111l_opy_(self):
        for retry in range(0, 100):
            xbmc.sleep(200)
            if self.l1ll111l_opy_.isPlaying():
                break
        while self.l1ll111l_opy_.isPlaying() and not xbmc.abortRequested and not self.l1ll1lll_opy_:
            xbmc.sleep(500)
        self.onPlayBackStopped()
    def onPlayBackStopped(self):
        if not self.l1ll111l_opy_.isPlaying() and not self.l1ll1lll_opy_ and not self.l1lll11l_opy_:
            self.l1lll11l_opy_ = True
            self.getControl(l1lll111_opy_.l1l1ll1_opy_).setVisible(True)
            self.l1lll11l_opy_ = False
            return
    class CustomPlayer(xbmc.Player):
        def __init__ (self, *args):
            self.l1lll1l1l_opy_ = False
        def onPlayBackStarted(self):
            self.l1lll1l1l_opy_ = True
        def onPlayBackEnded(self):
            self.onPlayBackStopped()
        def onPlayBackStopped(self):
            self.l1lll1l1l_opy_ = False
            instance.onPlayBackStopped()
        def onPlayBackPaused(self):
            if xbmc.Player().isPlaying():
                pass
        def onPlayBackResumed(self):
            if xbmc.Player().isPlaying():
                pass
params=tools.Get_Params()
url=None
name=None
mode=None
l1l111l_opy_=None
description=None
try:url = urllib.unquote_plus(params[l1lll1_opy_ (u"ࠢࡶࡴ࡯ࠦा")])
except:pass
try:name = urllib.unquote_plus(params[l1lll1_opy_ (u"ࠣࡰࡤࡱࡪࠨि")])
except:pass
try:l1l111l_opy_ = urllib.unquote_plus(params[l1lll1_opy_ (u"ࠤ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࠧी")])
except:pass
try:mode = int(params[l1lll1_opy_ (u"ࠥࡱࡴࡪࡥࠣु")])
except:pass
try:description = urllib.unquote_plus(params[l1lll1_opy_ (u"ࠦࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠤू")])
except:pass
run()